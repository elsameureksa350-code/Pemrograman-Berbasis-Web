<?php
require_once "koneksi.php";

if (isset($_POST['simpan'])) {
    $nama  = $_POST['nama_hadiah'];
    $poin  = $_POST['poin_diperlukan'];
    $stok  = $_POST['stok'];
    $gambar = null;

    if (!empty($_FILES['gambar']['name'])) {
        $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
        $nama_file_baru = 'hadiah_' . time() . '.' . $ext;
        $folder = 'uploads/hadiah/';
        if (!is_dir($folder)) mkdir($folder, 0777, true);
        $tujuan = $folder . $nama_file_baru;
        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $tujuan)) {
            $gambar = $nama_file_baru;
        }
    }

    $sql = "INSERT INTO hadiah (nama_hadiah, poin_diperlukan, stok, gambar)
            VALUES ('$nama', '$poin', '$stok', '$gambar')";

    if ($koneksi->query($sql)) {
        echo "<script>alert('Hadiah berhasil ditambahkan!'); window.location.href='?p=hadiah';</script>";
    } else {
        echo "Gagal menambah hadiah: " . $koneksi->error;
    }
}
?>

<main class="app-main">
<div class="app-content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6"><h3 class="mb-0">Tambah Hadiah</h3></div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-end">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item"><a href="./?p=hadiah">Hadiah</a></li>
          <li class="breadcrumb-item active">Tambah</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<div class="app-content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header">
        <form method="post" enctype="multipart/form-data">
          <table class="table">
            <tr>
              <td>Nama Hadiah</td>
              <td><input type="text" name="nama_hadiah" class="form-control" required></td>
            </tr>
            <tr>
              <td>Poin Diperlukan</td>
              <td><input type="number" name="poin_diperlukan" class="form-control" required></td>
            </tr>
            <tr>
              <td>Stok</td>
              <td><input type="number" name="stok" class="form-control" required></td>
            </tr>
            <tr>
              <td>Gambar (opsional)</td>
              <td><input type="file" name="gambar" class="form-control" accept="image/*"></td>
            </tr>
            <tr>
              <td colspan="2">
                <input type="submit" name="simpan" class="btn btn-success" value="Simpan">
                <a href="./?p=hadiah" class="btn btn-secondary">Kembali</a>
              </td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
</main>
