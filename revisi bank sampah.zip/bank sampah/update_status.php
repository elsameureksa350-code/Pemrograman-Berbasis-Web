<?php
require_once "koneksi.php";

if (!isset($_GET['id'])) {
    echo "<script>alert('ID tidak ditemukan!'); window.location.href='?p=setoran';</script>";
    exit();
}

$id = (int) $_GET['id'];

// Baca tipe transaksi: setoran / penukaran (default: setoran)
$tipe = isset($_GET['tipe']) ? strtolower($_GET['tipe']) : 'setoran';

// Baca status dari URL (optional), default: Selesai
$status = isset($_GET['status']) ? $_GET['status'] : 'Selesai';

// Amankan nilai status: hanya boleh Selesai atau Ditolak
if ($status !== 'Ditolak') {
    $status = 'Selesai';
}

if ($tipe === 'penukaran') {
    // ================================
    //  CASE 2: PENUKARAN HADIAH
    // ================================
    $q = $koneksi->query("
        SELECT nasabah_id, tanggal, total_poin 
        FROM penukaran_hadiah 
        WHERE id = '$id' 
        LIMIT 1
    ");
    $data = $q ? $q->fetch_assoc() : null;

    $nasabah_id = $data['nasabah_id'] ?? null;
    $tanggal    = $data['tanggal']    ?? null;
    $total_poin = (float)($data['total_poin'] ?? 0);

    // Update status di tabel penukaran_hadiah
    $sql = "UPDATE penukaran_hadiah SET status='$status' WHERE id='$id'";

    if ($koneksi->query($sql)) {

        // Sinkron ke riwayat_transaksi
        if ($nasabah_id && $tanggal) {
            // Update status
            $koneksi->query("
                UPDATE riwayat_transaksi
                SET status = '$status'
                WHERE nasabah_id = '$nasabah_id'
                  AND jenis      = 'Penukaran'
                  AND tanggal    = '$tanggal'
            ");

            // Jika Ditolak, jangan kurangi poin → nilai dibuat 0
            if ($status === 'Ditolak') {
                $koneksi->query("
                    UPDATE riwayat_transaksi
                    SET nilai = 0
                    WHERE nasabah_id = '$nasabah_id'
                      AND jenis      = 'Penukaran'
                      AND tanggal    = '$tanggal'
                ");
            }
        }

        echo "<script>alert('Status penukaran hadiah diperbarui menjadi $status!'); window.location.href='?p=penukaran_hadiah';</script>";
        exit();
    } else {
        echo "Gagal memperbarui: " . $koneksi->error;
    }

} else {
    // ================================
    //  CASE 1: SETORAN SAMPAH
    // ================================
    $res = $koneksi->query("SELECT nasabah_id, tanggal FROM setoran WHERE id='$id' LIMIT 1");
    $row = $res ? $res->fetch_assoc() : null;
    $nasabah_id = $row['nasabah_id'] ?? null;
    $tanggal    = $row['tanggal']    ?? null;

    // Update status di tabel setoran
    $sql = "UPDATE setoran SET status='$status' WHERE id='$id'";
    if ($koneksi->query($sql)) {

        // Sinkron status di riwayat_transaksi
        if ($nasabah_id && $tanggal) {
            $koneksi->query("
                UPDATE riwayat_transaksi
                SET status = '$status'
                WHERE nasabah_id = '$nasabah_id'
                  AND jenis      = 'Setoran'
                  AND tanggal    = '$tanggal'
            ");
        }

        echo "<script>alert('Status setoran diperbarui menjadi $status!'); window.location.href='?p=setoran';</script>";
        exit();
    } else {
        echo "Gagal memperbarui: " . $koneksi->error;
    }
}
?>
