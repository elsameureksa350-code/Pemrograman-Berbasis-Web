<?php
require_once 'koneksi.php';

if (isset($_POST['simpan'])) {

    $nama_sampah   = $_POST['nama_sampah'];
    $kategori      = $_POST['kategori'];
    $harga_per_kg  = $_POST['harga_per_kg'];
    $created_at    = date("Y-m-d H:i:s");

    // ------ Upload Gambar ------
    $gambar = null;
    if (!empty($_FILES['gambar']['name'])) {
        $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
        $nama_file_baru = 'jenis_' . time() . '_' . rand(1000, 9999) . '.' . $ext;

        $folder_upload = 'uploads/jenis_sampah/';
        if (!is_dir($folder_upload)) {
            mkdir($folder_upload, 0777, true);
        }

        $tujuan = $folder_upload . $nama_file_baru;

        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $tujuan)) {
            $gambar = $nama_file_baru;
        }
    }
    // ----------------------------

    // Query INSERT (tanpa harga_per_pcs, poin_per_pcs, nilai_total)
    $sql = "INSERT INTO jenis_sampah 
            (nama_sampah, kategori, harga_per_kg, gambar, created_at)
            VALUES 
            ('$nama_sampah', '$kategori', '$harga_per_kg', '$gambar', '$created_at')";

    if ($koneksi->query($sql) === TRUE) {
        echo "<script>alert('Data berhasil disimpan!'); window.location.href='?p=jenis_sampah';</script>";
        exit();
    } else {
        echo "Gagal menyimpan data: " . $koneksi->error;
    }
}
?>

<main class="app-main">

<div class="app-content-header">
    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-6">
                <h3 class="mb-0">Tambah Jenis Sampah</h3>
            </div>

            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active">Tambah Jenis Sampah</li>
                </ol>
            </div>
        </div>

    </div>
</div>

<div class="app-content">
    <div class="container-fluid">

        <div class="card">
            <div class="card-header">

                <form action="" method="post" enctype="multipart/form-data">
                <table class="table">

                    <tr>
                        <td>Nama Sampah</td>
                        <td><input type="text" name="nama_sampah" class="form-control" required></td>
                    </tr>

                    <tr>
                        <td>Kategori</td>
                        <td>
                            <select name="kategori" class="form-control" required>
                                <option value="" disabled selected>Pilih kategori</option>
                                <option value="Plastik">Plastik</option>
                                <option value="Kertas">Kertas</option>
                                <option value="Logam">Logam</option>
                                <option value="Kaca">Kaca</option>
                                <option value="Organik">Organik</option>
                                <option value="Elektronik">Elektronik (E-Waste)</option>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <td>Harga per KG</td>
                        <td><input type="number" name="harga_per_kg" class="form-control" value="0"></td>
                    </tr>

                    <tr>
                        <td>Gambar</td>
                        <td><input type="file" name="gambar" class="form-control" accept="image/*"></td>
                    </tr>

                    <tr>
                        <td colspan="2">
                            <input type="submit" name="simpan" class="btn btn-success" value="Simpan">
                            <a href="./?p=jenis_sampah" class="btn btn-secondary">Kembali</a>
                        </td>
                    </tr>

                </table>
                </form>

            </div>
        </div>

    </div>
</div>
</main>
