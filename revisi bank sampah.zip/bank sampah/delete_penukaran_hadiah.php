<?php
require_once "koneksi.php";

if (!isset($_GET['id'])) {
    echo "<script>alert('ID tidak ditemukan!'); window.location.href='?p=penukaran_hadiah';</script>";
    exit();
}

$id = (int) $_GET['id'];
$q = $koneksi->query("SELECT bukti FROM penukaran_hadiah WHERE id = $id");
$d = $q->fetch_assoc();

if ($d && !empty($d['bukti'])) {
    $folder = __DIR__ . "/uploads/penukaran_hadiah/";
    $file = $folder . $d['bukti'];
    if (is_file($file)) unlink($file);
}

$sql = "DELETE FROM penukaran_hadiah WHERE id = $id";
if ($koneksi->query($sql)) {
    echo "<script>alert('Penukaran hadiah dihapus!'); window.location.href='?p=penukaran_hadiah';</script>";
} else {
    echo "Gagal menghapus: " . $koneksi->error;
}
?>
