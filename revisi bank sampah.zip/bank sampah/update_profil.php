<?php
require_once "koneksi.php";

$id = 1;

$nama     = $_POST['nama'];
$email    = $_POST['email'];
$nomor_hp = $_POST['nomor_hp'];
$alamat   = $_POST['alamat'];

$update = "
UPDATE admin_users SET 
    nama='$nama',
    email='$email',
    nomor_hp='$nomor_hp',
    alamat='$alamat'
WHERE id=$id
";

if ($koneksi->query($update)) {
    echo "<script>alert('Profil berhasil diperbarui!'); window.location='profile.php';</script>";
} else {
    echo "Error: " . $koneksi->error;
}
?>
