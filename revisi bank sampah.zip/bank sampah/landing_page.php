<?php
session_start();

// kalau sudah login, langsung lempar ke halaman masing-masing
if (isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit;
}
if (isset($_SESSION['nasabah_id'])) {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>RECYCLEAN - Selamat Datang</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen flex flex-col">

  <!-- Header -->
  <header class="bg-white/90 backdrop-blur shadow-md sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
      <div class="flex items-center space-x-3">
        <div class="w-20 h-20 mx-auto">
                <img
                  src="recyclean.jpg"
                  alt="Logo RECYCLEAN"
                  class="w-full h-full object-contain">
        </div>
        <div>
          <h1 class="text-2xl font-bold text-green-700 tracking-tight">RECYCLEAN</h1>
          <p class="text-xs text-gray-500 -mt-1">Rubbish Your Recycle</p>
        </div>
      </div>

      <nav class="hidden md:flex items-center space-x-6 text-sm font-medium text-gray-600">
        <a href="#tentang" class="hover:text-green-700">Tentang</a>
        <a href="#cara-kerja" class="hover:text-green-700">Cara Kerja</a>
        <a href="#keunggulan" class="hover:text-green-700">Keunggulan</a>
        <a href="#bergabung" class="hover:text-green-700">Bergabung</a>
      </nav>

      <div class="flex items-center space-x-3">
        <a href="login.php"
           class="px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg border border-green-600 text-green-700 hover:bg-green-50">
          Log In
        </a>
        <a href="register_nasabah.php"
           class="px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg bg-green-600 text-white hover:bg-green-700">
          Daftar Sekarang
        </a>
      </div>
    </div>
  </header>

  <!-- Main -->
  <main class="flex-1">

    <!-- HERO -->
    <section class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid md:grid-cols-2 gap-10 items-center">
      <!-- Kiri: Hero text -->
      <div>
        <span class="inline-flex items-center px-3 py-1 rounded-full bg-green-100 text-green-700 text-xs font-semibold mb-3">
          🌱 Bank Sampah Digital • Mudah, Transparan, Menguntungkan
        </span>
        <h2 class="text-3xl md:text-4xl font-extrabold text-gray-800 mb-4 leading-tight">
          Kelola Sampah, Raih Poin, <span class="text-green-700">Bangun Kebiasaan Hijau</span> 🌍
        </h2>
        <p class="text-gray-600 mb-6 text-justify">
          <span class="font-semibold">Recyclean</span> adalah platform bank sampah berbasis web yang
          memudahkan masyarakat menjadi nasabah, menyetorkan sampah terpilah, mengumpulkan poin,
          dan menukarkannya dengan hadiah atau kebutuhan harian. Semua tercatat secara
          <span class="font-semibold">digital, transparan, dan real-time</span>.
        </p>

        <div class="flex flex-wrap gap-3 mb-8">
          <a href="register_nasabah.php"
             class="inline-flex items-center px-5 py-2.5 rounded-lg bg-green-600 text-white font-semibold hover:bg-green-700">
            Daftar Jadi Nasabah
          </a>
          <a href="#tentang"
             class="inline-flex items-center px-5 py-2.5 rounded-lg border border-green-600 text-green-700 font-semibold hover:bg-green-50">
            Pelajari Lebih Lanjut
          </a>
        </div>

        <div class="grid grid-cols-3 gap-4 text-center text-xs sm:text-sm">
          <div class="bg-white/80 backdrop-blur rounded-xl p-4 shadow">
            <div class="text-lg font-bold text-green-700">Setoran</div>
            <div class="text-gray-500 mt-1">Dicatat otomatis</div>
          </div>
          <div class="bg-white/80 backdrop-blur rounded-xl p-4 shadow">
            <div class="text-lg font-bold text-green-700">Poin</div>
            <div class="text-gray-500 mt-1">Terkumpul setiap transaksi</div>
          </div>
          <div class="bg-white/80 backdrop-blur rounded-xl p-4 shadow">
            <div class="text-lg font-bold text-green-700">Hadiah</div>
            <div class="text-gray-500 mt-1">Bisa ditukar kapan saja</div>
          </div>
        </div>
      </div>

      <!-- Kanan: Ilustrasi / kartu profil cepat -->
      <div class="bg-white rounded-2xl shadow-xl p-6 sm:p-8">
        <div class="flex flex-col items-center mb-6">
          <div class="w-30 h-50 mx-auto">
                <img
                  src="recyclean.jpg"
                  alt="Logo RECYCLEAN"
                  class="w-full h-full object-contain">
          </div>
          <h3 class="text-xl font-bold text-gray-800 mb-1 text-center">
            Profil Recyclean
          </h3>
          <p class="text-gray-600 text-center text-sm">
            Recyclean hadir sebagai solusi pengelolaan bank sampah yang modern
            dan terintegrasi, menghubungkan <span class="font-semibold">nasabah, pengelola bank sampah,</span>
            dan lingkungan sekitar dalam satu sistem.
          </p>
        </div>

        <dl class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm mb-6">
          <div class="bg-green-50 rounded-xl p-3">
            <dt class="font-semibold text-green-700 mb-1">Untuk Nasabah</dt>
            <dd class="text-gray-600">
              Pantau poin, riwayat setoran, dan penukaran hadiah langsung dari dashboard.
            </dd>
          </div>
          <div class="bg-green-50 rounded-xl p-3">
            <dt class="font-semibold text-green-700 mb-1">Untuk Admin</dt>
            <dd class="text-gray-600">
              Pengelolaan data nasabah, sampah, laporan, dan hadiah jadi jauh lebih mudah.
            </dd>
          </div>
          <div class="bg-green-50 rounded-xl p-3">
            <dt class="font-semibold text-green-700 mb-1">Transparan</dt>
            <dd class="text-gray-600">
              Setiap setoran dan penukaran tercatat rapi sehingga menghindari selisih data.
            </dd>
          </div>
          <div class="bg-green-50 rounded-xl p-3">
            <dt class="font-semibold text-green-700 mb-1">Ramah Lingkungan</dt>
            <dd class="text-gray-600">
              Mendorong kebiasaan pilah sampah dari rumah hingga ke bank sampah.
            </dd>
          </div>
        </dl>

        <div class="space-y-2 text-sm text-gray-600">
          <p><span class="font-semibold">Misi kami:</span> membantu masyarakat menjadikan sampah sebagai
            sumber nilai, bukan sekadar masalah.</p>
          <p><span class="font-semibold">Visi:</span> membangun ekosistem bank sampah yang terhubung,
            profesional, dan berkelanjutan.</p>
        </div>
      </div>
    </section>

    <!-- TENTANG RECYCLEAN -->
    <section id="tentang" class="bg-white/80 backdrop-blur py-12">
      <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4 text-center">
          Apa itu Recyclean?
        </h2>
        <p class="text-gray-600 text-sm sm:text-base text-justify mb-6">
          <span class="font-semibold">Recyclean</span> adalah aplikasi bank sampah berbasis web yang dirancang
          untuk mempermudah proses pencatatan, pengelolaan, dan pelaporan aktivitas daur ulang.
          Melalui Recyclean, nasabah dapat menyetorkan berbagai jenis sampah yang masih bernilai,
          mulai dari plastik, kertas, logam, hingga organik, kemudian mengumpulkan poin yang dapat
          ditukarkan dengan hadiah atau kebutuhan sehari-hari.
        </p>
        <p class="text-gray-600 text-sm sm:text-base text-justify">
          Sistem ini mendukung pengelola bank sampah dalam mengelola data nasabah, stok setoran,
          penilaian poin, hingga penukaran hadiah, sehingga operasional menjadi lebih tertata,
          minim kesalahan, dan transparan di mata nasabah.
        </p>
      </div>
    </section>

    <!-- CARA KERJA -->
    <section id="cara-kerja" class="py-12">
      <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-8 text-center">
          Cara Kerja Sebagai Nasabah
        </h2>

        <div class="grid md:grid-cols-4 gap-6">
          <div class="bg-white/80 rounded-2xl p-5 shadow-sm flex flex-col items-center text-center">
            <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mb-3 text-green-700 font-bold">1</div>
            <h3 class="font-semibold text-gray-800 mb-1 text-sm">Daftar Akun</h3>
            <p class="text-gray-600 text-xs">
              Daftar sebagai nasabah melalui menu <span class="font-semibold">“Daftar Nasabah”</span> dan lengkapi data diri.
            </p>
          </div>
          <div class="bg-white/80 rounded-2xl p-5 shadow-sm flex flex-col items-center text-center">
            <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mb-3 text-green-700 font-bold">2</div>
            <h3 class="font-semibold text-gray-800 mb-1 text-sm">Setor Sampah</h3>
            <p class="text-gray-600 text-xs">
              Bawa sampah terpilah ke bank sampah. Petugas akan menimbang dan mencatat di sistem.
            </p>
          </div>
          <div class="bg-white/80 rounded-2xl p-5 shadow-sm flex flex-col items-center text-center">
            <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mb-3 text-green-700 font-bold">3</div>
            <h3 class="font-semibold text-gray-800 mb-1 text-sm">Kumpulkan Poin</h3>
            <p class="text-gray-600 text-xs">
              Setiap setoran akan dikonversi menjadi poin sesuai jenis dan berat sampah.
            </p>
          </div>
          <div class="bg-white/80 rounded-2xl p-5 shadow-sm flex flex-col items-center text-center">
            <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mb-3 text-green-700 font-bold">4</div>
            <h3 class="font-semibold text-gray-800 mb-1 text-sm">Tukar Hadiah</h3>
            <p class="text-gray-600 text-xs">
              Tukarkan poin dengan hadiah menarik atau kebutuhan harian lewat menu penukaran.
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- KEUNGGULAN -->
    <section id="keunggulan" class="bg-white/90 backdrop-blur py-12">
      <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-8 text-center">
          Mengapa Harus Bergabung dengan Recyclean?
        </h2>

        <div class="grid md:grid-cols-3 gap-6">
          <div class="rounded-2xl p-6 bg-green-50 border border-green-100 shadow-sm">
            <h3 class="font-semibold text-green-700 mb-2">✨ Praktis & Transparan</h3>
            <p class="text-gray-600 text-sm">
              Riwayat setoran, poin, dan penukaran hadiah tercatat dengan jelas di dashboard nasabah,
              memudahkan pengecekan kapan pun.
            </p>
          </div>
          <div class="rounded-2xl p-6 bg-green-50 border border-green-100 shadow-sm">
            <h3 class="font-semibold text-green-700 mb-2">🎁 Poin Jadi Manfaat</h3>
            <p class="text-gray-600 text-sm">
              Sampah yang biasanya dibuang begitu saja bisa berubah menjadi poin yang bernilai dan
              ditukarkan dengan hadiah.
            </p>
          </div>
          <div class="rounded-2xl p-6 bg-green-50 border border-green-100 shadow-sm">
            <h3 class="font-semibold text-green-700 mb-2">🌍 Dampak Lingkungan Nyata</h3>
            <p class="text-gray-600 text-sm">
              Dengan rutin menyetorkan sampah, kamu ikut mengurangi timbunan sampah dan menjaga
              lingkungan di sekitar.
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- AJAKAN BERGABUNG -->
    <section id="bergabung" class="py-12">
      <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-4">
          Siap Menjadi Bagian dari Nasabah Recyclean?
        </h2>
        <p class="text-gray-600 mb-6 text-sm sm:text-base">
          Mulai ubah cara pandang terhadap sampah. Dengan menjadi nasabah Recyclean, kamu tidak hanya
          mendapatkan manfaat ekonomi, tetapi juga ikut berkontribusi menjaga bumi untuk generasi berikutnya.
        </p>

        <div class="flex flex-wrap justify-center gap-3">
        <a href="register_nasabah.php"
            class="px-6 py-3 rounded-lg bg-green-600 text-white font-semibold hover:bg-green-700">
            Daftar Sekarang
        </a>
        </div>
      </div>
    </section>

  </main>

  <!-- Footer -->
  <footer class="bg-gray-800 text-white text-center text-xs sm:text-sm py-4 mt-8">
    &copy; <?= date('Y') ?> RECYCLEAN. Bersama menjaga bumi dengan cara yang lebih cerdas.
  </footer>

</body>
</html>
