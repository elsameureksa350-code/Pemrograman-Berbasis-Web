<?php
require_once "koneksi.php";

// Asumsi: tabel admin(id, nama, email, telepon, role, tanggal_join)
$admin_id = $_SESSION['admin_id'] ?? 1;

// PROSES UPDATE
$pesan = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nama    = $koneksi->real_escape_string($_POST['nama']);
  $email   = $koneksi->real_escape_string($_POST['email']);
  $telepon = $koneksi->real_escape_string($_POST['telepon']);

  $update = $koneksi->query("UPDATE admin SET nama='$nama', email='$email', telepon='$telepon' WHERE id='$admin_id'");
  $pesan = $update ? "Profil berhasil diperbarui." : "Gagal menyimpan perubahan: ".$koneksi->error;
}

// AMBIL DATA ADMIN
$data = $koneksi->query("SELECT * FROM admin WHERE id='$admin_id'")->fetch_assoc();
$nama_admin    = $data['nama'] ?? 'Admin';
$email_admin   = $data['email'] ?? '-';
$telepon_admin = $data['telepon'] ?? '-';
$role_admin    = $data['role'] ?? 'admin';
$tanggal_join  = $data['tanggal_join'] ?? date('Y-m-d');

// buat inisial
$inisial = strtoupper(substr($nama_admin,0,2));

// statistik
$total_nasabah    = $koneksi->query("SELECT COUNT(*) AS jml FROM nasabah")->fetch_assoc()['jml'] ?? 0;
$total_setoran_kg = $koneksi->query("SELECT SUM(berat) AS kg FROM setoran")->fetch_assoc()['kg'] ?? 0;
$total_transaksi  = $koneksi->query("SELECT SUM(total) AS ttl FROM setoran")->fetch_assoc()['ttl'] ?? 0;
$total_penukaran  = $koneksi->query("SELECT COUNT(*) AS jml FROM penukaran_hadiah")->fetch_assoc()['jml'] ?? 0;
?>

<main class="app-main">
  <div class="app-content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6 fw-bold" style="color:#355E3B">
          <h3 class="mb-0 fw-bold">Profil Admin</h3>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-end">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Profil</li>
          </ol>
        </div>
      </div>
    </div>
  </div>

  <div class="app-content">
    <div class="container-fluid">
      <?php if($pesan): ?>
        <div class="alert alert-info"><?= $pesan ?></div>
      <?php endif; ?>

      <!-- Profil Card -->
      <div class="card text-center shadow-sm mb-4">
        <div class="card-body">
          <div class="rounded-circle bg-primary text-white d-inline-flex align-items-center justify-content-center mb-3" style="width:130px;height:130px;font-size:38px;">
            <?= $inisial ?>
          </div>
          <h4 class="fw-bold mb-0"><?= htmlspecialchars($nama_admin) ?></h4>
          <p class="text-muted mb-0"><?= htmlspecialchars($email_admin) ?></p>
          <p class="text-muted small mb-0">Bergabung: <?= date('d M Y', strtotime($tanggal_join)) ?> • <?= htmlspecialchars($role_admin) ?></p>
        </div>
      </div>

      <!-- Statistik -->
      <div class="row g-3 mb-4">
        <div class="col-md-3 col-sm-6">
          <div class="small-box bg-success">
            <div class="inner text-center">
              <h4><?= $total_nasabah ?></h4>
              <p>Total Nasabah</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="small-box bg-info">
            <div class="inner text-center">
              <h4><?= number_format($total_setoran_kg,1) ?> Kg</h4>
              <p>Sampah Terkumpul</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="small-box bg-primary">
            <div class="inner text-center">
              <h4>Rp <?= number_format($total_transaksi) ?></h4>
              <p>Total Transaksi</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="small-box bg-warning">
            <div class="inner text-center">
              <h4><?= $total_penukaran ?></h4>
              <p>Penukaran Hadiah</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Info Pribadi -->
      <div class="card shadow-sm">
        <div class="card-header bg-white">
          <h5 class="fw-bold mb-0">Informasi Pribadi</h5>
        </div>
        <div class="card-body">
          <form method="POST">
            <div class="mb-3">
              <label class="form-label">Nama Lengkap</label>
              <input type="text" class="form-control" name="nama" value="<?= htmlspecialchars($nama_admin) ?>" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($email_admin) ?>" required>
            </div>
            <div class="mb-3">
              <label class="form-label">Nomor Telepon</label>
              <input type="text" class="form-control" name="telepon" value="<?= htmlspecialchars($telepon_admin) ?>">
            </div>
            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Simpan Perubahan</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</main>
