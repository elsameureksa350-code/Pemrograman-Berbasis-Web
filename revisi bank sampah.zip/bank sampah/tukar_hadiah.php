<?php
session_start();
require_once "koneksi.php";

$kolomPoinHadiah = 'poin_diperlukan';

// ==== 1. Ambil NASABAH ====
$nasabah_id = $_SESSION['nasabah_id'] ?? 1;
$qNasabah = $koneksi->query("SELECT * FROM nasabah WHERE id = '$nasabah_id' LIMIT 1");
$nasabah  = $qNasabah ? $qNasabah->fetch_assoc() : null;
$nama_nasabah   = $nasabah['nama']   ?? 'Nasabah';
$alamat_nasabah = $nasabah['alamat'] ?? '';
$nomor_hp       = $nasabah['nomor_hp'] ?? '';

// ==== 2. Hitung saldo poin ====
$qPoinMasuk   = $koneksi->query("SELECT COALESCE(SUM(total), 0) AS poin_masuk FROM setoran WHERE nasabah_id='$nasabah_id' AND status='Selesai'");
$poin_masuk   = (float)($qPoinMasuk->fetch_assoc()['poin_masuk'] ?? 0);
$qPoinKeluar  = $koneksi->query("SELECT COALESCE(SUM(total_poin), 0) AS poin_keluar FROM penukaran_hadiah WHERE nasabah_id='$nasabah_id' AND status='Selesai'");
$poin_keluar  = (float)($qPoinKeluar->fetch_assoc()['poin_keluar'] ?? 0);
$saldo_poin   = max(0, $poin_masuk - $poin_keluar);

// ==== 3. Ambil daftar hadiah ====
$qHadiah = $koneksi->query("SELECT * FROM hadiah ORDER BY nama_hadiah ASC");

// ==== 4. Proses penukaran ====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Tahap 1: klik Tukar -> cek stok & poin -> kalau ok, simpan ke session lalu tampilkan form
    if (!isset($_POST['konfirmasi'])) {

        $hadiah_id = (int)($_POST['hadiah_id'] ?? 0);
        $jumlah    = (int)($_POST['jumlah'] ?? 1);
        if ($jumlah < 1) $jumlah = 1;

        // Ambil data hadiah untuk validasi stok & poin
        $qH     = $koneksi->query("SELECT * FROM hadiah WHERE id='$hadiah_id' LIMIT 1");
        $hadiah = $qH ? $qH->fetch_assoc() : null;

        if (!$hadiah) {
            echo "<script>alert('Hadiah tidak ditemukan.');</script>";
        } else {
            $poin_item  = (float)($hadiah[$kolomPoinHadiah] ?? 0);
            $stok       = (int)($hadiah['stok'] ?? 0);
            $total_poin = $poin_item * $jumlah;

            if ($stok <= 0) {
                echo "<script>alert('Stok hadiah ini sudah habis.');</script>";
            } elseif ($jumlah > $stok) {
                echo "<script>alert('Jumlah yang diminta melebihi stok. Stok tersedia: $stok');</script>";
            } elseif ($poin_item <= 0) {
                echo "<script>alert('Data poin hadiah belum diatur dengan benar.');</script>";
            } elseif ($saldo_poin < $total_poin) {
                echo "<script>alert('Poin Anda tidak cukup untuk menukar hadiah ini.');</script>";
            } else {
                // valid -> simpan ke session, lanjut ke form alamat
                $_SESSION['tukar'] = [
                    'hadiah_id' => $hadiah_id,
                    'jumlah'    => $jumlah
                ];
                header("Location: tukar_hadiah.php?form=1");
                exit;
            }
        }
    }

    // Tahap 2: kirim form pengiriman
    if (isset($_POST['konfirmasi'])) {
        $hadiah_id         = $_SESSION['tukar']['hadiah_id'] ?? 0;
        $jumlah            = $_SESSION['tukar']['jumlah']    ?? 1;
        $alamat_pengiriman = trim($_POST['alamat_pengiriman'] ?? '');
        $catatan           = trim($_POST['catatan'] ?? '');
        $tanggal           = date('Y-m-d H:i:s');

        $qH     = $koneksi->query("SELECT * FROM hadiah WHERE id='$hadiah_id' LIMIT 1");
        $hadiah = $qH ? $qH->fetch_assoc() : null;

        if ($hadiah) {
            $poin_item  = (float)($hadiah[$kolomPoinHadiah] ?? 0);
            $stok       = (int)($hadiah['stok'] ?? 0);
            $total_poin = $poin_item * $jumlah;

            // Cek lagi stok & poin pada saat konfirmasi (jaga-jaga kalau stok berubah)
            if ($stok <= 0) {
                echo "<script>alert('Stok hadiah ini sudah habis.'); window.location.href='tukar_hadiah.php';</script>";
            } elseif ($jumlah > $stok) {
                echo "<script>alert('Jumlah yang diminta melebihi stok. Stok tersedia: $stok'); window.location.href='tukar_hadiah.php';</script>";
            } elseif ($poin_item <= 0) {
                echo "<script>alert('Data poin hadiah belum diatur dengan benar.'); window.location.href='tukar_hadiah.php';</script>";
            } elseif ($saldo_poin < $total_poin) {
                echo "<script>alert('Poin Anda tidak cukup untuk menukar hadiah ini.'); window.location.href='tukar_hadiah.php';</script>";
            } else {
                $alamat_esc  = $koneksi->real_escape_string($alamat_pengiriman);
                $catatan_esc = $koneksi->real_escape_string($catatan);

                $sql = "INSERT INTO penukaran_hadiah 
                        (nasabah_id, hadiah_id, jumlah, total_poin, alamat_pengiriman, catatan, status, tanggal)
                        VALUES 
                        ('$nasabah_id', '$hadiah_id', '$jumlah', '$total_poin', '$alamat_esc', '$catatan_esc', 'Menunggu Verifikasi', '$tanggal')";
                if ($koneksi->query($sql)) {
                    // Kurangi stok hadiah sesuai jumlah yang ditukar
                    $koneksi->query("
                        UPDATE hadiah 
                        SET stok = stok - $jumlah 
                        WHERE id = '$hadiah_id'
                    ");

                    // === TAMBAHKAN LOG KE RIWAYAT_TRANSAKSI (PENGURANGAN POIN) ===
                    $judul_riwayat   = "Penukaran " . ($hadiah['nama_hadiah'] ?? 'Hadiah');
                    $jenis_riwayat   = 'Penukaran';
                    $tanggal_saja    = date('Y-m-d'); // kolom tanggal (tanpa jam)
                    $created_at_riw  = $tanggal;      // pakai timestamp yang sama

                    $sqlRiwayat = "
                        INSERT INTO riwayat_transaksi
                        (nasabah_id, jenis, judul, berat, nilai, status, tanggal, created_at)
                        VALUES
                        ('$nasabah_id', '$jenis_riwayat', '$judul_riwayat', NULL, '$total_poin', 'Pending', '$tanggal_saja', '$created_at_riw')
                    ";
                    $koneksi->query($sqlRiwayat);
                    // ============================================================

                    unset($_SESSION['tukar']);
                    echo "<script>alert('Permintaan penukaran berhasil dikirim. Menunggu verifikasi admin.'); window.location.href='tukar_hadiah.php';</script>";
                    exit;
                } else {
                    echo "<script>alert('Terjadi kesalahan saat menyimpan data.');</script>";
                }
            }
        } else {
            echo "<script>alert('Hadiah tidak ditemukan.'); window.location.href='tukar_hadiah.php';</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Penukaran Hadiah - Recyclean</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen font-sans">

<?php if (isset($_GET['form'])): ?>
  <!-- FORMULIR PENGIRIMAN -->
  <div class="max-w-lg mx-auto mt-10 bg-white shadow-xl rounded-2xl p-8">
    <h2 class="text-2xl font-bold text-gray-800 mb-3 text-center">Formulir Pengiriman Hadiah 🎁</h2>
    <p class="text-gray-600 text-center mb-6">Isi data berikut untuk pengiriman hadiah.</p>

    <form method="POST" class="space-y-4">
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Nama Penerima</label>
        <input type="text" name="nama_penerima" value="<?= htmlspecialchars($nama_nasabah) ?>" readonly
               class="w-full border rounded-lg px-3 py-2 bg-gray-100">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Alamat Pengiriman</label>
        <textarea name="alamat_pengiriman" required
                  class="w-full border rounded-lg px-3 py-2 focus:ring focus:ring-green-300"
                  placeholder="Tulis alamat lengkap..."><?= htmlspecialchars($alamat_nasabah) ?></textarea>
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Nomor Telepon</label>
        <input type="text" name="nomor_hp" value="<?= htmlspecialchars($nomor_hp) ?>"
               class="w-full border rounded-lg px-3 py-2 focus:ring focus:ring-green-300" required>
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Catatan Tambahan</label>
        <textarea name="catatan"
                  class="w-full border rounded-lg px-3 py-2 focus:ring focus:ring-green-300"
                  placeholder="Contoh: Kirim sore hari..."></textarea>
      </div>

      <input type="hidden" name="konfirmasi" value="1">

      <div class="flex justify-between items-center pt-4">
        <a href="tukar_hadiah.php" class="px-4 py-2 rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-100">
          Batal
        </a>
        <button type="submit"
                class="px-5 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-semibold">
          Kirim Permintaan
        </button>
      </div>
    </form>
  </div>

<?php else: ?>
  <!-- DAFTAR HADIAH -->
  <div class="max-w-6xl mx-auto px-6 py-8">
    <h2 class="text-3xl font-bold text-green-700 mb-6 text-center">Tukar Poin dengan Hadiah 🎁</h2>
    <p class="text-center text-gray-600 mb-10">
      Saldo Poin: <span class="font-bold text-green-700"><?= number_format($saldo_poin) ?></span>
    </p>
      <div><section class="mb-6 flex justify-between items-center">
      <a href="dashboard.php"
      class="inline-flex items-center px-4 py-2 rounded-lg bg-gray-100 text-gray-700 hover:bg-gray-200 text-sm font-medium">
        <i data-lucide="arrow-left" class="w-4 h-4 mr-2"></i>
        Kembali
      </a></section>
      </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <?php while($h = $qHadiah->fetch_assoc()): 
            $poin_item = isset($h[$kolomPoinHadiah]) ? (float)$h[$kolomPoinHadiah] : 0;
      ?>
      <div class="bg-white p-5 rounded-xl shadow-lg hover:shadow-xl transition-all">
        <?php if (!empty($h['gambar'])): ?>
          <img src="uploads/hadiah/<?= htmlspecialchars($h['gambar']) ?>" 
               class="w-full h-40 object-cover rounded-lg mb-3" 
               alt="Gambar Hadiah">
        <?php endif; ?>

        <h3 class="text-lg font-semibold text-gray-800 mb-1">
          <?= htmlspecialchars($h['nama_hadiah'] ?? 'Hadiah') ?>
        </h3>
        <p class="text-gray-600 text-sm mb-2"><?= htmlspecialchars($h['deskripsi'] ?? '') ?></p>
        <p class="text-green-700 font-medium mb-3"><?= number_format($poin_item) ?> poin / item</p>

        <form method="POST" action="">
          <input type="hidden" name="hadiah_id" value="<?= (int)$h['id'] ?>">
          <input type="number" name="jumlah" min="1" max="10" value="1" required
                 class="border rounded-lg px-3 py-1 w-20 text-center mr-2">
          <button type="submit"
                  class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium">
            Tukar
          </button>
        </form>
      </div>
      <?php endwhile; ?>
    </div>
  </div>
<?php endif; ?>
</body>
</html>
