<?php
include "koneksi.php";

$id = $_GET['id'];
$koneksi->query("UPDATE penukaran SET status='Selesai' WHERE id='$id'");

header("Location: penukaran.php");
exit;
?>
