<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tentang Recyclean</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    /* Scroll halus */
    html {
      scroll-behavior: smooth;
    }

    /* Animasi fade-in sederhana */
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(16px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .fade-in {
      opacity: 0;
      animation: fadeInUp 0.8s ease-out forwards;
    }

    .fade-in-delay-1 {
      opacity: 0;
      animation: fadeInUp 0.9s ease-out 0.1s forwards;
    }

    .fade-in-delay-2 {
      opacity: 0;
      animation: fadeInUp 1s ease-out 0.2s forwards;
    }
  </style>
</head>

<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen flex flex-col">

  <!-- Header -->
  <header class="bg-white/90 backdrop-blur shadow-md sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
      <div class="flex items-center space-x-3 fade-in">
        <div class="bg-green-600 p-2 rounded-full shadow-md transition-transform duration-200 hover:scale-105">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path d="M7 21a7 7 0 0 1 0-14h1"/>
            <path d="M11 3a7 7 0 0 1 0 14h-1"/>
            <path d="M14 21a7 7 0 0 0 0-14h-1"/>
          </svg>
        </div>
        <div>
          <h1 class="text-2xl font-bold text-green-700">RECYCLEAN</h1>
          <p class="text-xs text-gray-500 -mt-1">Rubbish Your Recycle</p>
        </div>
      </div>

      <div class="flex items-center space-x-3 fade-in-delay-1">
        <a href="landing_page_user.php"
           class="px-3 py-2 text-sm font-semibold rounded-lg text-gray-700 hover:bg-gray-100 transition-all duration-200 hover:-translate-y-0.5">
          Beranda
        </a>
        <a href="login.php"
           class="px-4 py-2 text-sm font-semibold rounded-lg border border-green-600 text-green-700 hover:bg-green-50 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
          Masuk
        </a>
        <a href="register_nasabah.php"
           class="px-4 py-2 text-sm font-semibold rounded-lg bg-green-600 text-white hover:bg-green-700 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
          Daftar Nasabah
        </a>
      </div>
    </div>
  </header>

  <!-- Main -->
  <main class="flex-1">
    <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">

      <!-- Judul / pengantar -->
      <section class="bg-white rounded-2xl shadow-xl p-8 fade-in">
        <span class="inline-flex items-center px-3 py-1 rounded-full bg-green-100 text-green-700 text-xs font-semibold mb-3 animate-pulse">
          🌱 Kenali Lebih Dekat Recyclean
        </span>
        <h2 class="text-3xl font-extrabold text-gray-800 mb-4">
          Tentang Recyclean
        </h2>
        <p class="text-gray-600 text-justify text-sm sm:text-base">
          <span class="font-semibold">Recyclean</span> adalah sistem bank sampah berbasis web yang membantu
          pengelola dan nasabah dalam mencatat aktivitas pengelolaan sampah secara digital. Melalui Recyclean,
          data nasabah, jenis sampah, setoran, hingga penukaran hadiah dapat tercatat lebih rapi, mudah dicari,
          dan nyaman dipantau. Recyclean hadir untuk menjadikan pengelolaan bank sampah lebih modern, transparan,
          dan menyenangkan bagi semua pihak.
        </p>
      </section>

      <!-- Visi & Misi -->
      <section class="grid md:grid-cols-2 gap-6 fade-in-delay-1">
        <div class="bg-white rounded-2xl shadow-xl p-6 transition-transform duration-200 hover:-translate-y-1 hover:shadow-2xl">
          <h3 class="text-xl font-bold text-green-700 mb-2">Visi</h3>
          <p class="text-gray-600 text-sm text-justify">
            Mendorong kebiasaan peduli lingkungan dengan mempermudah proses pengelolaan dan daur ulang sampah
            melalui sistem yang tertata, transparan, dan mudah digunakan, sehingga sampah tidak lagi dipandang
            sebagai sesuatu yang tidak berguna, melainkan sebagai sumber nilai.
          </p>
        </div>

        <div class="bg-white rounded-2xl shadow-xl p-6 transition-transform duration-200 hover:-translate-y-1 hover:shadow-2xl">
          <h3 class="text-xl font-bold text-green-700 mb-2">Misi</h3>
          <ul class="list-disc list-inside text-gray-600 text-sm space-y-1">
            <li>Menyajikan pencatatan setoran sampah yang jelas dan akurat.</li>
            <li>Memberikan sistem poin dan hadiah sebagai bentuk apresiasi bagi nasabah.</li>
            <li>Membantu pengelola bank sampah dalam menyusun laporan dan rekap data.</li>
            <li>Mengedukasi masyarakat untuk memilah dan mengelola sampah sejak dari rumah.</li>
          </ul>
        </div>
      </section>

      <!-- Fitur utama -->
      <section class="bg-white rounded-2xl shadow-xl p-8 fade-in-delay-2">
        <h3 class="text-xl font-bold text-gray-800 mb-4">Fitur Utama Recyclean</h3>
        <div class="grid md:grid-cols-2 gap-4 text-sm text-gray-600">
          <div class="space-y-2">
            <p class="flex items-start gap-2">
              <span class="mt-1 text-green-600">✔</span>
              <span>Data nasabah tersimpan dengan rapi dan mudah dicari kapan saja.</span>
            </p>
            <p class="flex items-start gap-2">
              <span class="mt-1 text-green-600">✔</span>
              <span>Pencatatan setoran sampah berdasarkan jenis, berat, dan waktu setoran.</span>
            </p>
            <p class="flex items-start gap-2">
              <span class="mt-1 text-green-600">✔</span>
              <span>Perhitungan poin otomatis dari setiap transaksi setoran.</span>
            </p>
          </div>
          <div class="space-y-2">
            <p class="flex items-start gap-2">
              <span class="mt-1 text-green-600">✔</span>
              <span>Penukaran poin dengan berbagai hadiah yang tersedia di sistem.</span>
            </p>
            <p class="flex items-start gap-2">
              <span class="mt-1 text-green-600">✔</span>
              <span>Riwayat transaksi yang bisa dilihat nasabah dan admin kapan saja.</span>
            </p>
            <p class="flex items-start gap-2">
              <span class="mt-1 text-green-600">✔</span>
              <span>Hak akses terpisah antara Admin dan Nasabah untuk keamanan data.</span>
            </p>
          </div>
        </div>
      </section>

      <!-- Peran Admin & Nasabah -->
      <section class="grid md:grid-cols-2 gap-6 fade-in">
        <div class="bg-white rounded-2xl shadow-xl p-6 transition-transform duration-200 hover:-translate-y-1 hover:shadow-2xl">
          <h3 class="text-lg font-bold text-gray-800 mb-2">Peran Admin</h3>
          <ul class="list-disc list-inside text-sm text-gray-600 space-y-1">
            <li>Mendaftarkan dan mengelola data nasabah.</li>
            <li>Mencatat setoran sampah dan penukaran hadiah.</li>
            <li>Mengelola daftar jenis sampah dan nilai poin.</li>
            <li>Menyusun laporan dan rekap data bank sampah secara berkala.</li>
          </ul>
        </div>

        <div class="bg-white rounded-2xl shadow-xl p-6 transition-transform duration-200 hover:-translate-y-1 hover:shadow-2xl">
          <h3 class="text-lg font-bold text-gray-800 mb-2">Peran Nasabah</h3>
          <ul class="list-disc list-inside text-sm text-gray-600 space-y-1">
            <li>Menyetorkan sampah ke bank sampah secara rutin.</li>
            <li>Melihat poin dan riwayat setoran melalui akun masing-masing.</li>
            <li>Menukarkan poin dengan hadiah yang tersedia di sistem.</li>
            <li>Ikut berkontribusi mengurangi timbunan sampah di lingkungan sekitar.</li>
          </ul>
        </div>
      </section>

      <!-- Ajak bergabung -->
      <section class="bg-green-600 text-white rounded-2xl shadow-xl p-8 text-center space-y-4 fade-in-delay-1">
        <h3 class="text-2xl font-bold">Bergabung dengan Recyclean</h3>
        <p class="text-sm text-green-100 max-w-2xl mx-auto">
          Dengan bergabung sebagai nasabah, setiap setoran sampah yang kamu lakukan tidak hanya membantu
          mengurangi sampah, tetapi juga memberikan manfaat langsung berupa poin dan hadiah. Jadikan
          kebiasaan pilah sampah sebagai bagian dari gaya hidup hijaumu bersama Recyclean.
        </p>
        <div class="flex flex-wrap gap-3 justify-center">
          <a href="login.php"
             class="px-5 py-2.5 bg-white text-green-700 font-semibold rounded-lg hover:bg-green-50 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg">
            Masuk
          </a>
          <a href="register_nasabah.php"
             class="px-5 py-2.5 border border-white text-white font-semibold rounded-lg hover:bg-green-700 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
            Daftar Sebagai Nasabah
          </a>
        </div>
      </section>

    </div>
  </main>

  <!-- Footer -->
  <footer class="bg-gray-800 text-white text-center text-sm py-4 mt-8">
    &copy; <?= date('Y') ?> RECYCLEAN. Bersama menjaga bumi.
  </footer>

</body>
</html>
