<?php
include "koneksi.php";

$id = $_GET['id'];
$koneksi->query("DELETE FROM penukaran WHERE id='$id'");

header("Location: penukaran.php");
exit;
?>
