<?php
$p=$_GET['p']??'';

switch($p){
    case 'bantuan': require_once "bantuan.php"; break;
    case 'lokasi_bank_sampah': require_once "lokasi_bank_sampah.php"; break;
    case 'notifikasi': require_once "notifikasi.php"; break;
    case 'pengaturan': require_once "pengaturan.php"; break;
    case 'riwayat_transaksi': require_once "riwayat_transaksi.php"; break;
    case 'setor_sampah': require_once "setor_sampah.php"; break;
    case 'tukar_saldo': require_once "tukar_saldo.php"; break;
    case 'profil': require_once "profil.php"; break;

    case 'login': require_once "login.php"; break;
    case 'keluar': require_once "keluar.php"; break;


    
    default: require_once "index.php"; break;
}
?>