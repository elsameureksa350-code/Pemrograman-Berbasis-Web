// pengaturan-script.js

// Initialize Lucide icons
lucide.createIcons();

// Notification dropdown toggle
const notificationBtn = document.getElementById('notification-btn');
const notificationDropdown = document.getElementById('notification-dropdown');
notificationBtn.addEventListener('click', () => {
  notificationDropdown.classList.toggle('hidden');
});

// Close dropdown when clicking outside
document.addEventListener('click', (e) => {
  if (!notificationBtn.contains(e.target) && !notificationDropdown.contains(e.target)) {
    notificationDropdown.classList.add('hidden');
  }
});

// Profile dropdown toggle
const profileBtn = document.getElementById('profile-btn');
const profileDropdown = document.getElementById('profile-dropdown');
profileBtn.addEventListener('click', () => {
  profileDropdown.classList.toggle('hidden');
});

// Close profile dropdown when clicking outside
document.addEventListener('click', (e) => {
  if (!profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
    profileDropdown.classList.add('hidden');
  }
});

// Settings toggles functionality
const toggles = [
  { id: 'push-notif', default: false },
  { id: 'email-notif', default: true },
  { id: 'deposit-notif', default: true },
  { id: 'public-profile', default: false },
  { id: 'location-data', default: true },
  { id: 'dark-theme', default: false }
];

toggles.forEach(toggle => {
  const checkbox = document.getElementById(toggle.id);
  if (checkbox) {
    // Set initial state
    if (toggle.default) {
      checkbox.checked = true;
    }

    // Add change event listener
    checkbox.addEventListener('change', (e) => {
      const isChecked = e.target.checked;
      const settingName = e.target.id.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());

      if (isChecked) {
        alert(`${settingName} telah diaktifkan.`);
      } else {
        alert(`${settingName} telah dinonaktifkan.`);
      }

      // In a real app, you would save this to localStorage or send to server
      localStorage.setItem(toggle.id, isChecked);
    });

    // Load saved state
    const savedState = localStorage.getItem(toggle.id);
    if (savedState !== null) {
      checkbox.checked = savedState === 'true';
    }
  }
});

// Language selector
const languageSelect = document.querySelector('select');
if (languageSelect) {
  languageSelect.addEventListener('change', (e) => {
    const selectedLanguage = e.target.value;
    alert(`Bahasa diubah ke: ${selectedLanguage === 'id' ? 'Bahasa Indonesia' : 'English'}`);
    // In a real app, you would reload the page with the new language
  });
}

// Account settings buttons
const changePasswordBtn = document.querySelector('button.bg-green-600');
if (changePasswordBtn && changePasswordBtn.textContent.includes('Ubah')) {
  changePasswordBtn.addEventListener('click', () => {
    alert('Fitur ubah kata sandi akan segera hadir!');
  });
}

const deleteAccountBtn = document.querySelector('button.bg-red-600');
if (deleteAccountBtn) {
  deleteAccountBtn.addEventListener('click', () => {
    if (confirm('Apakah Anda yakin ingin menghapus akun? Tindakan ini tidak dapat dibatalkan.')) {
      alert('Akun akan dihapus. Fitur ini belum diimplementasikan sepenuhnya.');
    }
  });
}

// Load saved settings on page load
window.addEventListener('load', () => {
  toggles.forEach(toggle => {
    const savedState = localStorage.getItem(toggle.id);
    if (savedState !== null) {
      const checkbox = document.getElementById(toggle.id);
      if (checkbox) {
        checkbox.checked = savedState === 'true';
      }
    }
  });
});
