// profil-script.js

// Initialize Lucide icons
lucide.createIcons();

// Load total sampah, total poin, and dampak lingkungan from localStorage and update display
const totalSampahDisplay = document.getElementById('total-sampah-display');
const totalPoinDisplay = document.getElementById('total-poin-display');
const dampakLingkunganDisplay = document.getElementById('dampak-lingkungan-display');
const savedTotalSampah = localStorage.getItem('totalSampah');
const savedTotalPoin = localStorage.getItem('totalPoin');
const savedDampakLingkungan = localStorage.getItem('dampakLingkungan');
if (savedTotalSampah && totalSampahDisplay) {
  totalSampahDisplay.textContent = savedTotalSampah + ' pcs';
}
if (savedTotalPoin && totalPoinDisplay) {
  totalPoinDisplay.textContent = parseInt(savedTotalPoin).toLocaleString() + ' pts';
}
if (savedDampakLingkungan && dampakLingkunganDisplay) {
  dampakLingkunganDisplay.textContent = savedDampakLingkungan + ' pohon';
}

// Animate progress bars for monthly and annual deposits
const progressBulanan = document.getElementById('progress-bulanan');
const progressTahunan = document.getElementById('progress-tahunan');

// Load progress data from localStorage (same as dashboard)
let setoranBulanIni = localStorage.getItem('setoranBulanIni');
if (!setoranBulanIni) {
  setoranBulanIni = '15'; // Default monthly progress
  localStorage.setItem('setoranBulanIni', setoranBulanIni);
}

let setoranTahunIni = localStorage.getItem('setoranTahunIni');
if (!setoranTahunIni) {
  setoranTahunIni = '225'; // Default yearly progress
  localStorage.setItem('setoranTahunIni', setoranTahunIni);
}

if (progressBulanan) {
  // Calculate monthly progress (current / 20 pcs)
  const bulanProgress = Math.min((parseInt(setoranBulanIni) / 20) * 100, 100);
  setTimeout(() => {
    progressBulanan.style.width = bulanProgress + '%';
  }, 500);
}

if (progressTahunan) {
  // Calculate annual progress (current / 300 pcs)
  const tahunProgress = Math.min((parseInt(setoranTahunIni) / 300) * 100, 100);
  setTimeout(() => {
    progressTahunan.style.width = tahunProgress + '%';
  }, 1000);
}

// Profile photo change functionality
const changePhotoBtn = document.getElementById('change-photo-btn');
const photoInput = document.getElementById('photo-input');
const profileImage = document.getElementById('profile-image');

changePhotoBtn.addEventListener('click', () => {
  photoInput.click();
});

photoInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (file) {
    // Validate file type
    if (!file.type.startsWith('image/')) {
      showToast('Error', 'File harus berupa gambar!', 'error');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      showToast('Error', 'Ukuran file maksimal 5MB!', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      profileImage.src = e.target.result;
      // In a real app, you would upload this to a server
      showToast('Berhasil', 'Foto profil berhasil diubah!', 'success');
    };
    reader.readAsDataURL(file);
  }
});

// Profile edit functionality
const editBtn = document.getElementById('edit-btn');
const saveBtn = document.getElementById('save-btn');
const cancelBtn = document.getElementById('cancel-btn');
const profileForm = document.getElementById('profile-form');
const inputs = profileForm.querySelectorAll('input, textarea');

editBtn.addEventListener('click', () => {
  // Enable editing
  inputs.forEach(input => {
    input.removeAttribute('readonly');
    input.classList.add('bg-white');
  });

  // Show save/cancel buttons, hide edit button
  editBtn.classList.add('hidden');
  saveBtn.classList.remove('hidden');
  cancelBtn.classList.remove('hidden');
});

cancelBtn.addEventListener('click', () => {
  // Disable editing
  inputs.forEach(input => {
    input.setAttribute('readonly', true);
    input.classList.remove('bg-white');
  });

  // Reset values (in a real app, you'd fetch from server)
  profileForm.reset();

  // Show edit button, hide save/cancel buttons
  editBtn.classList.remove('hidden');
  saveBtn.classList.add('hidden');
  cancelBtn.classList.add('hidden');
});

saveBtn.addEventListener('click', (e) => {
  e.preventDefault();

  // Form validation
  const formData = new FormData(profileForm);
  const nama = formData.get('nama')?.trim();
  const email = formData.get('email')?.trim();
  const telepon = formData.get('telepon')?.trim();
  const alamat = formData.get('alamat')?.trim();

  // Validate required fields
  if (!nama || !email || !telepon || !alamat) {
    showToast('Error', 'Semua field harus diisi!', 'error');
    return;
  }

  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    showToast('Error', 'Format email tidak valid!', 'error');
    return;
  }

  // Validate phone number (Indonesian format)
  const phoneRegex = /^(\+62|62|0)[8-9][0-9]{7,11}$/;
  if (!phoneRegex.test(telepon.replace(/\s|-/g, ''))) {
    showToast('Error', 'Format nomor telepon tidak valid!', 'error');
    return;
  }

  // In a real app, you would send this data to the server
  // For now, we'll simulate saving and update the display name
  const displayNameElement = document.querySelector('h1');
  if (displayNameElement && nama) {
    displayNameElement.textContent = nama;
  }

  showToast('Berhasil', 'Profil berhasil disimpan!', 'success');

  // Disable editing
  inputs.forEach(input => {
    input.setAttribute('readonly', true);
    input.classList.remove('bg-white');
  });

  // Show edit button, hide save/cancel buttons
  editBtn.classList.remove('hidden');
  saveBtn.classList.add('hidden');
  cancelBtn.classList.add('hidden');
});

// Initialize readonly state
inputs.forEach(input => {
  input.setAttribute('readonly', true);
});
