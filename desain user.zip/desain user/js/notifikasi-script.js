// Notification filtering and management script

document.addEventListener('DOMContentLoaded', function() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const notificationItems = document.querySelectorAll('.notification-item');
    const markAllReadBtn = document.getElementById('mark-all-read');
    const clearAllBtn = document.getElementById('clear-all');
    const unreadCountElement = document.querySelector('.text-sm.text-gray-600');

    // Function to update unread count
    function updateUnreadCount() {
        const unreadIndicators = document.querySelectorAll('.unread-indicator');
        const count = unreadIndicators.length;
        unreadCountElement.textContent = `${count} notifikasi belum dibaca`;
    }

    // Filter notifications
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');

            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active', 'bg-green-600', 'text-white'));
            filterButtons.forEach(btn => btn.classList.add('bg-gray-200', 'text-gray-700'));
            this.classList.add('active', 'bg-green-600', 'text-white');
            this.classList.remove('bg-gray-200', 'text-gray-700');

            // Filter notifications
            notificationItems.forEach(item => {
                if (filter === 'all' || item.getAttribute('data-type') === filter) {
                    item.style.display = 'flex';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });

    // Mark all as read
    markAllReadBtn.addEventListener('click', function() {
        const unreadIndicators = document.querySelectorAll('.unread-indicator');
        unreadIndicators.forEach(indicator => {
            indicator.classList.remove('unread-indicator');
        });
        updateUnreadCount();
    });

    // Clear all notifications
    clearAllBtn.addEventListener('click', function() {
        if (confirm('Apakah Anda yakin ingin menghapus semua notifikasi?')) {
            notificationItems.forEach(item => {
                item.remove();
            });
            updateUnreadCount();
        }
    });

    // Load more notifications functionality
    const loadMoreBtn = document.querySelector('button.bg-green-600.hover\\:bg-green-700.text-white.px-6.py-3.rounded-lg.font-medium');
    let notificationPage = 1;
    const notificationsPerPage = 3;

    // Additional notifications data
    const additionalNotifications = [
        {
            type: 'setoran',
            icon: 'check-circle',
            color: 'green',
            title: 'Setoran botol plastik dikonfirmasi',
            message: 'Setoran 2.5 kg botol plastik Anda telah dikonfirmasi. +625 poin telah ditambahkan.',
            time: '1 minggu yang lalu',
            unread: true
        },
        {
            type: 'penukaran',
            icon: 'gift',
            color: 'blue',
            title: 'Hadiah berhasil ditukar',
            message: 'Paket snack sehat telah dikirim ke alamat Anda. Terima kasih atas partisipasi Anda!',
            time: '1 minggu yang lalu',
            unread: true
        },
        {
            type: 'sistem',
            icon: 'bell',
            color: 'yellow',
            title: 'Pengingat: Target mingguan',
            message: 'Anda belum setor sampah minggu ini. Yuk mulai kontribusi Anda untuk lingkungan!',
            time: '8 hari yang lalu',
            unread: false
        },
        {
            type: 'level',
            icon: 'star',
            color: 'purple',
            title: 'Bonus level up!',
            message: 'Selamat! Anda mendapatkan bonus 200 poin tambahan untuk mencapai Level 3.',
            time: '10 hari yang lalu',
            unread: false
        },
        {
            type: 'setoran',
            icon: 'check-circle',
            color: 'green',
            title: 'Setoran kaleng aluminium dikonfirmasi',
            message: 'Setoran 1.2 kg kaleng aluminium Anda telah dikonfirmasi. +360 poin telah ditambahkan.',
            time: '12 hari yang lalu',
            unread: false
        },
        {
            type: 'sistem',
            icon: 'info',
            color: 'blue',
            title: 'Program baru: Recycle Challenge',
            message: 'Ikuti tantangan baru kami dan dapatkan poin bonus! Cek dashboard untuk detailnya.',
            time: '2 minggu yang lalu',
            unread: false
        }
    ];

    function loadMoreNotifications() {
        const startIndex = (notificationPage - 1) * notificationsPerPage;
        const endIndex = startIndex + notificationsPerPage;
        const notificationsToLoad = additionalNotifications.slice(startIndex, endIndex);

        if (notificationsToLoad.length === 0) {
            // No more notifications to load
            loadMoreBtn.textContent = 'Tidak ada notifikasi lagi';
            loadMoreBtn.disabled = true;
            loadMoreBtn.classList.add('opacity-50', 'cursor-not-allowed');
            return;
        }

        // Create container for older notifications if it doesn't exist
        let olderNotificationsContainer = document.querySelector('.older-notifications');
        if (!olderNotificationsContainer) {
            olderNotificationsContainer = document.createElement('div');
            olderNotificationsContainer.className = 'bg-white rounded-xl shadow-lg p-6 older-notifications';
            olderNotificationsContainer.innerHTML = `
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <i data-lucide="calendar" class="w-5 h-5 text-gray-600 mr-2"></i>
                    Lebih Lama
                </h3>
                <div class="space-y-3 notifications-list"></div>
            `;

            // Insert before the load more button
            const loadMoreSection = loadMoreBtn.parentElement.parentElement;
            loadMoreSection.insertBefore(olderNotificationsContainer, loadMoreSection.querySelector('.text-center'));
        }

        const notificationsList = olderNotificationsContainer.querySelector('.notifications-list');

        // Add new notifications
        notificationsToLoad.forEach(notification => {
            const notificationElement = document.createElement('div');
            notificationElement.className = `notification-item flex items-start space-x-4 p-4 bg-${notification.color}-50 border-l-4 border-${notification.color}-500 rounded-r-lg`;
            notificationElement.setAttribute('data-type', notification.type);

            notificationElement.innerHTML = `
                <div class="flex-shrink-0">
                    <i data-lucide="${notification.icon}" class="w-6 h-6 text-${notification.color}-600"></i>
                </div>
                <div class="flex-1">
                    <p class="text-gray-800 font-medium">${notification.title}</p>
                    <p class="text-sm text-gray-600 mt-1">${notification.message}</p>
                    <p class="text-xs text-gray-500 mt-2">${notification.time}</p>
                </div>
                ${notification.unread ? '<div class="flex-shrink-0"><span class="inline-block w-2 h-2 bg-' + notification.color + '-500 rounded-full unread-indicator"></span></div>' : ''}
            `;

            notificationsList.appendChild(notificationElement);
        });

        // Re-initialize Lucide icons for new elements
        lucide.createIcons();

        // Update unread count
        updateUnreadCount();

        // Increment page
        notificationPage++;

        // Check if there are more notifications
        const remainingNotifications = additionalNotifications.length - (notificationPage - 1) * notificationsPerPage;
        if (remainingNotifications <= 0) {
            loadMoreBtn.textContent = 'Tidak ada notifikasi lagi';
            loadMoreBtn.disabled = true;
            loadMoreBtn.classList.add('opacity-50', 'cursor-not-allowed');
        }
    }

    // Add event listener to load more button
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', loadMoreNotifications);
    }

    // Initialize unread count
    updateUnreadCount();
});
