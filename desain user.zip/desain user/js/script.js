// script.js

document.addEventListener('DOMContentLoaded', () => {
  // Authentication check
  const isLoggedIn = localStorage.getItem('isLoggedIn');
  const userData = JSON.parse(localStorage.getItem('userData') || '{}');

  // Redirect to login if not authenticated
  if (isLoggedIn !== 'true' || !userData.email) {
    window.location.href = 'login.html';
    return;
  }

  // Update user name in profile if available
  const profileNameElement = document.querySelector('#profile-btn span');
  if (profileNameElement && userData.name) {
    profileNameElement.textContent = userData.name;
  }

  // Initialize Lucide icons
  lucide.createIcons();

  // Notification System
  const notificationBtn = document.getElementById('notification-btn');
  const notificationDropdown = document.getElementById('notification-dropdown');
  const notificationBadge = document.getElementById('notification-badge');
  const notificationList = document.getElementById('notification-list');

  // Sample notifications data
  const notifications = [
    {
      id: 1,
      type: 'setoran',
      title: 'Setoran sampah dikonfirmasi!',
      message: '+150 poin telah ditambahkan ke saldo Anda.',
      time: '2 jam yang lalu',
      read: false,
      icon: 'check-circle',
      color: 'green'
    },
    {
      id: 2,
      type: 'penukaran',
      title: 'Penukaran hadiah berhasil',
      message: 'Voucher Belanja Rp 50.000 telah dikirim ke email Anda.',
      time: '4 jam yang lalu',
      read: false,
      icon: 'gift',
      color: 'blue'
    },
    {
      id: 3,
      type: 'level',
      title: 'Selamat! Level up!',
      message: 'Anda naik ke level Eco Warrior. Bonus 500 poin!',
      time: '1 hari yang lalu',
      read: false,
      icon: 'star',
      color: 'purple'
    }
  ];

  // Load statistics from localStorage and update dashboard
  const totalSampahElement = document.getElementById('total-sampah');
  const totalPoinElement = document.getElementById('total-poin');
  const userLevelElement = document.getElementById('user-level');
  const userRankElement = document.getElementById('user-rank');
  const dampakLingkunganElement = document.querySelector('#dampak-lingkungan'); // Dampak Lingkungan card

  // Load total sampah
  let savedTotalSampah = localStorage.getItem('totalSampah');
  if (!savedTotalSampah) {
    savedTotalSampah = '156'; // Connect with feedback data: 156 pieces collected
    localStorage.setItem('totalSampah', savedTotalSampah);
  }
  if (totalSampahElement) {
    totalSampahElement.textContent = savedTotalSampah + ' pcs';
  }

  // Load total poin
  let savedPoin = localStorage.getItem('totalPoin');
  if (!savedPoin) {
    savedPoin = '8625'; // Connect with feedback data: 8,625 points
    localStorage.setItem('totalPoin', savedPoin);
  }
  if (totalPoinElement) {
    totalPoinElement.textContent = parseInt(savedPoin).toLocaleString() + ' pts';
  }

  // Load dampak lingkungan
  let savedDampak = localStorage.getItem('dampakLingkungan');
  if (!savedDampak) {
    savedDampak = '86'; // Calculate environmental impact: ~100 points = 1 tree
    localStorage.setItem('dampakLingkungan', savedDampak);
  }
  if (dampakLingkunganElement) {
    dampakLingkunganElement.textContent = savedDampak + ' pohon';
  }

  // Load user level
  let savedLevel = localStorage.getItem('userLevel');
  if (!savedLevel) {
    savedLevel = '3'; // Default level
    localStorage.setItem('userLevel', savedLevel);
  }
  if (userLevelElement) {
    userLevelElement.textContent = 'Level ' + savedLevel;
  }

  // Load user rank
  let savedRank = localStorage.getItem('userRank');
  if (!savedRank) {
    savedRank = 'Eco Warrior'; // Default rank
    localStorage.setItem('userRank', savedRank);
  }
  if (userRankElement) {
    userRankElement.textContent = savedRank;
  }

  // Load progress statistics
  let setoranBulanIni = localStorage.getItem('setoranBulanIni');
  if (!setoranBulanIni) {
    setoranBulanIni = '15'; // Set default monthly progress
    localStorage.setItem('setoranBulanIni', setoranBulanIni);
  }
  let setoranTahunIni = localStorage.getItem('setoranTahunIni');
  if (!setoranTahunIni) {
    setoranTahunIni = '225'; // Set default yearly progress (75% of 300)
    localStorage.setItem('setoranTahunIni', setoranTahunIni);
  }

  // Update progress bars and text for dashboard
  const progressSetoranBulan = document.getElementById('progress-setoran');
  const progressSetoranTahun = document.getElementById('progress-setoran-tahun');
  const progressTextElements = document.querySelectorAll('.flex.justify-between.mb-2 span:last-child');

  if (progressTextElements.length >= 2) {
    // Setoran Bulan Ini: current / 20 pcs
    progressTextElements[0].textContent = setoranBulanIni + ' / 20 pcs';
    const bulanProgress = Math.min((parseInt(setoranBulanIni) / 20) * 100, 100);
    if (progressSetoranBulan) {
      progressSetoranBulan.style.width = bulanProgress + '%';
    }

    // Setoran Tahun Ini: current / 300 pcs
    progressTextElements[1].textContent = setoranTahunIni + ' / 300 pcs';
    const tahunProgress = Math.min((parseInt(setoranTahunIni) / 300) * 100, 100);
    if (progressSetoranTahun) {
      progressSetoranTahun.style.width = tahunProgress + '%';
    }
  }

  // Profile dropdown toggle
  const profileBtn = document.getElementById('profile-btn');
  const profileDropdown = document.getElementById('profile-dropdown');
  if (profileBtn && profileDropdown) {
    profileBtn.addEventListener('click', () => {
      profileDropdown.classList.toggle('hidden');
    });

    // Close profile dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
        profileDropdown.classList.add('hidden');
      }
    });
  }

  // Plus and minus buttons for setor sampah items
  document.querySelectorAll('.tambah-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const itemName = e.target.getAttribute('data-item');
      const input = document.querySelector(`.jumlah-input[data-item="${itemName}"]`);
      let currentValue = parseInt(input.value) || 0;
      input.value = currentValue + 1;
    });
  });

  document.querySelectorAll('.kurang-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const itemName = e.target.getAttribute('data-item');
      const input = document.querySelector(`.jumlah-input[data-item="${itemName}"]`);
      let currentValue = parseInt(input.value) || 0;
      if (currentValue > 0) {
        input.value = currentValue - 1;
      }
    });
  });

  // Setor Sampah button
  const setorBtn = document.getElementById('setor-btn');
  const setorModal = document.getElementById('setor-modal');
  if (setorBtn && setorModal) {
    setorBtn.addEventListener('click', () => {
      setorModal.classList.remove('hidden');
    });
  }

  // Tukar Saldo button
  const tukarBtn = document.getElementById('tukar-btn');
  const tukarModal = document.getElementById('tukar-modal');
  if (tukarBtn && tukarModal) {
    tukarBtn.addEventListener('click', () => {
      tukarModal.classList.remove('hidden');
    });
  }

  // Lokasi Bank Sampah button
  const lokasiBtn = document.getElementById('lokasi-btn');
  if (lokasiBtn) {
    lokasiBtn.addEventListener('click', () => {
      window.location.href = 'lokasi_bank_sampah.html';
    });
  }

  // Load More button
  const loadMoreBtn = document.getElementById('load-more-btn');
  if (loadMoreBtn) {
    loadMoreBtn.addEventListener('click', () => {
      window.location.href = 'riwayat_transaksi.html';
    });
  }

  // Close Tukar Modal
  const closeTukarModal = document.getElementById('close-tukar-modal');
  if (closeTukarModal && tukarModal) {
    closeTukarModal.addEventListener('click', () => {
      tukarModal.classList.add('hidden');
    });
  }

  // Close Setor Modal
  const closeSetorModal = document.getElementById('close-setor-modal');
  if (closeSetorModal && setorModal) {
    closeSetorModal.addEventListener('click', () => {
      setorModal.classList.add('hidden');
    });
  }

  // Setor Form submission
  const setorForm = document.getElementById('setor-form');
  if (setorForm && totalSampahElement) {

    setorForm.addEventListener('submit', (e) => {
      e.preventDefault();

      // Collect all items with quantities > 0
      const items = [];
      let totalPieces = 0;
      let totalPoints = 0;

      document.querySelectorAll('.jumlah-input').forEach(input => {
        const quantity = parseInt(input.value) || 0;
        if (quantity > 0) {
          const itemName = input.getAttribute('data-item');
          items.push(`${itemName}: ${quantity} pcs`);
          totalPieces += quantity;

          // Calculate points based on item type (simplified)
          let pointsPerPiece = 0;
          if (itemName.includes('Botol Plastik')) {
            pointsPerPiece = 50; // Example points per bottle
          } else if (itemName.includes('Botol Kaca')) {
            pointsPerPiece = 75; // Example points per glass bottle
          } else if (itemName.includes('Kaleng')) {
            pointsPerPiece = 25; // Example points per can
          }
          totalPoints += quantity * pointsPerPiece;
        }
      });

      if (items.length === 0) {
        alert('Silakan pilih setidaknya satu item untuk disetor.');
        return;
      }

      // Update total sampah count
      const currentTotal = parseInt(totalSampahElement.textContent);
      const newTotal = currentTotal + totalPieces;
      totalSampahElement.textContent = newTotal + ' pcs';
      localStorage.setItem('totalSampah', newTotal);

      // Update total poin count
      const currentPoin = parseInt(localStorage.getItem('totalPoin') || '0');
      const newPoin = currentPoin + totalPoints;
      if (totalPoinElement) {
        totalPoinElement.textContent = newPoin.toLocaleString();
      }
      localStorage.setItem('totalPoin', newPoin);

      // Update progress statistics
      let setoranBulanIni = parseInt(localStorage.getItem('setoranBulanIni') || '0');
      let setoranTahunIni = parseInt(localStorage.getItem('setoranTahunIni') || '0');

      setoranBulanIni += totalPieces;
      setoranTahunIni += totalPieces;

      localStorage.setItem('setoranBulanIni', setoranBulanIni.toString());
      localStorage.setItem('setoranTahunIni', setoranTahunIni.toString());

      // Update progress bars and text for dashboard
      const progressSetoranBulan = document.getElementById('progress-setoran');
      const progressSetoranTahun = document.getElementById('progress-setoran-tahun');
      const progressTextElements = document.querySelectorAll('.flex.justify-between.mb-2 span:last-child');

      if (progressTextElements.length >= 2) {
        // Setoran Bulan Ini: current / 20 pcs
        progressTextElements[0].textContent = setoranBulanIni + ' / 20 pcs';
        const bulanProgress = Math.min((setoranBulanIni / 20) * 100, 100);
        if (progressSetoranBulan) {
          progressSetoranBulan.style.width = bulanProgress + '%';
        }

        // Setoran Tahun Ini: current / 300 pcs
        progressTextElements[1].textContent = setoranTahunIni + ' / 300 pcs';
        const tahunProgress = Math.min((setoranTahunIni / 300) * 100, 100);
        if (progressSetoranTahun) {
          progressSetoranTahun.style.width = tahunProgress + '%';
        }
      }

      // Check for milestone achievements and add notifications
      const previousBulanIni = parseInt(localStorage.getItem('setoranBulanIni') || '0') - totalPieces;
      const previousTahunIni = parseInt(localStorage.getItem('setoranTahunIni') || '0') - totalPieces;

      // Monthly target completion notification
      if (previousBulanIni < 20 && setoranBulanIni >= 20) {
        const monthlyAchievementNotification = {
          id: Date.now() + 1,
          type: 'achievement',
          title: 'Target Bulanan Tercapai! 🎉',
          message: 'Selamat! Anda telah mencapai target setoran bulanan 20 pcs.',
          time: 'Baru saja',
          read: false,
          icon: 'trophy',
          color: 'yellow'
        };
        notifications.unshift(monthlyAchievementNotification);
        updateBadge();
        renderNotifications();
        showToast('Pencapaian Hebat!', 'Target setoran bulanan telah tercapai!');
      }

      // Annual target completion notification
      if (previousTahunIni < 300 && setoranTahunIni >= 300) {
        const annualAchievementNotification = {
          id: Date.now() + 2,
          type: 'achievement',
          title: 'Target Tahunan Tercapai! 🏆',
          message: 'Luar biasa! Target setoran tahunan 300 pcs telah berhasil diraih.',
          time: 'Baru saja',
          read: false,
          icon: 'award',
          color: 'purple'
        };
        notifications.unshift(annualAchievementNotification);
        updateBadge();
        renderNotifications();
        showToast('Prestasi Luar Biasa!', 'Target setoran tahunan telah tercapai!');
      }

      // Progress milestone notifications (25%, 50%, 75%)
      const bulanPercentage = Math.floor((setoranBulanIni / 20) * 100);
      const previousBulanPercentage = Math.floor((previousBulanIni / 20) * 100);

      if (bulanPercentage >= 25 && previousBulanPercentage < 25) {
        const progress25Notification = {
          id: Date.now() + 3,
          type: 'progress',
          title: 'Progress Bulanan 25%! 📈',
          message: 'Anda telah mencapai 25% dari target setoran bulanan.',
          time: 'Baru saja',
          read: false,
          icon: 'trending-up',
          color: 'blue'
        };
        notifications.unshift(progress25Notification);
        updateBadge();
        renderNotifications();
      }

      if (bulanPercentage >= 50 && previousBulanPercentage < 50) {
        const progress50Notification = {
          id: Date.now() + 4,
          type: 'progress',
          title: 'Progress Bulanan 50%! 🚀',
          message: 'Hebat! Sudah setengah jalan menuju target bulanan.',
          time: 'Baru saja',
          read: false,
          icon: 'zap',
          color: 'green'
        };
        notifications.unshift(progress50Notification);
        updateBadge();
        renderNotifications();
      }

      if (bulanPercentage >= 75 && previousBulanPercentage < 75) {
        const progress75Notification = {
          id: Date.now() + 5,
          type: 'progress',
          title: 'Progress Bulanan 75%! 🔥',
          message: 'Hampir tercapai! Tinggal sedikit lagi untuk target bulanan.',
          time: 'Baru saja',
          read: false,
          icon: 'flame',
          color: 'orange'
        };
        notifications.unshift(progress75Notification);
        updateBadge();
        renderNotifications();
      }

      // Add transaction to history
      const transactions = JSON.parse(localStorage.getItem('transactions') || '[]');
      const currentDate = new Date();
      const dateStr = `${currentDate.getDate().toString().padStart(2, '0')}/${(currentDate.getMonth() + 1).toString().padStart(2, '0')}/${currentDate.getFullYear()}`;

      // Get the first item as the main item for display
      const mainItem = items[0].split(':')[0].trim();

      const newTransaction = {
        id: Date.now(),
        date: dateStr,
        jenisSampah: mainItem,
        jumlah: totalPieces + ' pcs',
        poin: '+' + totalPoints + ' pts',
        lokasi: 'Bank Sampah A', // Default location
        status: 'Menunggu'
      };

      transactions.unshift(newTransaction); // Add to beginning of array
      localStorage.setItem('transactions', JSON.stringify(transactions));

      // Show success message
      const itemList = items.join(', ');
      alert(`Setoran berhasil dikirim!\n\nItem yang disetor:\n${itemList}\n\nTotal: ${totalPieces} pcs\nAnda mendapatkan +${totalPoints} poin.\n\nMenunggu konfirmasi admin.`);

      // Reset form
      setorForm.reset();
    });
  }

  // Tukar buttons in modal
  if (tukarModal) {
    document.querySelectorAll('#tukar-modal button:not(#close-tukar-modal)').forEach(btn => {
      if (btn.textContent.trim() === 'Tukar') {
        btn.addEventListener('click', () => {
          const hadiahName = btn.parentElement.previousElementSibling.textContent;
          const currentPoin = parseInt(localStorage.getItem('totalPoin') || '0');

          // Set harga untuk setiap hadiah
          let hargaPoin = 0;
          if (hadiahName.includes('Voucher Belanja Rp 50.000')) {
            hargaPoin = 5000;
          } else if (hadiahName.includes('Produk Eco-Friendly')) {
            hargaPoin = 3000;
          }

          // Cek apakah poin cukup
          if (currentPoin < hargaPoin) {
            alert(`Poin tidak cukup! Anda memiliki ${currentPoin} poin, dibutuhkan ${hargaPoin} poin.`);
            return;
          }

          // Kurangi poin
          const newPoin = currentPoin - hargaPoin;
          localStorage.setItem('totalPoin', newPoin);
          if (totalPoinElement) {
            totalPoinElement.textContent = newPoin.toLocaleString();
          }

          // Tambahkan notifikasi penukaran berhasil
          const newNotification = {
            id: Date.now(),
            type: 'penukaran',
            title: 'Penukaran hadiah berhasil!',
            message: `${hadiahName} telah berhasil ditukar dengan ${hargaPoin} poin.`,
            time: 'Baru saja',
            read: false,
            icon: 'gift',
            color: 'blue'
          };

          notifications.unshift(newNotification);
          updateBadge();
          renderNotifications();

          // Show success toast
          showToast('Penukaran Berhasil!', `${hadiahName} telah dikirim ke email Anda.`);

          // Tutup modal
          tukarModal.classList.add('hidden');
        });
      }
    });
  }

  // Progress bar animations - animate both monthly and yearly progress bars
  const progressSetoranBulanAnim = document.getElementById('progress-setoran');
  const progressSetoranTahunAnim = document.getElementById('progress-setoran-tahun');

  if (progressSetoranBulanAnim) {
    // Animate monthly progress bar
    setTimeout(() => {
      const bulanProgress = Math.min((parseInt(setoranBulanIni) / 20) * 100, 100);
      progressSetoranBulanAnim.style.width = bulanProgress + '%';
    }, 500);
  }

  if (progressSetoranTahunAnim) {
    // Animate yearly progress bar
    setTimeout(() => {
      const tahunProgress = Math.min((parseInt(setoranTahunIni) / 300) * 100, 100);
      progressSetoranTahunAnim.style.width = tahunProgress + '%';
    }, 700);
  }

  // Initialize notifications
  function initializeNotifications() {
    const unreadCount = notifications.filter(n => !n.read).length;
    if (unreadCount > 0) {
      notificationBadge.textContent = unreadCount;
      notificationBadge.classList.remove('hidden');
    }

    renderNotifications();
  }

  // Render notifications in dropdown
  function renderNotifications() {
    notificationList.innerHTML = '';

    // Filter notifications based on current filter
    let filteredNotifications = notifications;
    if (currentFilter !== 'all') {
      filteredNotifications = notifications.filter(notification => {
        if (currentFilter === 'setoran') return notification.type === 'setoran';
        if (currentFilter === 'penukaran') return notification.type === 'penukaran';
        if (currentFilter === 'level') return notification.type === 'level';
        if (currentFilter === 'sistem') return notification.type === 'sistem' || notification.type === 'achievement' || notification.type === 'progress';
        return true;
      });
    }

    filteredNotifications.slice(0, 5).forEach(notification => {
      const notificationItem = document.createElement('div');
      notificationItem.className = `p-3 border-b border-gray-100 hover:bg-gray-50 cursor-pointer ${!notification.read ? 'bg-blue-50' : ''}`;
      notificationItem.innerHTML = `
        <div class="flex items-start space-x-3">
          <div class="flex-shrink-0">
            <i data-lucide="${notification.icon}" class="w-5 h-5 text-${notification.color}-600"></i>
          </div>
          <div class="flex-1 min-w-0">
            <p class="text-sm font-medium text-gray-900 truncate">${notification.title}</p>
            <p class="text-sm text-gray-600 truncate">${notification.message}</p>
            <p class="text-xs text-gray-500 mt-1">${notification.time}</p>
          </div>
          ${!notification.read ? '<div class="flex-shrink-0 w-2 h-2 bg-blue-500 rounded-full"></div>' : ''}
        </div>
      `;

      notificationItem.addEventListener('click', () => {
        markAsRead(notification.id);
        showToast(notification.title, notification.message);
      });

      notificationList.appendChild(notificationItem);
    });

    // Show message if no notifications match filter
    if (filteredNotifications.length === 0) {
      const emptyMessage = document.createElement('div');
      emptyMessage.className = 'p-4 text-center text-gray-500 text-sm';
      emptyMessage.textContent = 'Tidak ada notifikasi dalam kategori ini.';
      notificationList.appendChild(emptyMessage);
    }

    // Re-initialize Lucide icons for new elements
    lucide.createIcons();
  }

  // Mark notification as read
  function markAsRead(id) {
    const notification = notifications.find(n => n.id === id);
    if (notification && !notification.read) {
      notification.read = true;
      updateBadge();
      renderNotifications();
    }
  }

  // Update notification badge
  function updateBadge() {
    const unreadCount = notifications.filter(n => !n.read).length;
    if (unreadCount > 0) {
      notificationBadge.textContent = unreadCount;
      notificationBadge.classList.remove('hidden');
    } else {
      notificationBadge.classList.add('hidden');
    }
  }

  // Current filter state
  let currentFilter = 'all';

  // Filter notifications
  function filterNotifications(filter) {
    currentFilter = filter;
    renderNotifications();

    // Update active filter button
    document.querySelectorAll('.filter-btn').forEach(btn => {
      btn.classList.remove('bg-blue-500', 'text-white');
      btn.classList.add('bg-gray-100', 'text-gray-700');
    });

    const activeBtn = document.querySelector(`[data-filter="${filter}"]`);
    if (activeBtn) {
      activeBtn.classList.remove('bg-gray-100', 'text-gray-700');
      activeBtn.classList.add('bg-blue-500', 'text-white');
    }
  }

  // Filter button event listeners
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const filter = e.target.getAttribute('data-filter');
      filterNotifications(filter);
    });
  });

  // Mark all as read button
  const markAllReadBtn = document.getElementById('mark-all-read-btn');
  if (markAllReadBtn) {
    markAllReadBtn.addEventListener('click', () => {
      notifications.forEach(n => n.read = true);
      updateBadge();
      renderNotifications();
      showToast('Berhasil!', 'Semua notifikasi telah ditandai sebagai dibaca.');
    });
  }

  // Clear all notifications button
  const clearAllBtn = document.getElementById('clear-all-btn');
  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', () => {
      if (confirm('Apakah Anda yakin ingin menghapus semua notifikasi?')) {
        notifications.length = 0; // Clear the array
        localStorage.setItem('notifications', JSON.stringify(notifications));
        updateBadge();
        renderNotifications();
        showToast('Berhasil!', 'Semua notifikasi telah dihapus.');
      }
    });
  }

  // Toggle notification dropdown
  if (notificationBtn && notificationDropdown) {
    notificationBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      notificationDropdown.classList.toggle('hidden');

      // Mark all as read when opening dropdown
      notifications.forEach(n => n.read = true);
      updateBadge();
      renderNotifications();
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!notificationBtn.contains(e.target) && !notificationDropdown.contains(e.target)) {
        notificationDropdown.classList.add('hidden');
      }
    });
  }

  // Toast notification system
  function showToast(title, message) {
    // Remove existing toast
    const existingToast = document.querySelector('.toast-notification');
    if (existingToast) {
      existingToast.remove();
    }

    // Create new toast
    const toast = document.createElement('div');
    toast.className = 'toast-notification fixed top-4 right-4 bg-white shadow-lg rounded-lg p-4 border-l-4 border-green-500 z-50 max-w-sm';
    toast.innerHTML = `
      <div class="flex items-start space-x-3">
        <div class="flex-shrink-0">
          <i data-lucide="check-circle" class="w-5 h-5 text-green-600"></i>
        </div>
        <div class="flex-1">
          <p class="text-sm font-medium text-gray-900">${title}</p>
          <p class="text-sm text-gray-600">${message}</p>
        </div>
        <button class="flex-shrink-0 text-gray-400 hover:text-gray-600" onclick="this.parentElement.parentElement.remove()">
          <i data-lucide="x" class="w-4 h-4"></i>
        </button>
      </div>
    `;

    document.body.appendChild(toast);
    lucide.createIcons();

    // Auto remove after 5 seconds
    setTimeout(() => {
      if (toast.parentElement) {
        toast.remove();
      }
    }, 5000);
  }

  // Initialize notifications on page load
  initializeNotifications();

  // Initialize transactions in localStorage if not present
  initializeTransactions();
  function initializeTransactions() {
    const existingTransactions = JSON.parse(localStorage.getItem('transactions') || '[]');
    if (existingTransactions.length === 0) {
      const defaultTransactions = [
        {
          id: 1,
          date: '01/12/2025',
          jenisSampah: 'Botol Plastik Besar',
          jumlah: '10 pcs',
          poin: '+750 pts',
          lokasi: 'Bank Sampah A',
          status: 'Dikonfirmasi'
        },
        {
          id: 2,
          date: '28/11/2025',
          jenisSampah: 'Botol Kaca Besar',
          jumlah: '3 pcs',
          poin: '+900 pts',
          lokasi: 'Bank Sampah A',
          status: 'Dikonfirmasi'
        },
        {
          id: 3,
          date: '25/11/2025',
          jenisSampah: 'Kaleng Sedang',
          jumlah: '5 pcs',
          poin: '+450 pts',
          lokasi: 'Bank Sampah A',
          status: 'Menunggu'
        }
      ];
      localStorage.setItem('transactions', JSON.stringify(defaultTransactions));
    }
  }

  // Load recent transactions from localStorage
  function loadRecentTransactions() {
    const transactionTableBody = document.getElementById('transaction-table');
    const transactions = JSON.parse(localStorage.getItem('transactions') || '[]');

    // Clear existing rows
    transactionTableBody.innerHTML = '';

    // Show only the 3 most recent transactions
    const recentTransactions = transactions.slice(0, 3);

    // Add transactions to table
    recentTransactions.forEach(transaction => {
      const row = document.createElement('tr');
      row.className = 'border-b border-gray-100 hover:bg-gray-50';

      // Get status color and text
      let statusClass = 'bg-yellow-100 text-yellow-800';
      let statusText = 'Menunggu';
      if (transaction.status === 'Dikonfirmasi') {
        statusClass = 'bg-green-100 text-green-800';
        statusText = 'Dikonfirmasi';
      } else if (transaction.status === 'Ditolak') {
        statusClass = 'bg-red-100 text-red-800';
        statusText = 'Ditolak';
      }

      row.innerHTML = `
        <td class="py-3 px-4 text-gray-700">${transaction.date}</td>
        <td class="py-3 px-4 text-gray-700">${transaction.jenisSampah}</td>
        <td class="py-3 px-4 text-gray-700">${transaction.jumlah}</td>
        <td class="py-3 px-4 text-green-600 font-semibold">${transaction.poin}</td>
        <td class="py-3 px-4">
          <span class="px-3 py-1 rounded-full text-sm font-medium ${statusClass}">${statusText}</span>
        </td>
      `;

      transactionTableBody.appendChild(row);
    });

    // If no transactions, show a message
    if (recentTransactions.length === 0) {
      const emptyRow = document.createElement('tr');
      emptyRow.innerHTML = `
        <td colspan="5" class="py-8 px-4 text-center text-gray-500">
          Belum ada transaksi. Mulai setor sampah untuk melihat riwayat di sini.
        </td>
      `;
      transactionTableBody.appendChild(emptyRow);
    }
  }

  // Load recent transactions on page load
  loadRecentTransactions();

  // Add notification when setoran is successful
  const originalSetorFormSubmit = setorForm?.onsubmit;
  if (setorForm) {
    setorForm.addEventListener('submit', (e) => {
      // Add a new notification for successful setoran
      const newNotification = {
        id: Date.now(),
        type: 'setoran',
        title: 'Setoran sampah berhasil dikirim!',
        message: 'Menunggu konfirmasi dari admin.',
        time: 'Baru saja',
        read: false,
        icon: 'plus-circle',
        color: 'green'
      };

      notifications.unshift(newNotification);
      updateBadge();
      renderNotifications();

      // Show toast
      showToast('Setoran Berhasil!', 'Setoran sampah Anda telah dikirim dan menunggu konfirmasi.');
    });
  }
});
