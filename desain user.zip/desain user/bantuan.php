<?php
require_once "recyclean_db/config.php"; // pastikan path file config.php benar

$keyword = isset($_POST['keyword']) ? $_POST['keyword'] : '';
$category = isset($_POST['category']) ? $_POST['category'] : '';
$n = 0;
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bantuan - RECYCLEAN</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
  <link rel="stylesheet" href="style.css">
</head>

<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen font-sans">

  <!-- Header -->
  <header class="bg-white shadow-lg sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex justify-between items-center py-4">
        <div class="flex items-center space-x-3">
          <div class="bg-green-600 p-2 rounded-full">
            <i data-lucide="recycle" class="w-8 h-8 text-white"></i>
          </div>
          <h1 class="text-2xl font-bold text-green-700">RECYCLEAN</h1>
        </div>

        <nav class="hidden md:flex space-x-6">
          <a href="index.html" class="text-gray-700 hover:text-green-600 font-medium">Dashboard</a>
        </nav>

        <div class="flex items-center space-x-4">
          <div class="relative">
            <button id="profile-btn" class="flex items-center space-x-3 hover:bg-gray-100 px-3 py-2 rounded-lg transition-colors">
              <img src="https://i.pravatar.cc/40" class="w-10 h-10 rounded-full border-2 border-green-300" alt="Profile">
              <span class="font-medium text-gray-700">Ani Nuraini</span>
            </button>

            <!-- Profile Dropdown -->
            <div id="profile-dropdown" class="hidden absolute top-full right-0 mt-2 bg-white shadow-lg rounded-lg p-2 w-48 z-40">
              <a href="index.html" class="flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                <i data-lucide="home" class="w-4 h-4"></i>
                <span>Dashboard</span>
              </a>
              <a href="profil.html" class="flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                <i data-lucide="user" class="w-4 h-4"></i>
                <span>Profil Saya</span>
              </a>
              <a href="pengaturan.html" class="flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                <i data-lucide="settings" class="w-4 h-4"></i>
                <span>Pengaturan</span>
              </a>
              <a href="bantuan.html" class="flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                <i data-lucide="help-circle" class="w-4 h-4"></i>
                <span>Bantuan</span>
              </a>
              <hr class="my-2 border-gray-200">
              <a href="keluar.html" class="flex items-center space-x-3 px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                <i data-lucide="log-out" class="w-4 h-4"></i>
                <span>Keluar</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>

  <!-- Main Content -->
  <main class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

    <!-- Help Sections -->
    <div class="space-y-8">

      <!-- Getting Started -->
      <section class="bg-white rounded-xl shadow-lg p-6">
        <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
          <i data-lucide="play-circle" class="w-6 h-6 text-green-600 mr-3"></i>
          Memulai
        </h2>

        <div class="space-y-6">
          <div>
            <h3 class="text-lg font-semibold text-gray-800 mb-2">Cara Menyetor Sampah</h3>
            <ol class="list-decimal list-inside space-y-1 text-gray-600">
              <li>Klik tombol "Setor Sampah" di dashboard</li>
              <li>Pilih jenis sampah (Botol Plastik, Kardus, Kertas Bekas)</li>
              <li>Masukkan berat sampah dalam kg</li>
              <li>Klik "Setor" untuk mengirim</li>
              <li>Tunggu konfirmasi dari admin</li>
            </ol>
          </div>

          <div>
            <h3 class="text-lg font-semibold text-gray-800 mb-2">Cara Menukar Saldo</h3>
            <ol class="list-decimal list-inside space-y-1 text-gray-600">
              <li>Klik tombol "Tukar Saldo" di dashboard</li>
              <li>Pilih hadiah yang diinginkan</li>
              <li>Klik "Tukar" untuk konfirmasi</li>
              <li>Hadiah akan diproses dalam 1-2 hari kerja</li>
            </ol>
          </div>

          <div>
            <h3 class="text-lg font-semibold text-gray-800 mb-2">Melihat Lokasi Bank Sampah</h3>
            <ol class="list-decimal list-inside space-y-1 text-gray-600">
              <li>Klik tombol "Lokasi Bank Sampah" di dashboard</li>
              <li>Lihat peta lokasi bank sampah terdekat</li>
              <li>Gunakan filter untuk mencari berdasarkan jarak</li>
            </ol>
          </div>
        </div>
      </section>

      <!-- Account Management -->
      <section class="bg-white rounded-xl shadow-lg p-6">
        <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
          <i data-lucide="user" class="w-6 h-6 text-blue-600 mr-3"></i>
          Pengelolaan Akun
        </h2>

        <div class="space-y-6">
          <div>
            <h3 class="text-lg font-semibold text-gray-800 mb-2">Mengubah Kata Sandi</h3>
            <ol class="list-decimal list-inside space-y-1 text-gray-600">
              <li>Klik nama profil di header</li>
              <li>Pilih "Pengaturan" dari dropdown</li>
              <li>Cari bagian "Pengaturan Akun"</li>
              <li>Klik "Ubah" pada "Ubah Kata Sandi"</li>
              <li>Masukkan kata sandi lama dan baru</li>
            </ol>
          </div>

          <div>
            <h3 class="text-lg font-semibold text-gray-800 mb-2">Melihat Profil</h3>
            <ol class="list-decimal list-inside space-y-1 text-gray-600">
              <li>Klik nama profil di header</li>
              <li>Pilih "Profil Saya" dari dropdown</li>
              <li>Lihat informasi akun dan riwayat aktivitas</li>
            </ol>
          </div>

          <div>
            <h3 class="text-lg font-semibold text-gray-800 mb-2">Mengatur Notifikasi</h3>
            <ol class="list-decimal list-inside space-y-1 text-gray-600">
              <li>Klik nama profil di header</li>
              <li>Pilih "Pengaturan" dari dropdown</li>
              <li>Cari bagian "Pengaturan Notifikasi"</li>
              <li>Aktifkan/nonaktifkan toggle sesuai keinginan</li>
            </ol>
          </div>
        </div>
      </section>

      <!-- Points and Rewards -->
      <section class="bg-white rounded-xl shadow-lg p-6">
        <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
          <i data-lucide="gift" class="w-6 h-6 text-yellow-600 mr-3"></i>
          Poin dan Hadiah
        </h2>

        <div class="space-y-6">
          <div>
            <h3 class="text-lg font-semibold text-gray-800 mb-2">Cara Mendapatkan Poin</h3>
            <p class="text-gray-600 mb-3">Poin didapatkan dari setoran sampah yang telah dikonfirmasi admin. Berikut tabel konversi:</p>
            <div class="overflow-x-auto">
              <table class="w-full border-collapse border border-gray-300">
                <thead>
                  <tr class="bg-gray-50">
                    <th class="border border-gray-300 px-4 py-2 text-left">Jenis Sampah</th>
                    <th class="border border-gray-300 px-4 py-2 text-left">Poin per kg</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="border border-gray-300 px-4 py-2">Botol Plastik</td>
                    <td class="border border-gray-300 px-4 py-2">300 pts</td>
                  </tr>
                  <tr class="bg-gray-50">
                    <td class="border border-gray-300 px-4 py-2">Kardus</td>
                    <td class="border border-gray-300 px-4 py-2">300 pts</td>
                  </tr>
                  <tr>
                    <td class="border border-gray-300 px-4 py-2">Kertas Bekas</td>
                    <td class="border border-gray-300 px-4 py-2">150 pts</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <h3 class="text-lg font-semibold text-gray-800 mb-2">Menukar Poin dengan Hadiah</h3>
            <ol class="list-decimal list-inside space-y-1 text-gray-600">
              <li>Pastikan saldo poin mencukupi</li>
              <li>Klik "Tukar Saldo" di dashboard</li>
              <li>Pilih hadiah yang diinginkan</li>
              <li>Klik "Tukar" untuk konfirmasi</li>
              <li>Poin akan dikurangkan otomatis</li>
            </ol>
          </div>
        </div>
      </section>

      <!-- Troubleshooting -->
      <section class="bg-white rounded-xl shadow-lg p-6">
        <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
          <i data-lucide="alert-triangle" class="w-6 h-6 text-red-600 mr-3"></i>
          Pemecahan Masalah
        </h2>

        <div class="space-y-4">
          <div class="border-l-4 border-red-500 pl-4">
            <h3 class="font-semibold text-gray-800">Setoran Tidak Dikonfirmasi</h3>
            <p class="text-gray-600">Jika setoran Anda belum dikonfirmasi dalam 24 jam, hubungi admin melalui email atau WhatsApp.</p>
          </div>

          <div class="border-l-4 border-yellow-500 pl-4">
            <h3 class="font-semibold text-gray-800">Lupa Kata Sandi</h3>
            <p class="text-gray-600">Klik "Lupa Kata Sandi" di halaman login atau hubungi support untuk bantuan reset.</p>
          </div>

          <div class="border-l-4 border-blue-500 pl-4">
            <h3 class="font-semibold text-gray-800">Aplikasi Lambat</h3>
            <p class="text-gray-600">Coba refresh halaman atau bersihkan cache browser. Jika masalah berlanjut, hubungi support.</p>
          </div>
        </div>
      </section>

      <!-- Contact Support -->
      <section class="bg-white rounded-xl shadow-lg p-6">
        <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
          <i data-lucide="phone" class="w-6 h-6 text-green-600 mr-3"></i>
          Hubungi Dukungan
        </h2>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div class="flex items-center space-x-3">
            <i data-lucide="mail" class="w-5 h-5 text-gray-600"></i>
            <div>
              <p class="font-semibold text-gray-800">Email</p>
              <p class="text-gray-600">support@recyclean.id</p>
            </div>
          </div>

          <div class="flex items-center space-x-3">
            <i data-lucide="message-circle" class="w-5 h-5 text-gray-600"></i>
            <div>
              <p class="font-semibold text-gray-800">WhatsApp</p>
              <p class="text-gray-600">+62 812-3456-7890</p>
            </div>
          </div>

          <div class="flex items-center space-x-3">
            <i data-lucide="clock" class="w-5 h-5 text-gray-600"></i>
            <div>
              <p class="font-semibold text-gray-800">Jam Operasional</p>
              <p class="text-gray-600">Senin - Jumat: 08:00 - 17:00 WIB</p>
            </div>
          </div>

          <div class="flex items-center space-x-3">
            <i data-lucide="map-pin" class="w-5 h-5 text-gray-600"></i>
            <div>
              <p class="font-semibold text-gray-800">Lokasi</p>
              <p class="text-gray-600">Jl. Hijau Lestari No. 123, Jakarta</p>
            </div>
          </div>
        </div>
      </section>

    </div>

  </main>

  <!-- Footer -->
  <footer class="bg-gray-800 text-white py-8 mt-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
      <p>&copy; 2025 RECYCLEAN. Bersama menjaga bumi.</p>
    </div>
  </footer>

  <script src="script.js"></script>
  <script>
    // Profile dropdown functionality
    document.addEventListener('DOMContentLoaded', function() {
      const profileBtn = document.getElementById('profile-btn');
      const profileDropdown = document.getElementById('profile-dropdown');

      profileBtn.addEventListener('click', function() {
        profileDropdown.classList.toggle('hidden');
      });

      // Close dropdown when clicking outside
      document.addEventListener('click', function(event) {
        if (!profileBtn.contains(event.target) && !profileDropdown.contains(event.target)) {
          profileDropdown.classList.add('hidden');
        }
      });

      // Initialize Lucide icons
      lucide.createIcons();
    });
  </script>
</body>
</html>
