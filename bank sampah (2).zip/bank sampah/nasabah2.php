<?php
require_once 'koneksi.php';

$data=mysqli_query($koneksi, "SELECT * FROM nasabah");
?>
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    
    <!-- LOOPING PHP DI SINI -->
    <?php foreach($data as $d): ?>

    <div class="bg-white shadow-md rounded-xl p-5 border border-gray-200 hover:shadow-lg transition">
        
        <!-- HEADER -->
        <div class="flex items-start justify-between">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600 text-xl">
                    <i class="fa-solid fa-user"></i>
                </div>
                <div>
                    <h3 class="font-semibold text-lg text-gray-800"><?= $d['nama'] ?></h3>
                    <p class="text-sm text-gray-500">ID: <?= $d['id'] ?></p>
                </div>
            </div>

            <!-- BADGE STATUS -->
            <?php if($d['status'] == 'Aktif'): ?>
                <span class="px-3 py-1 text-xs rounded-full bg-green-100 text-green-600 font-semibold">
                    Aktif
                </span>
            <?php else: ?>
                <span class="px-3 py-1 text-xs rounded-full bg-red-100 text-red-600 font-semibold">
                    Nonaktif
                </span>
            <?php endif; ?>
        </div>

        <!-- INFORMASI NASABAH -->
        <div class="mt-4 space-y-2 text-gray-600 text-sm">
            <p><i class="fa-solid fa-location-dot mr-2"></i> <?= $d['alamat'] ?></p>
            <p><i class="fa-solid fa-phone mr-2"></i> <?= $d['nomor'] ?></p>
            <p><i class="fa-solid fa-calendar-days mr-2"></i> Bergabung: <?= $d['bergabung'] ?></p>
        </div>

        <hr class="my-4">

        <!-- INFORMASI SETORAN -->
        <div class="text-sm">
            <p class="font-medium text-gray-700">Total Setoran</p>
            <p class="font-bold text-green-600 text-lg">
                Rp <?= number_format($d['total_setoran'],0,',','.') ?>
            </p>

            <p class="mt-3 font-medium text-gray-700">Sampah Terkumpul</p>
            <p class="font-semibold text-green-600">
                <?= $d['total_sampah'] ?> kg
            </p>

            <p class="mt-3 text-gray-500">
                Transaksi Terakhir:
                <span class="font-medium text-gray-700"><?= $d['last_transaksi'] ?></span>
            </p>
        </div>

        <!-- BUTTON -->
        <div class="flex gap-3 mt-5">
            <a href="edit.php?id=<?= $d['id'] ?>"
                class="flex-1 bg-blue-600 text-white text-center py-2 rounded-lg hover:bg-blue-700 transition">
                <i class="fa-solid fa-pen mr-1"></i> Edit
            </a>

            <a href="detail.php?id=<?= $d['id'] ?>"
                class="flex-1 bg-green-600 text-white text-center py-2 rounded-lg hover:bg-green-700 transition">
                <i class="fa-solid fa-eye mr-1"></i> Detail
            </a>
        </div>

    </div>

    <?php endforeach; ?>
</div>
