<?php
require 'koneksi.php';
$id = $_GET['id'];

$koneksi->query("UPDATE setoran SET status='Selesai' WHERE id='$id'");

header("Location: ?p=setoran");
exit;
?>
