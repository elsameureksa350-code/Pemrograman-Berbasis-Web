<?php
require_once 'koneksi.php';

if (isset($_POST['submit'])) {

    $nama_sampah     = $_POST['nama_sampah'];
    $kategori        = $_POST['kategori'];
    $harga_per_kg    = $_POST['harga_per_kg'];
    $harga_per_pcs   = $_POST['harga_per_pcs'];
    $poin_per_pcs    = $_POST['poin_per_pcs'];
    $created_at      = date("Y-m-d H:i:s");

    // Hitung nilai_total (opsional)
    $nilai_total = $harga_per_pcs * $poin_per_pcs;

    // Query INSERT
    $sql = "INSERT INTO jenis_sampah 
            (nama_sampah, kategori, harga_per_kg, harga_per_pcs, poin_per_pcs, nilai_total, created_at)
            VALUES 
            ('$nama_sampah', '$kategori', '$harga_per_kg', '$harga_per_pcs', '$poin_per_pcs', '$nilai_total', '$created_at')";

    if ($koneksi->query($sql) === TRUE) {
        echo "<script>alert('Data berhasil disimpan!'); window.location.href='?p=jenis_sampah';</script>";
        exit();
    } else {
        echo "Gagal menyimpan data: " . $koneksi->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Kategori Sampah</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container py-4">
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white">
            <h4 class="fw-bold mb-0">Tambah Kategori Sampah</h4>
        </div>

        <div class="card-body">

            <form method="POST">

                <div class="mb-3">
                    <label class="form-label">Nama Sampah</label>
                    <input type="text" name="nama_sampah" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Kategori</label>
                    <select name="kategori" class="form-select" required>
                        <option value="" disabled selected>Pilih kategori</option>
                        <option value="Plastik">Plastik</option>
                        <option value="Kertas">Kertas</option>
                        <option value="Logam">Logam</option>
                        <option value="Kaca">Kaca</option>
                        <option value="Organik">Organik</option>
                        <option value="Elektronik">Elektronik (E-Waste)</option>
                        <option value="Lainnya">Lainnya</option>
                    </select>
                </div>

                <div class="row mb-3">
                    <div class="col">
                        <label class="form-label">Harga per KG</label>
                        <input type="number" name="harga_per_kg" class="form-control" value="0">
                    </div>
                    <div class="col">
                        <label class="form-label">Harga per PCS</label>
                        <input type="number" name="harga_per_pcs" class="form-control" value="0">
                    </div>
                    <div class="col">
                        <label class="form-label">Poin per PCS</label>
                        <input type="number" name="poin_per_pcs" class="form-control" value="0">
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Warna Badge Icon</label>
                    <input type="color" name="warna_badge" class="form-control form-control-color" value="#4CAF50">
                </div>

                <button type="submit" name="submit" class="btn btn-success">
                    <i class="fas fa-save"></i> Simpan
                </button>

                <a href="./?p=jenis_sampah" class="btn btn-secondary">Kembali</a>

            </form>

        </div>
    </div>
</div>

</body>
</html>
