<?php
include "koneksi.php";

$id = $_GET['id'];
$koneksi->query("DELETE FROM setoran WHERE id='$id'");
header("Location: setoran.php");
?>
