<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Penukaran Saldo</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>Penukaran Saldo</h2>
    <form action="proses_penukaran.php" method="POST">
        <div class="mb-3">
            <label>Nasabah</label>
            <select name="nasabah" class="form-control" required>
                <option value="">Pilih Nasabah</option>
                <?php
                $n = $koneksi->query("SELECT * FROM nasabah");
                while($row = $n->fetch_assoc()){
                    echo "<option value='{$row['id']}'>{$row['nama']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Nominal Penukaran</label>
            <input type="number" name="nominal" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Tanggal</label>
            <input type="date" name="tanggal" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Tukar Saldo</button>
    </form>
</div>

</body>
</html>
