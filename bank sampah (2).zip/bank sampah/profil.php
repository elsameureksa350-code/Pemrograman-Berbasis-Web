<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pengguna</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f5f7fa;
        }

        /* Sidebar bawaan */
        .sidebar {
            width: 250px;
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            background: #0068ff;
            padding-top: 60px;
            color: #fff;
        }

        .sidebar h4 {
            padding-left: 20px;
        }

        .sidebar a {
            display: block;
            padding: 12px 20px;
            color: #fff;
            text-decoration: none;
        }

        .sidebar a:hover {
            background: rgba(255, 255, 255, 0.15);
        }

        /* Jarak konten ke sidebar */
        .content-wrapper {
            margin-left: 250px;
            padding: 30px;
        }

        /* Kartu Profil */
        .profile-circle {
            width: 130px;
            height: 130px;
            border-radius: 50%;
            background: #6c63ff;
            color: #fff;
            font-size: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
        }

        .stat-box {
            background: #32a852;
            color: white;
            border-radius: 10px;
            padding: 25px 10px;
            text-align: center;
        }
    </style>
</head>

<body>

    <!-- SIDEBAR -->
    <div class="sidebar">
        <h4>RECYCLEAN</h4>

        <a href="#">Nasabah</a>
        <a href="#">Jenis Sampah</a>
        <a href="#">Setoran</a>
        <a href="#">Penukaran</a>
        <a href="#">Riwayat</a>
        <a href="#">Pengaturan</a>
        <a href="#" class="fw-bold">Profil</a>
    </div>
    <!-- END SIDEBAR -->

    <!-- PAGE CONTENT -->
    <div class="content-wrapper">

        <!-- PROFIL HEADER -->
        <div class="card p-4 mb-4 shadow-sm text-center">
            <div class="profile-circle mb-3">
                AD
            </div>
            <h3 class="mb-1">adel</h3>
            <p class="text-muted mb-1">adelasyafiko@gmail.com</p>
            <p class="text-muted small">Bergabung: 09 Dec 2025 • admin</p>
        </div>

        <!-- STATISTIK -->
        <div class="row g-3 mb-4">
            <div class="col-md-3 col-sm-6">
                <div class="stat-box">
                    <div class="fs-4 fw-bold">1,247</div>
                    <div>Total Nasabah</div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="stat-box">
                    <div class="fs-4 fw-bold">3.2 Ton</div>
                    <div>Sampah Terkumpul</div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="stat-box">
                    <div class="fs-4 fw-bold">Rp 28.5M</div>
                    <div>Total Transaksi</div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="stat-box">
                    <div class="fs-4 fw-bold">156</div>
                    <div>Penukaran Saldo</div>
                </div>
            </div>
        </div>

        <!-- MENU PROFIL + INFORMASI -->
        <div class="row">
            <!-- Menu -->
            <div class="col-lg-4">
                <div class="card p-3 shadow-sm mb-4">
                    <h5 class="mb-3">Menu Profil</h5>

                    <ul class="list-group">
                        <li class="list-group-item"><i class="bi bi-person"></i> Informasi Pribadi</li>
                        <li class="list-group-item"><i class="bi bi-shield-lock"></i> Keamanan Akun</li>
                        <li class="list-group-item"><i class="bi bi-clock"></i> Aktivitas Login</li>
                        <li class="list-group-item"><i class="bi bi-gear"></i> Preferensi</li>
                        <li class="list-group-item text-danger"><i class="bi bi-box-arrow-right"></i> Keluar Akun</li>
                    </ul>
                </div>
            </div>

            <!-- Informasi Pribadi -->
            <div class="col-lg-8">
                <div class="card p-3 shadow-sm mb-4">
                    <h5 class="mb-3">Informasi Pribadi</h5>

                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control mb-3" value="adel">

                    <label class="form-label">Email</label>
                    <input type="email" class="form-control mb-3" value="adelasyafiko@gmail.com">

                    <label class="form-label">Nomor Telepon</label>
                    <input type="text" class="form-control mb-3" value="082141">

                    <button class="btn btn-primary mt-2">Simpan Perubahan</button>
                </div>
            </div>
        </div>

    </div>
    <!-- END PAGE CONTENT -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
