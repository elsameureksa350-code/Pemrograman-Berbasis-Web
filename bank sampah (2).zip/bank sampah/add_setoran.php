<?php
require_once 'koneksi.php';

if (isset($_POST['submit'])) {

    $nama_sampah = $_POST['nama_sampah'];
    $kategori    = $_POST['kategori'];

    // Siapkan default
    $harga_per_kg  = 0;
    $harga_per_pcs = 0;
    $poin_per_pcs  = 0;

    // Jika kategori KG
    if ($kategori == "KG") {
        $harga_per_kg  = !empty($_POST['harga_per_kg']) ? $_POST['harga_per_kg'] : 0;
        $nilai_total   = $harga_per_kg;
    }

    // Jika kategori PCS
    if ($kategori == "PCS") {
        $harga_per_pcs = !empty($_POST['harga_per_pcs']) ? $_POST['harga_per_pcs'] : 0;
        $poin_per_pcs  = !empty($_POST['poin_per_pcs']) ? $_POST['poin_per_pcs'] : 0;

        $nilai_total = $harga_per_pcs * $poin_per_pcs;
    }

    $created_at = date("Y-m-d H:i:s");

    // Query INSERT
    $sql = "INSERT INTO jenis_sampah 
            (nama_sampah, kategori, harga_per_kg, harga_per_pcs, poin_per_pcs, nilai_total, created_at)
            VALUES 
            ('$nama_sampah', '$kategori', '$harga_per_kg', '$harga_per_pcs', '$poin_per_pcs', '$nilai_total', '$created_at')";

    if ($koneksi->query($sql) === TRUE) {
        echo "<script>alert('Data berhasil disimpan!'); window.location.href='?p=jenis_sampah';</script>";
        exit();
    } else {
        echo "Gagal menyimpan data: " . $koneksi->error;
    }
}
?>
