<?php
$p=$_GET['p']??'';

switch($p){
    case 'nasabah': require_once "nasabah.php"; break;
    case 'jenis_sampah': require_once "jenis_sampah.php"; break;
    case 'setoran': require_once "setoran.php"; break;
    case 'penukaran': require_once "penukaran.php"; break;
    case 'riwayat': require_once "riwayat.php"; break;
    case 'pengaturan': require_once "pengaturan.php"; break;
    case 'profil': require_once "profil.php"; break;

    case 'nasabah2': require_once "nasabah2.php"; break;


    case 'add_nasabah': require_once "add_nasabah.php"; break;
    case 'add_jenis_sampah': require_once "add_jenis_sampah.php"; break;
    case 'add_setoran': require_once "add_setoran.php"; break;
    case 'add_penukaran_saldo': require_once "add_penukaran_saldo.php"; break;

    case 'edit_nasabah': require_once "edit_nasabah.php"; break;
    case 'detail': require_once "detail.php"; break;

    case 'update_profil': require_once "update_profil.php"; break;

    case 'proses_setoran': require_once "proses_setoran.php"; break;
    case 'pross_penukaran': require_once "proses_penukaran.php"; break;
    case 'selesai_penukaran': require_once "selesai_penukaran.php"; break;


    
    default: require_once "index.php"; break;
}
?>