<?php
include "koneksi.php";
$data = mysqli_query($koneksi, "SELECT * FROM riwayat_transaksi");


// FILTER
$tgl_mulai  = $_GET['mulai'] ?? "";
$tgl_akhir  = $_GET['akhir'] ?? "";
$jenis      = $_GET['jenis'] ?? "Semua";
$status_q   = $_GET['status'] ?? "Semua";

$where = [];

// Filter Tanggal
if ($tgl_mulai) $where[] = "tanggal >= '$tgl_mulai'";
if ($tgl_akhir) $where[] = "tanggal <= '$tgl_akhir'";

// Filter Jenis
if ($jenis == "Setoran")     $where[] = "jenis='setoran'";
if ($jenis == "Penukaran")   $where[] = "jenis='penukaran'";

// Filter Status
if ($status_q != "Semua")    $where[] = "status='$status_q'";

// Gabungkan where
$filterSQL = "";
if (count($where) > 0) {
    $filterSQL = "WHERE " . implode(" AND ", $where);
}

// QUERY RIWAYAT
$sql = "SELECT r.*, n.nama AS nasabah
        FROM riwayat_transaksi r
        JOIN nasabah n ON n.id = r.nasabah_id
        ORDER BY r.created_at DESC";
$data = $koneksi->query($sql);


// Statistik
$total_setoran = $koneksi->query("SELECT COUNT(*) as jml FROM setoran")->fetch_assoc()['jml'];
$total_penukaran = $koneksi->query("SELECT COUNT(*) as jml FROM penukaran")->fetch_assoc()['jml'];
$total_volume = $koneksi->query("SELECT SUM(berat) as vol FROM setoran")->fetch_assoc()['vol'] ?? 0;
$total_nilai = $koneksi->query("SELECT SUM(total) as ttl FROM setoran")->fetch_assoc()['ttl'] ?? 0;

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Riwayat Transaksi</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<style>
/* Sidebar */
.sidebar {
    width:230px;
    height:100vh;
    background:#0d6efd;
    color:white;
    position:fixed;
    padding:20px;
}

/* Konten lebih dekat sidebar */
.content {
    margin-left:220px !important; /* posisi lebih dekat sidebar */
    padding:20px;
}

/* Wrapper agar tidak terlalu lebar */
.center-wrapper {
    max-width:750px;  /* lebih kecil supaya dekat sidebar */
    margin-left:0;    /* ratakan ke kiri */
}

/* RESPONSIVE: di HP sidebar pindah ke atas */
@media (max-width: 768px) {
    .sidebar {
        position:relative;
        width:100%;
        height:auto;
    }
    .content {
        margin-left:0 !important;
    }
    .center-wrapper {
        max-width:100%;
    }
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h4>RECYCLEAN</h4>
    <div class="menu-item">Nasabah</div>
    <div class="menu-item">Jenis Sampah</div>
    <div class="menu-item">Setoran</div>
    <div class="menu-item">Penukaran</div>
    <div class="menu-item fw-bold">Riwayat</div>
    <div class="menu-item">Pengaturan</div>
    <div class="menu-item">Profil</div>
</div>

<!-- CONTENT -->
<div class="content">
<div class="center-wrapper">

    <h2 class="mb-0">Riwayat Transaksi</h2>
    <p>Lihat semua aktivitas transaksi</p>

    <!-- FILTER -->
    <form class="row g-3 bg-white p-3 rounded shadow-sm" method="GET">

        <div class="col-md-3 col-6">
            <label class="small">Tanggal Mulai</label>
            <input type="date" name="mulai" class="form-control" value="<?= $tgl_mulai ?>">
        </div>

        <div class="col-md-3 col-6">
            <label class="small">Tanggal Akhir</label>
            <input type="date" name="akhir" class="form-control" value="<?= $tgl_akhir ?>">
        </div>

        <div class="col-md-3 col-6">
            <label class="small">Jenis</label>
            <select name="jenis" class="form-control">
                <option value="Semua" <?= $jenis=="Semua"?"selected":"" ?>>Semua</option>
                <option value="Setoran" <?= $jenis=="Setoran"?"selected":"" ?>>Setoran</option>
                <option value="Penukaran" <?= $jenis=="Penukaran"?"selected":"" ?>>Penukaran</option>
            </select>
        </div>

        <div class="col-md-3 col-6">
            <label class="small">Status</label>
            <select name="status" class="form-control">
                <option value="Semua" <?= $status_q=="Semua"?"selected":"" ?>>Semua</option>
                <option value="Selesai" <?= $status_q=="Selesai"?"selected":"" ?>>Selesai</option>
                <option value="Pending" <?= $status_q=="Pending"?"selected":"" ?>>Pending</option>
            </select>
        </div>

        <div class="col-12 mt-2">
            <button class="btn btn-success w-100">Filter</button>
        </div>

    </form>

    <!-- SUMMARY -->
    <div class="row text-center mt-4">

        <div class="col-md-3 col-6 mb-3">
            <div class="card-summary">
                <h6>Total Setoran</h6>
                <h3><?= $total_setoran ?></h3>
            </div>
        </div>

        <div class="col-md-3 col-6 mb-3">
            <div class="card-summary">
                <h6>Total Penukaran</h6>
                <h3><?= $total_penukaran ?></h3>
            </div>
        </div>

        <div class="col-md-3 col-6 mb-3">
            <div class="card-summary">
                <h6>Volume Sampah</h6>
                <h3><?= number_format($total_volume,1) ?> Kg</h3>
            </div>
        </div>

        <div class="col-md-3 col-6 mb-3">
            <div class="card-summary">
                <h6>Nilai Transaksi</h6>
                <h3>Rp <?= number_format($total_nilai) ?></h3>
            </div>
        </div>

    </div>

    <hr class="my-4">

    <!-- LIST TRANSAKSI -->
    <?php while($d = $data->fetch_assoc()): ?>
        <?php
        $warna = $d['jenis']=="setoran" ? "success" : "primary";
        $sign  = $d['jenis']=="setoran" ? "+" : "-";
        ?>

        <div class="transaksi-card <?= $d['jenis']=="penukaran"?"penukaran":"" ?>">
            <b><?= $d['judul'] ?> - <?= $d['nasabah'] ?></b>
            <span class="badge bg-<?= $d['status']=="Selesai"?"success":"warning" ?> badge-status">
                <?= $d['status'] ?>
            </span>

            <br>

            <?php if ($d['jenis']=="setoran"): ?>
                Sampah: <?= $d['berat'] ?> Kg • 
                Total: Rp <?= number_format($d['nilai']) ?><br>
            <?php else: ?>
                Penukaran: Rp <?= number_format($d['nilai']) ?><br>
            <?php endif; ?>

            <small><?= $d['created_at'] ?></small><br>

            <b class="text-<?= $warna ?>">
                <?= $sign ?> Rp <?= number_format($d['nilai']) ?>
            </b>
        </div>

    <?php endwhile; ?>

</div>
</div>

</body>
</html>
