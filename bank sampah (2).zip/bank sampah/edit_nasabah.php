<main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <!--begin::Col-->
              <div class="col-sm-6"><h3 class="mb-0">Dashboard</h3></div>
              <!--end::Col-->
              <!--begin::Col-->
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Theme Customize</li>
                </ol>
              </div>
              <!--end::Col-->
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <!--begin::Col-->
              <div class="col-12">
                <!--begin::Card-->
                <div class="card">
                  <!--begin::Card Header-->
                  <div class="card-header">
                    <!--begin::Card Title-->
                    <form method="POST" action="">
                    <?php
                    require_once 'koneksi.php';
                    $xid = isset($_GET['id']) ? $_GET['id'] : '';

                    if (isset($_POST['Simpan'])) {
                      $nama = $_POST['nama'];
                      $nomor_hp = $_POST['nomor_hp'];
                      $alamat = $_POST['alamat'];
                      $created_at = $_POST['created_at'];
                      $sql = "UPDATE nasabah SET nama='$nama', nomor_hp='$nomor_hp', alamat='$alamat', created_at='$created_at' WHERE id='$xid'";
                      $res = $koneksi->query($sql);
                      if ($res) {
                          echo "<script>window.location.href='?p=nasabah';</script>";
                          exit();
                      } else {
                          echo "Gagal mengupdate data: " . $koneksi->error;
                      }
                    }

                    $sql = "SELECT * FROM nasabah WHERE id='$xid'";
                    $data = $koneksi->query($sql);
                    if ($data) {
                      foreach ($data as $d) {

                        // reset per-row selection
                        $cowo = '';
                        $cewe = '';
                        $ti = '';
                        $si = '';

                        // set gender checked
                        if (isset($d['gender']) && $d['gender'] == 'L') {
                          $cowo = 'checked';
                        } else {
                          $cewe = 'checked';
                        }

                        // set prodi selected
                        if (isset($d['prodi'])) {
                          if ($d['prodi'] == 1) { $ti = 'selected'; }
                          if ($d['prodi'] == 2) { $si = 'selected'; }
                        }

                        // output form fields (values properly quoted)
                        echo "<table class='table table-stripped table-hover table-border'>
                        <tr><td>Nomor Handphone</td><td> <input type='nomor_hp' name='nomor_hp' value='" . htmlspecialchars($d['nomor_hp']) . "' class='form-control'></td></tr>
                        <tr><td>Nama</td><td> <input type='text' name='nama' value='" . htmlspecialchars($d['nama']) . "' class='form-control'></td></tr>
                        <tr><td>Jenis Kelamin</td><td>
                          <label><input type='radio' value='L' name='gender' $cowo> Laki-laki</label>
                          <label class='ms-3'><input type='radio' value='P' name='gender' $cewe> Perempuan</label>
                        </td></tr>
                        <tr><td>Alamat</td><td><textarea name='alamat' class='form-control'>" . htmlspecialchars($d['alamat']) . "</textarea></td></tr>
                        <tr><td>Transaksi Terakhir</td><td><textarea name='created_at' class='form-control'>" . htmlspecialchars($d['created_at']) . "</textarea></td></tr>
                       
                        <tr><td></td><td><input type='submit' class='btn btn-success' value='Simpan' name='Simpan'></td></tr>
                        </table>";
                      }
                    } else {
                      echo "Data tidak ditemukan atau error: " . $koneksi->error;
                    }
                    ?>
                    </form>
                  <a href="./?p=nasabah" class="btn btn-secondary">Back</a>
                    </div>
                  </div>
                  <!--end::Card Footer-->
                </div>
                <!--end::Card-->
                  <!--end::Card Footer-->
                </div>
                <!--end::Card-->
              </div>
              <!--end::Col-->
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>