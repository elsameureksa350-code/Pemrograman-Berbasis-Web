<?php
require_once "koneksi.php";

// Ambil semua data jenis sampah
$data = mysqli_query($koneksi, "SELECT * FROM jenis_sampah ORDER BY id DESC");

// Hitung total kategori
$total_kategori = mysqli_num_rows($data);
?>

<!--begin::App Main-->
<main class="app-main">

    <!--begin::App Content Header-->
    
    <div class="app-content-header">
        <div class="container-fluid">

            <div class="row align-items-center">
                <div class="col-sm-6">
<h2 class="fw-bold" style="color:#355E3B">Jenis Sampah</h2>
                </div>
<div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <div>
                        <a href="./?p=add_jenis_sampah" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Tambah Kategori Sampah
                        </a>
                    </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Data Nasabah</li>
                    </ol>
                </div>
            </div>

        </div>
    </div>
    
    <!--end::App Content Header-->


    <!--begin::App Content-->
    <div class="app-content">
        <div class="container-fluid">

            <div class="card shadow-sm border-0">

<div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
    </div>

    <h6 class="text-muted mb-4">Kelola jenis dan harga sampah</h6>

    <div class="row g-4">

        <?php foreach ($data as $d) : ?>

        <div class="col-md-4 col-lg-3">
            <div class="card-jenis">

                <!-- Icon -->
                    <i class="fas fa-recycle"></i>
                </div>

                <!-- Nama Jenis -->
                <h2 class="fw-bold"><?= $d['nama_sampah'] ?></h2>
                <h6 class="fw-bold"><?= $d['kategori'] ?></h6>

                <hr>

                <!-- Info -->
                <?php if ($d['harga_per_pcs'] > 0): ?>
                    <p class="mb-1">Poin/Pcs: <span class="badge bg-success"><?= $d['poin_per_pcs'] ?> Poin</span></p>
                    <p class="mb-1 text-primary">Total Terkumpul: <strong><?= $d['harga_per_pcs'] ?> Pcs</strong></p>
                    <p class="mb-1 text-success">Nilai Total: <strong><?= $d['harga_per_pcs'] * $d['poin_per_pcs'] ?> Poin</strong></p>
                <?php else: ?>
                    <p class="mb-1">Harga/kg: <span class="badge bg-success">Rp <?= number_format($d['harga_per_kg'],0,',','.') ?></span></p>
                    <p class="mb-1 text-primary">Total Terkumpul: <strong><?= $d['total_kg'] ?> kg</strong></p>
                    <p class="mb-1 text-success">Nilai Total: <strong>Rp <?= number_format($d['total_kg'] * $d['harga_per_kg'],0,',','.') ?></strong></p>
                <?php endif; ?>

                <div class="mt-3">
                    <a href="?p=edit_jenis&id=<?= $d['id'] ?>" class="btn btn-primary w-100">
                        Edit
                    </a>
                </div>
            </div>
        </div>

        <?php endforeach; ?>

    </div>


    </div>
</div>



<!-- FontAwesome -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>

</body>
</html>
