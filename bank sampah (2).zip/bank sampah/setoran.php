<?php
require_once 'koneksi.php';

// AMAN: definisikan semua variabel yang mungkin digunakan
$catatan = ''; // mencegah "undefined variable"
$filter_date = '';

// Jika ada filter tanggal via GET (misal ?tanggal=2025-12-19), gunakan itu.
// Kalau tidak ada, pakai hari ini.
if (isset($_GET['tanggal']) && trim($_GET['tanggal']) !== '') {
    $candidate = trim($_GET['tanggal']);
    // Validasi format YYYY-MM-DD sederhana
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $candidate)) {
        $filter_date = $candidate;
    } else {
        // jika format salah, gunakan today (atau bisa die dengan pesan error)
        $filter_date = date('Y-m-d');
    }
} else {
    $filter_date = date('Y-m-d');
}

// Safety escape (meskipun sudah tervalidasi format tanggal)
$filter_date = $koneksi->real_escape_string($filter_date);

// Ambil semua setoran untuk tanggal tersebut (join untuk nama nasabah & nama sampah)
$sql = "
SELECT s.id, s.nasabah_id, s.sampah_id, s.berat, s.catatan, s.total, s.status, s.created_at,
       n.nama AS nasabah, j.nama_sampah AS sampah
FROM setoran s
LEFT JOIN nasabah n ON s.nasabah_id = n.id
LEFT JOIN jenis_sampah j ON s.sampah_id = j.id
WHERE DATE(s.tanggal) = '$filter_date'
ORDER BY s.id DESC
";

$q = $koneksi->query($sql);
if (!$q) {
    // debug yang ramah: tampilkan error mysql (hanya sementara)
    die("Query gagal: " . $koneksi->error . "<br>SQL: " . htmlspecialchars($sql));
}

// sekarang $q valid, dan $catatan sudah didefinisikan sebelumnya
?>
<!-- HTML bagian atas tetap sama -->
<!-- misal form tambah / header dll -->

<div style="margin-left:20px; padding:20px;">
    <h2>Setoran</h2>
    <p>Kelola setoran sampah nasabah</p>

    <!-- optional: form filter tanggal -->
    <form method="GET" class="mb-3">
        <label>Pilih Tanggal:</label>
        <input type="date" name="tanggal" value="<?= htmlspecialchars($filter_date) ?>">
        <button type="submit" class="btn btn-sm btn-primary">Filter</button>
        <a href="?p=setoran" class="btn btn-sm btn-secondary">Reset</a>
    </form>

    <div class="container mt-5">
        <div>
            <a href="./?p=add_setoran" class="btn btn-primary">
                <i class="fas fa-plus"></i> Tambah Data
            </a>
        </div>

        <!-- form add_setoran tetap diarahkan ke proses_setoran.php -->
        <!-- ... (form kamu di sini jika perlu) ... -->
    </div>

    <hr class="my-4">

    <h4>Daftar Setoran untuk <?= htmlspecialchars($filter_date) ?></h4>

<?php
// Loop hasil query dengan aman
while ($d = $q->fetch_assoc()) {
    // Pastikan field tersedia (fallback)
    $nasabah_name = isset($d['nasabah']) ? $d['nasabah'] : '—';
    $sampah_name  = isset($d['sampah']) ? $d['sampah'] : '—';
    $berat        = isset($d['berat']) ? $d['berat'] : 0;
    $total        = isset($d['total']) ? $d['total'] : 0;
    $status       = isset($d['status']) ? $d['status'] : 'Pending';
    $created_at   = isset($d['created_at']) ? $d['created_at'] : '';
    $catatan_row  = isset($d['catatan']) ? $d['catatan'] : '';
    $id_row       = isset($d['id']) ? $d['id'] : 0;

    $status_color = ($status === "Selesai") ? "success" : "warning";
    ?>
    <div class="card card-setoran p-3 mt-3">
        <b><?= htmlspecialchars($nasabah_name) ?></b>
        <span class="badge bg-<?= $status_color ?> badge-status"><?= htmlspecialchars($status) ?></span>
        <br>
        <?= htmlspecialchars($sampah_name) ?> • <?= htmlspecialchars($berat) ?> kg • Rp<?= number_format((float)$total) ?><br>
        <small><?= htmlspecialchars($created_at) ?></small><br>
        <?php if ($catatan_row !== ''): ?>
            <small>Catatan: <?= nl2br(htmlspecialchars($catatan_row)) ?></small><br>
        <?php endif; ?>

        <a href="update_status.php?id=<?= $id_row ?>" class="btn btn-success btn-sm mt-2">Terima</a>
        <a href="hapus_setoran.php?id=<?= $id_row ?>" class="btn btn-danger btn-sm mt-2">Hapus</a>
    </div>
<?php
} // end while
?>

</div>
