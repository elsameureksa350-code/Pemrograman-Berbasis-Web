<?php
require_once 'koneksi.php';

if (isset($_POST['simpan'])) {
    $id       = $_POST['id'];
    $nama     = $_POST['nama'];
    $alamat   = $_POST['alamat'];
    $nomor_hp = $_POST['nomor_hp'];

    // Jika ID auto increment, hapus saja 'id'
    $sql = "INSERT INTO nasabah (id, nama, alamat, nomor_hp) 
            VALUES ('$id', '$nama', '$alamat', '$nomor_hp')";

    if ($koneksi->query($sql)) {
        echo "<script>window.location.href='?p=nasabah';</script>";
        exit();
    } else {
        echo "Gagal menyimpan data: " . $koneksi->error;
    }
}
?>


<!--begin::App Main-->
      <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <!--begin::Col-->
              <div class="col-sm-6"><h3 class="mb-0">Tambah Nasabah</h3></div>
              <!--end::Col-->
              <!--begin::Col-->
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Theme Customize</li>
                </ol>
              </div>
              <!--end::Col-->
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <!--begin::Col-->
              <div class="col-12">
                <!--begin::Card-->
                <div class="card">
                  <!--begin::Card Header-->
                  <div class="card-header">
                  <form action="" method="post">
                <table class="table">
                  <tr>
                    <td>Id</td>
                    <td><input type="text" name="id" class="form-control" required></td>
                  </tr>
                  <tr>
                    <td>Nama</td>
                    <td><input type="text" name="nama" class="form-control" required></td>
                  </tr>
                  <tr>
                    <td>Alamat</td>
                    <td><input type="text" name="alamat" class="form-control" required></td>
                  </tr>
                  <tr>
                    <td>Nomor Handphone</td>
                    <td><input type="number" name="nomor_hp" class="form-control" required></td>
                  </tr>
                    
                    <td><input type="submit" name="simpan" class="btn btn-success" value="Simpan"></td>
                  </tr>
                </table>
              </form>
                  <!--end::Card Footer-->
                </div>
                <!--end::Card-->
                     <!--end::Card Footer-->
                </div>
                <!--end::Card-->
              </div>
              <!--end::Col-->
            </div>
            <!--end::Row-->
          </div>
          
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>
      <!--end::App Main-->