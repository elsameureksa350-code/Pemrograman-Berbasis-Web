<?php
require_once 'koneksi.php';
$data = mysqli_query($koneksi, "SELECT * FROM nasabah");
?>

<!--begin::App Main-->
<main class="app-main">

    <!--begin::App Content Header-->
    <div class="app-content-header">
        <div class="container-fluid">

            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h3 class="mb-0 fw-bold"><i class="fas fa-users me-2"></i>Data Nasabah</h3>
                </div>

                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Data Nasabah</li>
                    </ol>
                </div>
            </div>

        </div>
    </div>
    <!--end::App Content Header-->


    <!--begin::App Content-->
    <div class="app-content">
        <div class="container-fluid">

            <div class="card shadow-sm border-0">

                <!--begin::Card Header-->
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <div>
                        <a href="./?p=add_nasabah" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Tambah Data
                        </a>
                    </div>

                    <!-- Search Bar -->
                    <form class="d-flex" style="max-width: 300px;">
                        <input class="form-control form-control-sm" type="search" placeholder="Cari nasabah...">
                    </form>
                </div>
                <!--end::Card Header-->


                <!--begin::Card Body-->
                <div class="card-body">

                    <table class="table table-hover table-striped align-middle text-sm">
                        <thead class="table-success text-center">
                            <tr>
                                <th style="width: 5%">No</th>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>Nomor HP</th>
                                <th style="width: 20%">Options</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $n = 0;
                            foreach ($data as $d) {
                                $n++;

                                // Generate badge status

                                echo "
                                <tr>
                                    <td class='text-center'>{$n}</td>
                                    <td class='text-center fw-bold'>{$d['id']}</td>
                                    <td>{$d['nama']}</td>
                                    <td>{$d['alamat']}</td>
                                    <td>{$d['nomor_hp']}</td>

                                    <td class='text-center'>
                                        <a href='?p=detail&id={$d['id']}' class='btn btn-info btn-sm me-1'>
                                            <i class='fas fa-eye'></i> Detail
                                        </a>
                                        <a href='?p=edit_nasabah&id={$d['id']}' class='btn btn-warning btn-sm me-1'>
                                            <i class='fas fa-edit'></i> Edit
                                        </a>
                                        <a href='?p=hapus&id={$d['id']}' 
                                           onclick=\"return confirm('Hapus data nasabah?')\" 
                                           class='btn btn-danger btn-sm'>
                                           <i class='fas fa-trash'></i> Hapus
                                        </a>
                                    </td>
                                </tr>";
                            }
                            ?>
                        </tbody>
                    </table>

                </div>
                <!--end::Card Body-->

            </div>

        </div>
    </div>
    <!--end::App Content-->

</main>
<!--end::App Main-->
