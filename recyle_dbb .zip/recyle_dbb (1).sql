-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for recyclean_dbb
CREATE DATABASE IF NOT EXISTS `recyclean_dbb` /*!40100 DEFAULT CHARACTER SET armscii8 COLLATE armscii8_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `recyclean_dbb`;

-- Dumping structure for table recyclean_dbb.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `email` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `password` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `telepon` varchar(50) CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT NULL,
  `role` varchar(50) COLLATE armscii8_bin DEFAULT 'admin',
  `tanggal_join` datetime DEFAULT NULL,
  `jabatan` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `alamat` text COLLATE armscii8_bin,
  `avatar` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `bergabung` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.admin: ~3 rows (approximately)
INSERT INTO `admin` (`id`, `nama`, `email`, `password`, `telepon`, `role`, `tanggal_join`, `jabatan`, `alamat`, `avatar`, `bergabung`) VALUES
	(1, 'Admin', 'RecyClean@gmail.com', 'adel123', '087654321', 'admin', NULL, 'admin', 'qiwdiqwd', 'awdw', '2025-12-09'),
	(2, 'admin', 'adminrecyclean@gmail.com', 'recyclean', '088888', 'admin', '2025-12-12 02:00:04', 'admin', 'awa', 'admin', '2025-12-12'),
	(3, 'user', 'user@gmail.com', 'user123', '0812121', 'user', '2025-12-12 02:33:34', 'user', 'jadikan', 'user', '2025-12-12');

-- Dumping structure for table recyclean_dbb.hadiah
CREATE TABLE IF NOT EXISTS `hadiah` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_hadiah` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `deskripsi` text CHARACTER SET armscii8 COLLATE armscii8_bin,
  `poin` int DEFAULT NULL,
  `poin_diperlukan` int DEFAULT NULL,
  `stok` int DEFAULT NULL,
  `gambar` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.hadiah: ~4 rows (approximately)
INSERT INTO `hadiah` (`id`, `nama_hadiah`, `deskripsi`, `poin`, `poin_diperlukan`, `stok`, `gambar`, `created_at`) VALUES
	(1, 'TEMPAT SAMPAH', 'untuk menyapu', 10, 100, 2, 'hadiah_1765764817.jpg', NULL),
	(2, 'KESET', 'untuk menyapu', NULL, 100, 2, 'hadiah_1765764762.jpg', NULL),
	(8, 'KEMOCENG', NULL, NULL, 100, 1, 'hadiah_1765764703.jpg', NULL),
	(9, 'Pengki', NULL, NULL, 100, 2, 'hadiah_1765764651.jpg', NULL),
	(10, 'SAPU', NULL, NULL, 100, 2, 'hadiah_1765764583.jpg', NULL);

-- Dumping structure for table recyclean_dbb.harga_sampah
CREATE TABLE IF NOT EXISTS `harga_sampah` (
  `id` int NOT NULL,
  `jenis` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `deskripsi` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `harga_per_pcs` int DEFAULT NULL,
  `icon` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `updated_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.harga_sampah: ~0 rows (approximately)

-- Dumping structure for table recyclean_dbb.jenis_sampah
CREATE TABLE IF NOT EXISTS `jenis_sampah` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_sampah` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `kategori` char(50) COLLATE armscii8_bin DEFAULT NULL,
  `poin_per_pcs` int DEFAULT NULL,
  `harga_per_pcs` int DEFAULT NULL,
  `total_kg` decimal(10,2) DEFAULT NULL,
  `nilai_total` int DEFAULT NULL,
  `gambar` varchar(255) COLLATE armscii8_bin DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `warna_badge` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `harga_per_kg` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.jenis_sampah: ~4 rows (approximately)
INSERT INTO `jenis_sampah` (`id`, `nama_sampah`, `kategori`, `poin_per_pcs`, `harga_per_pcs`, `total_kg`, `nilai_total`, `gambar`, `created_at`, `warna_badge`, `harga_per_kg`) VALUES
	(7, 'BOTOL', 'Plastik', NULL, NULL, NULL, NULL, 'jenis_1765763956_3884.jpeg', '2025-12-14 18:59:16', NULL, 12),
	(8, 'BOTOL', 'Kaca', NULL, NULL, NULL, NULL, 'jenis_1765764032_7850.jpg', '2025-12-14 19:00:32', NULL, 6),
	(9, 'BESI', 'Logam', NULL, NULL, 14.00, NULL, 'jenis_1765764260_9972.jpg', '2025-12-14 19:04:20', NULL, 15),
	(10, 'HVS', 'Kertas', NULL, NULL, NULL, NULL, 'jenis_1765764325_7495.jpg', '2025-12-14 19:05:25', NULL, 9);

-- Dumping structure for table recyclean_dbb.mhs
CREATE TABLE IF NOT EXISTS `mhs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nim` varchar(12) COLLATE utf8mb4_general_ci NOT NULL,
  `nama` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `gender` enum('L','P') COLLATE utf8mb4_general_ci NOT NULL,
  `address` text COLLATE utf8mb4_general_ci NOT NULL,
  `prodi` int NOT NULL,
  `waktu` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table recyclean_dbb.mhs: ~2 rows (approximately)
INSERT INTO `mhs` (`id`, `nim`, `nama`, `gender`, `address`, `prodi`, `waktu`) VALUES
	(1, '244110501005', 'diyaana', 'P', 'semarang', 1, '2025-10-06 08:45:50'),
	(2, '244110501007', 'mawar', 'P', 'purwokerto', 1, '2025-10-26 13:31:19');

-- Dumping structure for table recyclean_dbb.nasabah
CREATE TABLE IF NOT EXISTS `nasabah` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT NULL,
  `alamat` text CHARACTER SET armscii8 COLLATE armscii8_bin,
  `nomor_hp` varchar(50) CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT NULL,
  `gender` enum('L','P') COLLATE armscii8_bin DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `email` varchar(100) COLLATE armscii8_bin DEFAULT NULL,
  `password` varchar(255) COLLATE armscii8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12231 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.nasabah: ~9 rows (approximately)
INSERT INTO `nasabah` (`id`, `nama`, `jenis_kelamin`, `alamat`, `nomor_hp`, `gender`, `created_at`, `email`, `password`) VALUES
	(2, 'rqfwq', 'Perempuan', 'ada', '081241', 'P', '2025-12-12 16:47:00', NULL, NULL),
	(12213, 'aku', NULL, 'afwa', '08214', 'L', '2025-12-17 16:51:00', NULL, NULL),
	(12215, 'nasabahnya', 'Perempuan', 'adada', '08132', 'P', '2025-12-11 18:40:00', 'nasabah@gmail.com', 'nasabah123'),
	(12216, 'Naura', 'Perempuan', 'Jaksel', '0888832143254', 'P', '2025-12-11 19:16:00', 'naurasyp@gmail.com', '123'),
	(12218, 'faris', 'Laki-laki', 'brebes', '082222082206', 'L', '2025-12-11 20:22:00', 'akunsekunder142@gmail.com', 'faris142'),
	(12219, 'Yusuf', 'Laki-laki', 'aa', '088822', 'L', '2025-12-12 01:09:00', 'aa@test.com', '123'),
	(12225, 'kaka', 'Laki-laki', '12412', '081241', 'L', '2025-12-13 02:18:18', '12@gmail.com', '123'),
	(12226, 'Enggal', 'Laki-laki', 'komp', '08124124', 'L', '2025-12-13 02:19:50', 'gal12@gmail.com', '123');

-- Dumping structure for table recyclean_dbb.payout_setting
CREATE TABLE IF NOT EXISTS `payout_setting` (
  `id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `method` enum('Y','N') COLLATE armscii8_bin DEFAULT NULL,
  `nomor_akun` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `nama_akun` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.payout_setting: ~0 rows (approximately)

-- Dumping structure for table recyclean_dbb.pengaturan_laporan
CREATE TABLE IF NOT EXISTS `pengaturan_laporan` (
  `id` int NOT NULL,
  `auto_generated` tinyint DEFAULT NULL,
  `format_laporan` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.pengaturan_laporan: ~0 rows (approximately)

-- Dumping structure for table recyclean_dbb.pengaturan_notifikasi
CREATE TABLE IF NOT EXISTS `pengaturan_notifikasi` (
  `id` int NOT NULL,
  `email_notif` tinyint DEFAULT NULL,
  `sms_notif` tinyint DEFAULT NULL,
  `push_notif` tinyint DEFAULT NULL,
  `email_template` text COLLATE armscii8_bin,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.pengaturan_notifikasi: ~0 rows (approximately)

-- Dumping structure for table recyclean_dbb.pengaturan_umum
CREATE TABLE IF NOT EXISTS `pengaturan_umum` (
  `id` int DEFAULT NULL,
  `nama_aplikasi` varchar(50) CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT NULL,
  `logo` varchar(50) CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT NULL,
  `maintenance` tinyint DEFAULT NULL,
  `auto_backup` tinyint DEFAULT NULL,
  `timezone` varchar(50) CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.pengaturan_umum: ~1 rows (approximately)
INSERT INTO `pengaturan_umum` (`id`, `nama_aplikasi`, `logo`, `maintenance`, `auto_backup`, `timezone`) VALUES
	(NULL, 'RecyClean', '', 0, 1, 'WIB (UTC+7)');

-- Dumping structure for table recyclean_dbb.penukaran
CREATE TABLE IF NOT EXISTS `penukaran` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nasabah_id` int DEFAULT NULL,
  `nominal` decimal(20,6) DEFAULT NULL,
  `bukti` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `status` varchar(50) CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT 'Pending',
  `created_at` datetime DEFAULT NULL,
  `poin_dipakai` int DEFAULT NULL,
  `jenis_penukaran` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `catatan` text COLLATE armscii8_bin,
  PRIMARY KEY (`id`),
  KEY `id_nasabah` (`nasabah_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.penukaran: ~0 rows (approximately)

-- Dumping structure for table recyclean_dbb.penukaran_hadiah
CREATE TABLE IF NOT EXISTS `penukaran_hadiah` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nasabah_id` int DEFAULT NULL,
  `hadiah_id` int DEFAULT NULL,
  `jumlah` int DEFAULT NULL,
  `total_poin` int DEFAULT NULL,
  `bukti` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `status` varchar(50) COLLATE armscii8_bin DEFAULT 'Pending',
  `created_at` datetime DEFAULT NULL,
  `alamat_pengiriman` text COLLATE armscii8_bin,
  `catatan` text COLLATE armscii8_bin,
  PRIMARY KEY (`id`),
  KEY `nasabah_id` (`nasabah_id`),
  KEY `hadiah_id` (`hadiah_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.penukaran_hadiah: ~42 rows (approximately)
INSERT INTO `penukaran_hadiah` (`id`, `nasabah_id`, `hadiah_id`, `jumlah`, `total_poin`, `bukti`, `tanggal`, `status`, `created_at`, `alamat_pengiriman`, `catatan`) VALUES
	(1, 1241, 1, 1, 1000, '', '2025-12-11', 'Pending', '2025-12-11 21:30:31', NULL, NULL),
	(2, 1, 1, 1, 10, NULL, '2025-12-12', 'Selesai', NULL, NULL, NULL),
	(3, 1, 1, 1, 10, NULL, '2025-12-12', 'Selesai', NULL, NULL, NULL),
	(4, 12219, 1, 1, 10, NULL, '2025-12-12', 'Selesai', NULL, NULL, NULL),
	(5, 12219, 1, 10, 100, NULL, '2025-12-12', 'Selesai', NULL, NULL, NULL),
	(6, 12219, 1, 1, 10, NULL, '2025-12-12', 'Selesai', NULL, NULL, NULL),
	(7, 12221, 1, 10, 100, NULL, '2025-12-13', 'Selesai', NULL, NULL, NULL),
	(8, 12226, 1, 2, 20, NULL, '2025-12-13', 'Selesai', NULL, NULL, NULL),
	(9, 12226, 1, 1, 10, NULL, '2025-12-13', 'Selesai', NULL, NULL, NULL),
	(10, 12226, 1, 1, 10, NULL, '2025-12-13', 'Selesai', NULL, 'komp', NULL),
	(11, 12226, 1, 1, 10, NULL, '2025-12-13', 'Menunggu Verifikasi', NULL, 'komp', 'ada'),
	(12, 12226, 1, 1, 10, NULL, '2025-12-13', 'Menunggu Verifikasi', NULL, 'komp', ''),
	(13, 12226, 1, 4, 40, NULL, '2025-12-13', 'Selesai', NULL, 'komp', ''),
	(14, 12226, 1, 3, 30, NULL, '2025-12-13', 'Menunggu Verifikasi', NULL, 'komp', ''),
	(15, 12226, 5, 3, 0, NULL, '2025-12-13', 'Selesai', NULL, 'komp', ''),
	(16, 12226, 1, 1, 10, NULL, '2025-12-13', 'Selesai', NULL, 'komp', ''),
	(17, 12226, 5, 1, 0, NULL, '2025-12-13', 'Selesai', NULL, 'komp', ''),
	(18, 12226, 1, 3, 30, NULL, '2025-12-13', 'Selesai', NULL, 'komp', ''),
	(19, 12226, 1, 1, 10, NULL, '2025-12-13', 'Selesai', NULL, NULL, NULL),
	(20, 12226, 1, 1, 10, NULL, '2025-12-13', 'Selesai', NULL, NULL, NULL),
	(21, 12226, 8, 10, 10000, NULL, '2025-12-13', 'Selesai', NULL, NULL, NULL),
	(22, 12226, 8, 1, 1000, NULL, '2025-12-13', 'Selesai', NULL, NULL, NULL),
	(23, 12226, 9, 1, 10, NULL, '2025-12-13', 'Selesai', NULL, NULL, NULL),
	(24, 12226, 9, 1, 10, NULL, '2025-12-13', 'Selesai', NULL, 'komp', 'ok'),
	(25, 12226, 9, 1, 10, NULL, '2025-12-13', 'Menunggu Verifikasi', NULL, 'komp', ''),
	(26, 12226, 9, 1, 10, NULL, '2025-12-13', 'Menunggu Verifikasi', NULL, 'komp', 'jj'),
	(27, 1, 9, 1, 10, NULL, '2025-12-13', 'Menunggu Verifikasi', NULL, 'fdf', 'ok'),
	(28, 12226, 10, 1, 100, NULL, '2025-12-13', 'Menunggu Verifikasi', NULL, 'komp', ''),
	(29, 12226, 9, 1, 10, NULL, '2025-12-13', 'Menunggu Verifikasi', NULL, 'komp', ''),
	(30, 12226, 10, 1, 100, NULL, '2025-12-13', 'Menunggu Verifikasi', NULL, 'komp kawdkajwbkfjabkfjbawkjfbajfbwkfakjbfjkawbfjkabfkjwbafjabwkjfbakf', 'donasi'),
	(31, 12226, 9, 1, 10, NULL, '2025-12-14', 'Selesai', NULL, 'komp', 'hh'),
	(32, 12226, 10, 3, 300, NULL, '2025-12-14', 'Menunggu Verifikasi', NULL, 'komp', 'h'),
	(33, 12226, 9, 1, 10, NULL, '2025-12-14', 'Selesai', NULL, 'komp', 'wdw'),
	(34, 12226, 9, 1, 10, NULL, '2025-12-14', 'Selesai', NULL, 'komp', ''),
	(35, 12226, 10, 1, 100, NULL, '2025-12-14', 'Menunggu Verifikasi', NULL, 'komp', 'qq'),
	(36, 12226, 10, 1, 100, NULL, '2025-12-14', 'Menunggu Verifikasi', NULL, 'komp', ''),
	(37, 12226, 8, 1, 1000, NULL, '2025-12-14', 'Selesai', NULL, 'komp', 'w'),
	(38, 12226, 10, 1, 100, NULL, '2025-12-14', 'Selesai', NULL, 'komp', 'ok'),
	(39, 12226, 10, 1, 100, NULL, '2025-12-14', 'Menunggu Verifikasi', NULL, 'komp', ''),
	(40, 12226, 10, 1, 100, NULL, '2025-12-15', 'Selesai', NULL, 'komp', 'kesini'),
	(41, 12226, 10, 1, 100, NULL, '2025-12-15', 'Selesai', NULL, 'komp', ''),
	(43, 12226, 10, 1, 100, NULL, '2025-12-15', 'Selesai', NULL, 'komp', ''),
	(44, 12226, 8, 1, 100, NULL, '2025-12-15', 'Selesai', NULL, 'komp', '');

-- Dumping structure for table recyclean_dbb.pickup_address
CREATE TABLE IF NOT EXISTS `pickup_address` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `address` text COLLATE armscii8_bin,
  `latitude` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `longitude` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `is_default` int DEFAULT NULL,
  `created_at` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.pickup_address: ~0 rows (approximately)

-- Dumping structure for table recyclean_dbb.riwayat_backup
CREATE TABLE IF NOT EXISTS `riwayat_backup` (
  `id` int NOT NULL,
  `file_name` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `size_mb` float DEFAULT NULL,
  `total_record` int DEFAULT NULL,
  `status` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.riwayat_backup: ~0 rows (approximately)

-- Dumping structure for table recyclean_dbb.riwayat_transaksi
CREATE TABLE IF NOT EXISTS `riwayat_transaksi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nasabah_id` varchar(50) CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT NULL,
  `jenis` enum('Setoran','Penukaran') COLLATE armscii8_bin DEFAULT NULL,
  `judul` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `berat` decimal(10,2) DEFAULT NULL,
  `nilai` decimal(15,2) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `status` varchar(50) CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nasabah_id` (`nasabah_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.riwayat_transaksi: ~43 rows (approximately)
INSERT INTO `riwayat_transaksi` (`id`, `nasabah_id`, `jenis`, `judul`, `berat`, `nilai`, `tanggal`, `status`, `created_at`) VALUES
	(1, '1', 'Setoran', 'Setoran besi', 1.00, 12.00, '2025-12-11', 'Pending', '2025-12-11 10:33:56'),
	(2, '1', 'Setoran', 'Setoran BOTOL', 1.00, 10.00, '2025-12-11', 'Pending', '2025-12-11 10:34:40'),
	(3, '1', 'Setoran', 'Setoran BOTOL', 1.00, 10.00, '2025-12-11', 'Pending', '2025-12-11 10:44:01'),
	(4, '1', 'Setoran', 'Setoran BOTOL', 1.00, 10.00, '2025-12-11', 'Pending', '2025-12-11 11:18:30'),
	(5, '1', 'Setoran', 'Setoran BOTOL', 11.00, 110.00, '2025-12-11', 'Pending', '2025-12-11 11:21:53'),
	(6, '12216', 'Setoran', 'Setoran BOTOL', 1.00, 10.00, '2025-12-12', 'Pending', '2025-12-11 19:19:50'),
	(7, '12219', 'Setoran', 'Setoran BOTOL', 12.00, 120.00, '2025-12-12', 'Pending', '2025-12-12 01:09:43'),
	(8, '1', 'Setoran', 'Setoran botol', 12.00, 120.00, '2025-12-13', 'Pending', '2025-12-13 00:50:28'),
	(9, '1', 'Setoran', 'Setoran BOTOL', 6.00, 60.00, '2025-12-13', 'Pending', '2025-12-13 00:57:45'),
	(10, '12220', 'Setoran', 'Setoran BOTOL', 12.00, 120.00, '2025-12-13', 'Pending', '2025-12-13 01:00:32'),
	(11, '12220', 'Setoran', 'Setoran botol', 3.00, 30.00, '2025-12-13', 'Pending', '2025-12-13 01:01:15'),
	(12, '12221', 'Setoran', 'Setoran BOTOL', 12.00, 120.00, '2025-12-13', 'Pending', '2025-12-13 01:19:09'),
	(13, '12226', 'Setoran', 'Setoran sterofom', 12.00, 12000.00, '2025-12-13', 'Pending', '2025-12-13 02:33:35'),
	(14, '12226', 'Setoran', 'Setoran sterofom', 1.00, 1000.00, '2025-12-13', 'Pending', '2025-12-13 02:44:47'),
	(15, '12226', 'Setoran', 'Setoran sterofom', 1.00, 1000.00, '2025-12-13', 'Pending', '2025-12-13 06:12:29'),
	(16, '12226', 'Setoran', 'Setoran sterofom', 1.00, 1000.00, '2025-12-13', 'Pending', '2025-12-13 11:01:44'),
	(17, '12226', 'Setoran', 'Setoran botol', 1.00, 10.00, '2025-12-13', 'Pending', '2025-12-13 11:02:35'),
	(18, '12226', 'Setoran', 'Setoran BOTOL', 2.00, 20.00, '2025-12-13', 'Pending', '2025-12-13 11:13:45'),
	(19, '12226', 'Setoran', 'Setoran BOTOL', 5.00, 50.00, '2025-12-14', 'Ditolak', '2025-12-14 00:29:03'),
	(20, '12226', 'Setoran', 'Setoran BOTOL', 12.00, 120.00, '2025-12-14', 'Ditolak', '2025-12-14 05:52:11'),
	(21, '12226', 'Setoran', 'Setoran BOTOL', 1.00, 102.00, '2025-12-14', 'Ditolak', '2025-12-14 06:12:45'),
	(22, '12226', 'Setoran', 'Setoran BOTOL', 1.00, 102.00, '2025-12-14', 'Ditolak', '2025-12-14 06:21:25'),
	(23, '12226', 'Setoran', 'Setoran sterofom', 3.00, 30.00, '2025-12-14', 'Ditolak', '2025-12-14 06:23:32'),
	(24, '12226', 'Setoran', 'Setoran sterofom', 3.00, 30.00, '2025-12-14', 'Ditolak', '2025-12-14 06:24:50'),
	(25, '12226', 'Setoran', 'Setoran BOTOL', 2.00, 204.00, '2025-12-14', 'Ditolak', '2025-12-14 06:36:21'),
	(26, '12226', 'Setoran', 'Setoran BOTOL', 1.00, 10.00, '2025-12-14', 'Ditolak', '2025-12-14 07:00:17'),
	(27, '12226', 'Penukaran', 'Penukaran ere', NULL, 10.00, '2025-12-14', 'Pending', '2025-12-14 08:12:11'),
	(28, '12226', 'Penukaran', 'Penukaran ere', NULL, 10.00, '2025-12-14', 'Pending', '2025-12-14 08:16:24'),
	(29, '12226', 'Setoran', 'Setoran BOTOL', 2.00, 20.00, '2025-12-14', 'Ditolak', '2025-12-14 08:18:15'),
	(30, '12226', 'Setoran', 'Setoran BOTOL', 1.00, 10.00, '2025-12-14', 'Ditolak', '2025-12-14 08:19:28'),
	(31, '12226', 'Penukaran', 'Penukaran sapu botol', NULL, 100.00, '2025-12-14', 'Pending', '2025-12-14 08:25:59'),
	(32, '12226', 'Penukaran', 'Penukaran sapu botol', NULL, 100.00, '2025-12-14', 'Pending', '2025-12-14 08:26:40'),
	(33, '12226', 'Penukaran', 'Penukaran BOTOL W', NULL, 1000.00, '2025-12-14', 'Pending', '2025-12-14 08:26:48'),
	(34, '12226', 'Penukaran', 'Penukaran sapu botol', NULL, 100.00, '2025-12-14', 'Pending', '2025-12-14 09:07:25'),
	(35, '12226', 'Setoran', 'Setoran BOTOL', 1.00, 10.00, '2025-12-14', 'Ditolak', '2025-12-14 09:07:44'),
	(36, '12226', 'Penukaran', 'Penukaran sapu botol', NULL, 100.00, '2025-12-14', 'Pending', '2025-12-14 09:17:30'),
	(37, '12226', 'Setoran', 'Setoran BOTOL', 1.00, 10.00, '2025-12-14', 'Ditolak', '2025-12-14 09:18:13'),
	(38, '12226', 'Penukaran', 'Penukaran sapu botol', NULL, 100.00, '2025-12-15', 'Pending', '2025-12-14 18:18:44'),
	(39, '12226', 'Penukaran', 'Penukaran sapu botol', NULL, 100.00, '2025-12-15', 'Pending', '2025-12-14 18:23:19'),
	(40, '12226', 'Setoran', 'Setoran BOTOL', 1.00, 102.00, '2025-12-15', 'Selesai', '2025-12-14 18:46:21'),
	(41, '12226', 'Penukaran', 'Penukaran sapu botol', NULL, 100.00, '2025-12-15', 'Pending', '2025-12-14 18:46:39'),
	(42, '12226', 'Penukaran', 'Penukaran sapu botol', NULL, 100.00, '2025-12-15', 'Pending', '2025-12-14 18:53:57'),
	(43, '12226', 'Setoran', 'Setoran botol', 12.00, 120.00, '2025-12-15', 'Selesai', '2025-12-14 18:54:09'),
	(44, '12226', 'Setoran', 'Setoran BOTOL', 12.00, 1224.00, '2025-12-15', 'Selesai', '2025-12-14 18:54:24'),
	(45, '12226', 'Setoran', 'Setoran BESI', 1.00, 15.00, '2025-12-15', 'Selesai', '2025-12-14 19:06:22'),
	(46, '12226', 'Setoran', 'Setoran BESI', 1.00, 15.00, '2025-12-15', 'Selesai', '2025-12-14 19:07:40'),
	(47, '12226', 'Penukaran', 'Penukaran KEMOCENG', NULL, 100.00, '2025-12-15', 'Pending', '2025-12-14 19:14:21'),
	(48, '12226', 'Setoran', 'Setoran BESI', 12.00, 180.00, '2025-12-15', 'Selesai', '2025-12-14 19:25:57');

-- Dumping structure for table recyclean_dbb.setoran
CREATE TABLE IF NOT EXISTS `setoran` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nasabah_id` int DEFAULT NULL,
  `sampah_id` int DEFAULT NULL,
  `berat` decimal(10,2) DEFAULT NULL,
  `catatan` text COLLATE armscii8_bin,
  `total` int DEFAULT NULL,
  `bukti` varchar(255) COLLATE armscii8_bin DEFAULT NULL,
  `status` varchar(50) CHARACTER SET armscii8 COLLATE armscii8_bin DEFAULT 'Pending',
  `tanggal` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_nasabah` (`nasabah_id`) USING BTREE,
  KEY `id_sampah` (`sampah_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.setoran: ~36 rows (approximately)
INSERT INTO `setoran` (`id`, `nasabah_id`, `sampah_id`, `berat`, `catatan`, `total`, `bukti`, `status`, `tanggal`, `created_at`) VALUES
	(1, 1, 1, 10.00, 'menunggu', 10, NULL, 'Selesai', NULL, NULL),
	(4, 1241, 3, 5.00, 'kurang berat', 50, '', 'Selesai', '2025-12-11', '2025-12-11 14:29:36'),
	(5, 1, 3, 2.00, 'awda', 20, NULL, 'Selesai', '2025-12-11', '2025-12-11 10:26:35'),
	(6, 1, 2, 1.00, 'ada', 12, NULL, 'Selesai', '2025-12-11', '2025-12-11 10:33:56'),
	(7, 1, 3, 1.00, 'dw', 10, NULL, 'Selesai', '2025-12-11', '2025-12-11 10:34:40'),
	(11, 12213, 3, 1.00, 'ada', 10, '', 'Pending', '2025-12-12', '2025-12-12 02:05:20'),
	(12, 12216, 3, 1.00, 'ada', 10, NULL, 'Selesai', '2025-12-12', '2025-12-11 19:19:50'),
	(13, 12219, 3, 12.00, 'donasi', 120, NULL, 'Selesai', '2025-12-12', '2025-12-12 01:09:43'),
	(14, 1, 1, 12.00, 'donasi', 120, NULL, 'Pending', '2025-12-13', '2025-12-13 00:50:28'),
	(15, 12219, 3, 12.00, 'donasi', 120, '', 'Pending', '2025-12-13', '2025-12-13 07:53:11'),
	(16, 12219, 3, 4.00, 'donasi', 40, 'setoran_1765612585_6516.jpeg', 'Pending', '2025-12-13', '2025-12-13 07:56:25'),
	(17, 1, 3, 6.00, 'dona', 60, NULL, 'Pending', '2025-12-13', '2025-12-13 00:57:45'),
	(18, 12220, 3, 12.00, 'donasi', 120, NULL, 'Pending', '2025-12-13', '2025-12-13 01:00:32'),
	(19, 12220, 1, 3.00, 'kgk', 30, NULL, 'Selesai', '2025-12-13', '2025-12-13 01:01:15'),
	(20, 12221, 3, 12.00, '12', 120, NULL, 'Selesai', '2025-12-13', '2025-12-13 01:19:09'),
	(21, 12226, 4, 12.00, 'donasi', 12000, NULL, 'Selesai', '2025-12-13', '2025-12-13 02:33:35'),
	(22, 12226, 4, 1.00, '12', 1000, 'bukti_1765619087_6422.jpeg', 'Pending', '2025-12-13', '2025-12-13 02:44:47'),
	(23, 12226, 4, 1.00, 'ok', 1000, NULL, 'Selesai', '2025-12-13', '2025-12-13 06:12:29'),
	(24, 12226, 4, 1.00, 'donasi', 1000, NULL, 'Pending', '2025-12-13', '2025-12-13 11:01:44'),
	(25, 12226, 1, 1.00, 'do', 10, NULL, 'Selesai', '2025-12-13', '2025-12-13 11:02:35'),
	(26, 12226, 3, 2.00, 'dooo', 20, 'bukti_1765649625_9831.jpeg', 'Selesai', '2025-12-13', '2025-12-13 11:13:45'),
	(27, 12226, 3, 5.00, 'jj', 50, NULL, 'Pending', '2025-12-14', '2025-12-14 00:29:03'),
	(28, 12226, 3, 12.00, 'dd', 120, 'bukti_1765716731_8790.jpeg', 'Selesai', '2025-12-14', '2025-12-14 05:52:11'),
	(29, 12226, 5, 1.00, '12', 102, NULL, 'Pending', '2025-12-14', '2025-12-14 06:12:45'),
	(30, 12226, 5, 1.00, '12', 102, NULL, 'Pending', '2025-12-14', '2025-12-14 06:21:25'),
	(31, 12226, 4, 3.00, 'tukar duit', 30, 'bukti_1765718612_1392.jpeg', 'Selesai', '2025-12-14', '2025-12-14 06:23:32'),
	(32, 12226, 6, 3.00, 'donasi', 30, 'bukti_1765718690_4470.jpeg', 'Selesai', '2025-12-14', '2025-12-14 06:24:50'),
	(33, 12226, 5, 2.00, 'dodo', 204, 'bukti_1765719381_5435.jpeg', 'Selesai', '2025-12-14', '2025-12-14 06:36:21'),
	(34, 12226, 3, 1.00, '21', 10, NULL, 'Ditolak', '2025-12-14', '2025-12-14 07:00:17'),
	(35, 12226, 3, 2.00, '12', 20, NULL, 'Pending', '2025-12-14', '2025-12-14 08:18:15'),
	(36, 12226, 3, 1.00, '12', 10, 'bukti_1765725568_6843.jpeg', 'Selesai', '2025-12-14', '2025-12-14 08:19:28'),
	(37, 12226, 3, 1.00, '2', 10, NULL, 'Ditolak', '2025-12-14', '2025-12-14 09:07:44'),
	(38, 12226, 3, 1.00, 'wad', 10, NULL, 'Ditolak', '2025-12-14', '2025-12-14 09:18:13'),
	(39, 12226, 5, 1.00, '12', 102, 'bukti_1765763181_6083.jpeg', 'Selesai', '2025-12-15', '2025-12-14 18:46:21'),
	(40, 12226, 1, 12.00, '', 120, NULL, 'Ditolak', '2025-12-15', '2025-12-14 18:54:09'),
	(41, 12226, 5, 12.00, '', 1224, 'bukti_1765763664_5503.jpeg', 'Selesai', '2025-12-15', '2025-12-14 18:54:24'),
	(42, 12226, 9, 1.00, '', 15, 'bukti_1765764382_3651.jpg', 'Selesai', '2025-12-15', '2025-12-14 19:06:22'),
	(43, 12226, 9, 1.00, '', 15, NULL, 'Ditolak', '2025-12-15', '2025-12-14 19:07:40'),
	(44, 12226, 9, 12.00, '', 180, 'bukti_1765765557_4437.jpg', 'Selesai', '2025-12-15', '2025-12-14 19:25:57');

-- Dumping structure for table recyclean_dbb.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int NOT NULL,
  `nama` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `email` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `password` varchar(50) COLLATE armscii8_bin DEFAULT NULL,
  `role` enum('Y','N') COLLATE armscii8_bin DEFAULT NULL,
  `status` enum('Y','N') COLLATE armscii8_bin DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.user: ~0 rows (approximately)

-- Dumping structure for table recyclean_dbb.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` char(10) COLLATE utf8mb4_general_ci NOT NULL,
  `password` char(255) COLLATE utf8mb4_general_ci NOT NULL,
  `level` enum('mhs','dosen','admin') COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table recyclean_dbb.users: ~0 rows (approximately)

-- Dumping structure for table recyclean_dbb.user_aktifitas
CREATE TABLE IF NOT EXISTS `user_aktifitas` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `aktifitas` varchar(255) COLLATE armscii8_bin DEFAULT NULL,
  `ip_address` varchar(150) COLLATE armscii8_bin DEFAULT NULL,
  `device` varchar(100) COLLATE armscii8_bin DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=armscii8 COLLATE=armscii8_bin;

-- Dumping data for table recyclean_dbb.user_aktifitas: ~0 rows (approximately)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
