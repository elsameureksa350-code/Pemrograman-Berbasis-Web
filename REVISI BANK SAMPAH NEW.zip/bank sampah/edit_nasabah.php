<main class="app-main">
  <!--begin::App Content Header-->
  <div class="app-content-header">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6">
          <h3 class="mb-0">Dashboard</h3>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-end">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Theme Customize</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
  <!--end::App Content Header-->

  <!--begin::App Content-->
  <div class="app-content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">

              <form method="POST" action="">
                <?php
                require_once 'koneksi.php';
                $xid = isset($_GET['id']) ? $_GET['id'] : '';

                // ================= PROSES UPDATE =================
                if (isset($_POST['Simpan'])) {
                  $nama       = $koneksi->real_escape_string($_POST['nama']      ?? '');
                  $nomor_hp   = $koneksi->real_escape_string($_POST['nomor_hp']  ?? '');
                  $alamat     = $koneksi->real_escape_string($_POST['alamat']    ?? '');
                  $created_at = $_POST['created_at'] ?? '';
                  $gender_raw = $_POST['gender']      ?? ''; // 'L' atau 'P'

                  // Mapping ke 2 kolom: gender & jenis_kelamin
                  if ($gender_raw === 'L') {
                    $gender_db        = 'L';
                    $jenis_kelamin_db = 'Laki-laki';
                  } elseif ($gender_raw === 'P') {
                    $gender_db        = 'P';
                    $jenis_kelamin_db = 'Perempuan';
                  } else {
                    // default aman kalau input aneh
                    $gender_db        = 'L';
                    $jenis_kelamin_db = 'Laki-laki';
                  }

                  // Formatkan tanggal ke format MySQL
                  if (!empty($created_at)) {
                    $created_at = date('Y-m-d H:i:s', strtotime($created_at));
                  } else {
                    $created_at = date('Y-m-d H:i:s');
                  }

                  $sql = "
                    UPDATE nasabah 
                    SET 
                      nama          = '$nama',
                      nomor_hp      = '$nomor_hp',
                      alamat        = '$alamat',
                      gender        = '$gender_db',
                      jenis_kelamin = '$jenis_kelamin_db',
                      created_at    = '$created_at'
                    WHERE id = '$xid'
                  ";

                  $res = $koneksi->query($sql);
                  if ($res) {
                    echo "<script>window.location.href='?p=nasabah';</script>";
                    exit();
                  } else {
                    echo 'Gagal mengupdate data: ' . $koneksi->error;
                  }
                }

                // ================= AMBIL DATA NASABAH =================
                $sql  = "SELECT * FROM nasabah WHERE id='$xid' LIMIT 1";
                $data = $koneksi->query($sql);

                if ($data && $d = $data->fetch_assoc()) {

                  // Tentukan nilai gender untuk radio dari kolom yang ada
                  $gender_val = $d['gender'] ?? '';

                  if ($gender_val !== 'L' && $gender_val !== 'P') {
                    // Kalau kolom gender kosong tapi jenis_kelamin terisi, mapping balik
                    $jk = $d['jenis_kelamin'] ?? '';
                    if ($jk === 'Laki-laki') {
                      $gender_val = 'L';
                    } elseif ($jk === 'Perempuan') {
                      $gender_val = 'P';
                    }
                  }

                  $cowo = ($gender_val === 'L') ? 'checked' : '';
                  $cewe = ($gender_val === 'P') ? 'checked' : '';

                  // Hindari NULL ke htmlspecialchars
                  $val_nomor_hp = htmlspecialchars($d['nomor_hp']   ?? '');
                  $val_nama     = htmlspecialchars($d['nama']       ?? '');
                  $val_alamat   = htmlspecialchars($d['alamat']     ?? '');

                  echo "
                  <table class='table table-stripped table-hover table-border'>
                    <tr>
                      <td>Nomor Handphone</td>
                      <td>
                        <input type='text' name='nomor_hp' value='{$val_nomor_hp}' class='form-control'>
                      </td>
                    </tr>
                    <tr>
                      <td>Nama</td>
                      <td>
                        <input type='text' name='nama' value='{$val_nama}' class='form-control'>
                      </td>
                    </tr>
                    <tr>
                      <td>Jenis Kelamin</td>
                      <td>
                        <label>
                          <input type='radio' value='L' name='gender' $cowo> Laki-laki
                        </label>
                        <label class='ms-3'>
                          <input type='radio' value='P' name='gender' $cewe> Perempuan
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <td>Alamat</td>
                      <td>
                        <textarea name='alamat' class='form-control'>{$val_alamat}</textarea>
                      </td>
                    </tr>
                    <tr>
                      <td>Transaksi Terakhir</td>
                      <td>
                        <input
                          type='datetime-local'
                          name='created_at'
                          class='form-control'
                          value='" . (!empty($d['created_at']) ? date('Y-m-d\TH:i', strtotime($d['created_at'])) : "") . "'>
                      </td>
                    </tr>
                    <tr>
                      <td></td>
                      <td>
                        <input type='submit' class='btn btn-success' value='Simpan' name='Simpan'>
                      </td>
                    </tr>
                  </table>";
                } else {
                  echo 'Data tidak ditemukan atau error: ' . $koneksi->error;
                }
                ?>
              </form>

              <a href="./?p=nasabah" class="btn btn-secondary mt-2">Back</a>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--end::App Content-->
</main>
