<?php
require_once "koneksi.php";

// Ambil filter
$tgl_mulai  = $_GET['mulai'] ?? "";
$tgl_akhir  = $_GET['akhir'] ?? "";
$jenis      = $_GET['jenis'] ?? "Semua";
$status_q   = $_GET['status'] ?? "Semua";

// Filter dinamis
$where = [];
if ($tgl_mulai) $where[] = "r.tanggal >= '$tgl_mulai'";
if ($tgl_akhir) $where[] = "r.tanggal <= '$tgl_akhir'";

// Jenis di dropdown: "Setoran", "Penukaran", "Semua"
// Di DB bisa tersimpan "Setoran"/"setoran", dst
if ($jenis != "Semua") {
    $where[] = "LOWER(r.jenis) = '" . strtolower($jenis) . "'";
}

// Status mengikuti nilai di kolom r.status
// (Selesai, Pending, Menunggu Verifikasi, Ditolak, dll)
if ($status_q != "Semua") $where[] = "r.status = '$status_q'";

$filterSQL = count($where) > 0 ? "WHERE ".implode(" AND ", $where) : "";

// Query data riwayat
$sql = "SELECT r.*, n.nama AS nasabah
        FROM riwayat_transaksi r
        JOIN nasabah n ON n.id = r.nasabah_id
        $filterSQL
        ORDER BY r.created_at DESC";
$data = $koneksi->query($sql);

// Statistik ringkas
$total_setoran   = $koneksi->query("SELECT COUNT(*) as jml FROM setoran")->fetch_assoc()['jml'] ?? 0;
$total_penukaran = $koneksi->query("SELECT COUNT(*) as jml FROM penukaran_hadiah")->fetch_assoc()['jml'] ?? 0;
$total_volume    = $koneksi->query("SELECT SUM(berat) as vol FROM setoran")->fetch_assoc()['vol'] ?? 0;
$total_nilai     = $koneksi->query("SELECT SUM(total) as ttl FROM setoran")->fetch_assoc()['ttl'] ?? 0;
?>

<!--begin::App Main-->
<main class="app-main">

<!-- Header -->
<div class="app-content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6 fw-bold" style="color:#355E3B"><h3 class="mb-0 fw-bold">Riwayat Transaksi</h3></div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-end">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Riwayat</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<!-- Content -->
<div class="app-content">
  <div class="container-fluid">

    <!-- Filter -->
    <div class="card">
      <div class="card-header">
        <form method="GET">
          <table class="table table-borderless mb-0">
            <tr>
              <td>Tanggal Mulai</td>
              <td><input type="date" name="mulai" class="form-control" value="<?= $tgl_mulai ?>"></td>
              <td>Tanggal Akhir</td>
              <td><input type="date" name="akhir" class="form-control" value="<?= $tgl_akhir ?>"></td>
            </tr>
            <tr>
              <td>Jenis</td>
              <td>
                <select name="jenis" class="form-control">
                  <option value="Semua" <?= $jenis=="Semua"?"selected":"" ?>>Semua</option>
                  <option value="Setoran" <?= $jenis=="Setoran"?"selected":"" ?>>Setoran</option>
                  <option value="Penukaran" <?= $jenis=="Penukaran"?"selected":"" ?>>Penukaran</option>
                </select>
              </td>
              <td>Status</td>
              <td>
                <select name="status" class="form-control">
                  <option value="Semua" <?= $status_q=="Semua"?"selected":"" ?>>Semua</option>
                  <option value="Selesai" <?= $status_q=="Selesai"?"selected":"" ?>>Selesai</option>
                  <option value="Pending" <?= $status_q=="Pending"?"selected":"" ?>>Pending</option>
                  <option value="Menunggu Verifikasi" <?= $status_q=="Menunggu Verifikasi"?"selected":"" ?>>Menunggu Verifikasi</option>
                  <option value="Ditolak" <?= $status_q=="Ditolak"?"selected":"" ?>>Ditolak</option>
                </select>
              </td>
            </tr>
            <tr>
              <td colspan="4" class="text-center">
                <button class="btn btn-success px-5">Terapkan Filter</button>
              </td>
            </tr>
          </table>
        </form>
      </div>
    </div>

    <!-- Statistik -->
    <div class="card mt-3">
      <div class="card-header">
        <h5 class="fw-bold mb-0">Ringkasan Transaksi</h5>
      </div>
      <div class="card-body">
        <table class="table table-bordered text-center">
          <tr class="table-success">
            <th>Total Setoran</th>
            <th>Total Penukaran</th>
            <th>Volume Sampah</th>
            <th>Nilai Transaksi</th>
          </tr>
          <tr>
            <td><?= $total_setoran ?></td>
            <td><?= $total_penukaran ?></td>
            <td><?= number_format($total_volume,1) ?> Kg</td>
            <td>Rp <?= number_format($total_nilai) ?></td>
          </tr>
        </table>
      </div>
    </div>

    <!-- Daftar Riwayat -->
    <div class="card mt-3">
      <div class="card-header">
        <h5 class="fw-bold mb-0">Daftar Riwayat Transaksi</h5>
      </div>
      <div class="card-body">
        <?php if ($data->num_rows > 0): ?>
        <table class="table table-bordered table-striped">
          <thead class="table-success">
            <tr>
              <th width="50">No</th>
              <th>Nasabah</th>
              <th>Jenis</th>
              <th>Judul</th>
              <th>Nilai</th>
              <th>Status</th>
              <th>Tanggal</th>
            </tr>
          </thead>
          <tbody>
            <?php $no=1; while($d = $data->fetch_assoc()): ?>
            <?php
              // Tentukan warna badge status
              $status = $d['status'];
              if ($status == 'Selesai') {
                  $status_color = 'success';
              } elseif ($status == 'Ditolak') {
                  $status_color = 'danger';
              } elseif ($status == 'Pending' || $status == 'Menunggu Verifikasi') {
                  $status_color = 'warning';
              } else {
                  $status_color = 'secondary';
              }
            ?>
            <tr>
              <td><?= $no++ ?></td>
              <td><?= htmlspecialchars($d['nasabah']) ?></td>
              <td class="text-capitalize"><?= $d['jenis'] ?></td>
              <td><?= htmlspecialchars($d['judul']) ?></td>
              <td>
                <?php if (strtolower($d['jenis'])=="setoran"): ?>
                  <!-- Setoran: poin bertambah -->
                  <span class="text-success fw-bold">+ <?= number_format($d['nilai']) ?> Poin</span>
                <?php else: ?>
                  <!-- Penukaran: poin berkurang -->
                  <span class="text-danger fw-bold">- <?= number_format($d['nilai']) ?> Poin</span>
                <?php endif; ?>
              </td>
              <td>
                <span class="badge bg-<?= $status_color ?>">
                  <?= $status ?>
                </span>
              </td>
              <td><?= date('d/m/Y', strtotime($d['created_at'])) ?></td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
        <?php else: ?>
          <div class="alert alert-info mb-0">Belum ada transaksi ditemukan.</div>
        <?php endif; ?>
      </div>
    </div>

  </div>
</div>
</main>

<!-- Aktifkan layout fixed AdminLTE supaya sidebar tetap saat scroll -->
<script>
  document.addEventListener('DOMContentLoaded', function () {
    // Untuk AdminLTE 3: pakai class layout-fixed + sidebar-mini
    document.body.classList.add('layout-fixed', 'sidebar-mini');

    // Untuk AdminLTE 4: beberapa template pakai data-lte-layout
    document.body.setAttribute('data-lte-layout', 'fixed');
  });
</script>
