<?php
require_once "koneksi.php";

$filter_date = isset($_GET['tanggal']) && $_GET['tanggal'] != '' 
    ? $_GET['tanggal'] 
    : date('Y-m-d');

$sql = "
SELECT p.id, p.nasabah_id, p.hadiah_id, p.jumlah, p.total_poin, p.alamat_pengiriman, p.status, p.tanggal,
n.nama AS nasabah, h.nama_hadiah AS hadiah
FROM penukaran_hadiah p
LEFT JOIN nasabah n ON p.nasabah_id = n.id
LEFT JOIN hadiah h ON p.hadiah_id = h.id
WHERE DATE(p.tanggal) = '$filter_date'
ORDER BY p.id DESC
";
$q = $koneksi->query($sql);
?>

<main class="app-main">
<div class="app-content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6 fw-bold" style="color:#355E3B">
        <h3 class="mb-0 fw-bold">Penukaran Hadiah</h3>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-end">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Penukaran Hadiah</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<div class="app-content">
  <div class="container-fluid">
    <div class="card shadow-sm">
      <div class="card-header bg-light">
        <form method="GET" class="row g-3 align-items-center">
          <div class="col-auto">
            <label for="tanggal" class="col-form-label fw-bold">Pilih Tanggal</label>
          </div>
          <div class="col-auto">
            <input 
              type="date" 
              id="tanggal"
              name="tanggal" 
              class="form-control" 
              value="<?= htmlspecialchars($filter_date ?? '') ?>">
          </div>
          <div class="col-auto">
            <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
            <a href="?p=penukaran_hadiah" class="btn btn-secondary"><i class="fas fa-undo"></i> Reset</a>
          </div>
          <div class="col-auto ms-auto">
            <a href="./?p=add_penukaran_hadiah" class="btn btn-success">
              <i class="fas fa-gift"></i> Tambah Penukaran
            </a>
          </div>
        </form>
      </div>

      <div class="card-body">
        <h5 class="fw-bold mb-3">
          Daftar Penukaran (<?= htmlspecialchars($filter_date ?? '') ?>)
        </h5>

        <?php if ($q && $q->num_rows > 0): ?>
        <div class="table-responsive">
          <table class="table table-striped table-bordered align-middle text-center">
            <thead class="table-success">
              <tr>
                <th>No</th>
                <th>Nasabah</th>
                <th>Hadiah</th>
                <th>Jumlah</th>
                <th>Total Poin</th>
                <th>Alamat</th>
                <th>Status</th>
                <th>Tanggal</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
            <?php 
              $no = 1;
              while ($d = $q->fetch_assoc()):
                $status_color = match($d['status']) {
                  'Selesai' => 'success',
                  'Ditolak' => 'danger',
                  default => 'warning'
                };
            ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($d['nasabah'] ?? '') ?></td>
                <td><?= htmlspecialchars($d['hadiah'] ?? '') ?></td>
                <td><?= htmlspecialchars($d['jumlah'] ?? '0') ?> item</td>
                <td><?= htmlspecialchars($d['total_poin'] ?? '0') ?></td>
                <td><?= htmlspecialchars($d['alamat_pengiriman'] ?? '') ?></td>
                
                <td><span class="badge bg-<?= $status_color ?>"><?= htmlspecialchars($d['status'] ?? 'Pending') ?></span></td>
                <td><small><?= htmlspecialchars($d['tanggal'] ?? '') ?></small></td>
                <td>
                  <a href="?p=update_penukaran_hadiah&id=<?= (int)$d['id'] ?>" class="btn btn-success btn-sm mb-1">
                    <i class="fas fa-check"></i> Selesai
                  </a><br>
                  <a href="?p=delete_penukaran_hadiah&id=<?= (int)$d['id'] ?>" 
                     class="btn btn-danger btn-sm"
                     onclick="return confirm('Yakin ingin menghapus penukaran ini?')">
                    <i class="fas fa-trash"></i> Hapus
                  </a>
                </td>
              </tr>
            <?php endwhile; ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
          <div class="alert alert-info text-center">Belum ada penukaran pada tanggal ini.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</main>
