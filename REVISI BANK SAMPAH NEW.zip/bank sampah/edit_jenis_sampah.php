<?php
require_once "koneksi.php";

// Pastikan ID dikirim
if (!isset($_GET['id'])) {
    echo "<script>alert('ID tidak ditemukan!'); window.location.href='?p=jenis_sampah';</script>";
    exit();
}

$id = $_GET['id'];

// Ambil data sesuai ID
$query = mysqli_query($koneksi, "SELECT * FROM jenis_sampah WHERE id='$id'");
$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "<script>alert('Data tidak ditemukan!'); window.location.href='?p=jenis_sampah';</script>";
    exit();
}

if (isset($_POST['update'])) {

    $nama_sampah   = $_POST['nama_sampah'];
    $kategori      = $_POST['kategori'];
    $harga_per_kg  = $_POST['harga_per_kg'];
    $gambar_lama   = $_POST['gambar_lama'];

    // ------ Upload Gambar (jika ada yang baru) ------
    $gambar_baru = $gambar_lama;

    if (!empty($_FILES['gambar']['name'])) {
        $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
        $nama_file_baru = 'jenis_' . time() . '_' . rand(1000, 9999) . '.' . $ext;

        $folder_upload = 'uploads/jenis_sampah/';
        if (!is_dir($folder_upload)) {
            mkdir($folder_upload, 0777, true);
        }

        $tujuan = $folder_upload . $nama_file_baru;

        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $tujuan)) {
            // hapus gambar lama jika ada
            if (!empty($gambar_lama) && file_exists($folder_upload . $gambar_lama)) {
                unlink($folder_upload . $gambar_lama);
            }
            $gambar_baru = $nama_file_baru;
        }
    }
    // ------------------------------------------------

    $sql = "UPDATE jenis_sampah SET
                nama_sampah   = '$nama_sampah',
                kategori      = '$kategori',
                harga_per_kg  = '$harga_per_kg',
                gambar        = '$gambar_baru'
            WHERE id = '$id'";

    if ($koneksi->query($sql)) {
        echo "<script>alert('Data berhasil diperbarui!'); window.location.href='?p=jenis_sampah';</script>";
        exit();
    } else {
        echo "Gagal mengupdate data: " . $koneksi->error;
    }
}
?>

<main class="app-main">

<div class="app-content-header">
    <div class="container-fluid">

        <div class="row">
            <div class="col-sm-6">
                <h3 class="mb-0">Edit Jenis Sampah</h3>
            </div>

            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="./?p=jenis_sampah">Jenis Sampah</a></li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </div>
        </div>

    </div>
</div>

<div class="app-content">
    <div class="container-fluid">

        <div class="card">
            <div class="card-header">

                <form action="" method="post" enctype="multipart/form-data">
                <table class="table">

                    <tr>
                        <td>Nama Sampah</td>
                        <td>
                            <input type="text" name="nama_sampah" class="form-control"
                                   value="<?= $data['nama_sampah'] ?>" required>
                        </td>
                    </tr>

                    <tr>
                        <td>Kategori</td>
                        <td>
                            <select name="kategori" class="form-control" required>
                                <option value="Plastik"    <?= $data['kategori']=='Plastik'?'selected':'' ?>>Plastik</option>
                                <option value="Kertas"     <?= $data['kategori']=='Kertas'?'selected':'' ?>>Kertas</option>
                                <option value="Logam"      <?= $data['kategori']=='Logam'?'selected':'' ?>>Logam</option>
                                <option value="Kaca"       <?= $data['kategori']=='Kaca'?'selected':'' ?>>Kaca</option>
                                <option value="Organik"    <?= $data['kategori']=='Organik'?'selected':'' ?>>Organik</option>
                                <option value="Elektronik" <?= $data['kategori']=='Elektronik'?'selected':'' ?>>Elektronik</option>
                                <option value="Lainnya"    <?= $data['kategori']=='Lainnya'?'selected':'' ?>>Lainnya</option>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <td>Harga per KG</td>
                        <td>
                            <input type="number" name="harga_per_kg" class="form-control"
                                   value="<?= $data['harga_per_kg'] ?>">
                        </td>
                    </tr>

                    <tr>
                        <td>Gambar Saat Ini</td>
                        <td>
                            <?php if (!empty($data['gambar'])): ?>
                                <img src="uploads/jenis_sampah/<?= $data['gambar'] ?>" 
                                     alt="<?= $data['nama_sampah'] ?>" 
                                     style="max-width:150px; height:auto;" class="mb-2">
                            <?php else: ?>
                                <span class="text-muted">Belum ada gambar</span>
                            <?php endif; ?>

                            <input type="hidden" name="gambar_lama" value="<?= $data['gambar'] ?>">
                            <br>
                            <label class="form-label mt-2">Ganti Gambar (opsional)</label>
                            <input type="file" name="gambar" class="form-control" accept="image/*">
                        </td>
                    </tr>

                    <tr>
                        <td colspan="2">
                            <input type="submit" name="update" class="btn btn-success" value="Update">
                            <a href="./?p=jenis_sampah" class="btn btn-secondary">Kembali</a>
                        </td>
                    </tr>

                </table>
                </form>

            </div>
        </div>

    </div>
</div>

</main>
