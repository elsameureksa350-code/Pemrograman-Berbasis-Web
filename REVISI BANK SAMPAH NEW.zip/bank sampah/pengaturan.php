<?php
include "koneksi.php";

// Ambil data pengaturan
$q = $koneksi->query("SELECT * FROM pengaturan_umum LIMIT 1");
$set = $q->fetch_assoc();

// Jika belum ada data, buat default
if (!$set) {
    $koneksi->query("INSERT INTO pengaturan_umum VALUES (
        NULL,'RecyClean','',0,1,'WIB (UTC+7)'
    )");
    $set = [
        "nama_aplikasi"=>"RecyClean",
        "logo"=>"",
        "maintenance"=>0,
        "auto_backup"=>1,
        "timezone"=>"WIB (UTC+7)"
    ];
}

// Simpan perubahan
if (isset($_POST['simpan'])) {

    $nama   = $_POST['nama'];
    $tz     = $_POST['timezone'];
    $maint  = isset($_POST['maintenance']) ? 1 : 0;
    $backup = isset($_POST['backup']) ? 1 : 0;

    // Upload Logo
    $logo = $set['logo'];
    if (!empty($_FILES['logo']['name'])) {
        $file = "logo_" . time() . ".png";
        move_uploaded_file($_FILES['logo']['tmp_name'], "upload/".$file);
        $logo = $file;
    }

    $koneksi->query("
        UPDATE pengaturan SET
        nama_aplikasi='$nama',
        logo='$logo',
        maintenance=$maint,
        auto_backup=$backup,
        timezone='$tz'
    ");

    header("Location: pengaturan.php?sukses=1");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Pengaturan</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

<style>
/* SIDEBAR */
.sidebar {
    width:230px;
    height:100vh;
    background:#0d6efd;
    color:white;
    position:fixed;
    padding:20px;
}

.sidebar .menu-item {
    padding:10px 5px;
    border-radius:6px;
    cursor:pointer;
    opacity:.9;
}

.sidebar .menu-item.active {
    background:white;
    color:#0d6efd;
    font-weight:bold;
}

.sidebar .menu-item:hover {
    background:rgba(255,255,255,0.2);
}

/* CONTENT */
.content {
    margin-left:250px;
    padding:20px;
}

/* CARD WRAPPER */
.setting-wrapper {
    background:#fff;
    padding:20px;
    border-radius:10px;
    max-width:900px;
}

/* RESPONSIVE */
@media(max-width:768px){
    .sidebar {
        width:100%;
        height:auto;
        position:relative;
    }
    .content {
        margin-left:0;
    }
    .setting-wrapper {
        max-width:100%;
    }
}
</style>

</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h4 class="mb-4">RECYCLEAN</h4>

    <div class="menu-item">Nasabah</div>
    <div class="menu-item">Jenis Sampah</div>
    <div class="menu-item">Setoran</div>
    <div class="menu-item">Penukaran</div>
    <div class="menu-item">Riwayat</div>

    <div class="menu-item active">Pengaturan</div>

    <div class="menu-item">Profil</div>
</div>

<!-- CONTENT -->
<div class="content">
    <h2 class="mb-0">Pengaturan</h2>
    <p>Kelola konfigurasi sistem RecyClean</p>

    <div class="d-flex gap-3">

        <!-- MENU PENGATURAN -->
        <div style="width:220px;">
            <div class="list-group">

                <a class="list-group-item list-group-item-action active">
                    Umum
                </a>

                <a class="list-group-item list-group-item-action">Harga Sampah</a>
                <a class="list-group-item list-group-item-action">Notifikasi</a>
                <a class="list-group-item list-group-item-action">Backup Data</a>
                <a class="list-group-item list-group-item-action">Manajemen Pengguna</a>
                <a class="list-group-item list-group-item-action">Laporan</a>

            </div>
        </div>

        <!-- FORM PENGATURAN -->
        <div class="setting-wrapper flex-fill">

            <?php if(isset($_GET['sukses'])): ?>
            <div class="alert alert-success">Perubahan berhasil disimpan!</div>
            <?php endif; ?>

            <h4 class="mb-3">Pengaturan Umum</h4>

            <form method="POST" enctype="multipart/form-data">

                <!-- NAMA APLIKASI -->
                <label>Nama Aplikasi</label>
                <input type="text" class="form-control mb-3" name="nama" value="<?= $set['nama_aplikasi'] ?>">

                <!-- LOGO APLIKASI -->
                <label>Logo Aplikasi</label><br>

                <?php if($set['logo']!=""): ?>
                    <img src="upload/<?= $set['logo'] ?>" height="40" class="mb-2"><br>
                <?php endif ?>

                <input type="file" name="logo" class="form-control mb-3">

                <!-- SWITCH -->
                <div class="d-flex align-items-center mb-3">
                    <label class="me-3">Mode Maintenance</label>
                    <input type="checkbox" name="maintenance" <?= $set['maintenance']?'checked':'' ?>>
                </div>

                <div class="d-flex align-items-center mb-3">
                    <label class="me-5">Auto Backup</label>
                    <input type="checkbox" name="backup" <?= $set['auto_backup']?'checked':'' ?>>
                </div>

                <!-- TIMEZONE -->
                <label>Timezone</label>
                <select name="timezone" class="form-control mb-3">
                    <option <?= $set['timezone']=="WIB (UTC+7)"?"selected":"" ?>>WIB (UTC+7)</option>
                    <option <?= $set['timezone']=="WITA (UTC+8)"?"selected":"" ?>>WITA (UTC+8)</option>
                    <option <?= $set['timezone']=="WIT (UTC+9)"?"selected":"" ?>>WIT (UTC+9)</option>
                </select>

                <button class="btn btn-success px-4" name="simpan">Simpan Perubahan</button>

            </form>

        </div>

    </div>
</div>

</body>
</html>
