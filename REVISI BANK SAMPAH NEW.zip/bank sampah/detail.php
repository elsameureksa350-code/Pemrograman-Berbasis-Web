<main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <!--begin::Col-->
              <div class="col-sm-6"><h3 class="mb-0">Dashboard</h3></div>
              <!--end::Col-->
              <!--begin::Col-->
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Theme Customize</li>
                </ol>
              </div>
              <!--end::Col-->
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <!--begin::Col-->
              <div class="col-12">
                <!--begin::Card-->
                <div class="card">
                  <!--begin::Card Header-->
                  <div class="card-header">
                    <!--begin::Card Title-->
                  <?php
                  require_once 'koneksi.php';
                  $xid=$_GET['id'];
                  $sql ="select * from nasabah where id='$xid'";
                  $data=$koneksi->query($sql);
                  foreach ($data as $d){ 

                    switch ($d['nama']){
                      case 1: $nasabah='Teknik Informatika'; break;
                      case 2: $nasabah='Sistem Informasi'; break;
                      default: $nasabah='-'; break;
                    }

                    echo "<table class='table table-stripped table-hover table-border'>
                    <tr><td>ID</td><td>: {$d['id']}</td></tr>
                    <tr><td>Nama</td><td>: {$d['nama']}</td></tr>
                    <tr><td>Alamat</td><td>: {$d['alamat']}</td></tr>
                    <tr><td>Nomor Handphone</td><td>: {$d['nomor_hp']}</td></tr>
                    <tr><td>Tanggal</td><td>: {$d['created_at']}</td></tr>
                    </table>";
                }
                  ?>
                  <a href="./?p=nasabah" class="btn btn-secondary">Back</a>
                    </div>
                  </div>
                  <!--end::Card Footer-->
                </div>
                <!--end::Card-->
                  <!--end::Card Footer-->
                </div>
                <!--end::Card-->
              </div>
              <!--end::Col-->
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>