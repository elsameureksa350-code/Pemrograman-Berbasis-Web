<?php
require_once "koneksi.php";

$filter_date = isset($_GET['tanggal']) && $_GET['tanggal'] != '' 
    ? $_GET['tanggal'] 
    : date('Y-m-d');

$sql = "
SELECT 
    s.id, 
    s.nasabah_id, 
    s.sampah_id, 
    s.berat, 
    s.catatan, 
    s.total, 
    s.bukti,
    s.status,
    s.created_at,
    n.nama AS nasabah, 
    j.nama_sampah AS sampah
FROM setoran s
LEFT JOIN nasabah n ON s.nasabah_id = n.id
LEFT JOIN jenis_sampah j ON s.sampah_id = j.id
WHERE DATE(s.tanggal) = '$filter_date'
ORDER BY s.id DESC
";
$q = $koneksi->query($sql);
?>

<main class="app-main">

<div class="app-content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6">
        <h3 class="mb-0">Setoran Sampah</h3>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-end">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Setoran</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<div class="app-content">
  <div class="container-fluid">

    <div class="card shadow-sm">
      <div class="card-header bg-light">
        <form method="GET" class="row g-3 align-items-center">
          <div class="col-auto">
            <label for="tanggal" class="col-form-label fw-bold">Pilih Tanggal</label>
          </div>
          <div class="col-auto">
            <input type="date" id="tanggal" name="tanggal" class="form-control"
                   value="<?= htmlspecialchars($filter_date ?? '') ?>">
          </div>
          <div class="col-auto">
            <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
            <a href="?p=setoran" class="btn btn-secondary"><i class="fas fa-undo"></i> Reset</a>
          </div>
          <div class="col-auto ms-auto">
            <a href="./?p=add_setoran" class="btn btn-success">
              <i class="fas fa-plus"></i> Tambah Setoran
            </a>
          </div>
        </form>
      </div>

      <div class="card-body">
        <h5 class="fw-bold mb-3">
          Daftar Setoran (<?= htmlspecialchars($filter_date ?? '') ?>)
        </h5>

        <?php if ($q && $q->num_rows > 0): ?>
        <div class="table-responsive">
          <table class="table table-striped table-bordered align-middle text-center">
            <thead class="table-success">
              <tr>
                <th>No</th>
                <th>Nasabah</th>
                <th>Jenis Sampah</th>
                <th>Berat (kg)</th>
                <th>Total (Rp)</th>
                <th>Catatan</th>
                <th>Bukti</th>
                <th>Status</th>
                <th>Tanggal</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
            <?php 
              $no = 1;
              while ($d = $q->fetch_assoc()): 
                $status_color = match($d['status']) {
                  'Selesai' => 'success',
                  'Ditolak' => 'danger',
                  default => 'warning'
                };

                $has_bukti = !empty($d['bukti']);
            ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($d['nasabah'] ?? '') ?></td>
                <td><?= htmlspecialchars($d['sampah'] ?? '') ?></td>
                <td><?= number_format($d['berat'] ?? 0, 1) ?></td>
                <td>Rp<?= number_format($d['total'] ?? 0) ?></td>
                <td><?= nl2br(htmlspecialchars($d['catatan'] ?? '-')) ?></td>
                <td>
                  <?php if ($has_bukti): ?>
                    <img src="uploads/setoran/<?= htmlspecialchars($d['bukti']) ?>" 
                         class="img-thumbnail" style="max-width:80px; max-height:80px;">
                  <?php else: ?>
                    <span class="badge bg-warning text-dark">Tanpa Bukti</span>
                  <?php endif; ?>
                </td>
                <td>
                  <span class="badge bg-<?= $status_color ?>">
                    <?= htmlspecialchars($d['status'] ?? 'Pending') ?>
                  </span>
                </td>
                <td><small><?= htmlspecialchars($d['created_at'] ?? '') ?></small></td>
                <td>
                  <?php if ($has_bukti): ?>
                    <!-- Kalau ada bukti, admin bisa Terima -->
                    <a href="?p=update_status&id=<?= (int)$d['id'] ?>" 
                       class="btn btn-success btn-sm mb-1">
                      <i class="fas fa-check"></i> Terima
                    </a><br>
                  <?php else: ?>
                    <!-- Kalau TIDAK ada bukti, tombol Terima dibuat non-aktif -->
                    <button class="btn btn-success btn-sm mb-1" disabled
                            title="Tidak bisa diterima karena belum ada bukti foto">
                      <i class="fas fa-check"></i> Terima
                    </button><br>
                  <?php endif; ?>

                  <!-- Tombol Tolak: admin bisa menolak setoran (khususnya yang tanpa bukti) -->
                  <a href="?p=update_status&id=<?= (int)$d['id'] ?>&status=Ditolak" 
                     class="btn btn-warning btn-sm mb-1"
                     onclick="return confirm('Yakin ingin MENOLAK setoran ini?');">
                    <i class="fas fa-times"></i> Tolak
                  </a><br>

                  <a href="?p=delete_setoran&id=<?= (int)$d['id'] ?>" 
                     class="btn btn-danger btn-sm"
                     onclick="return confirm('Yakin ingin menghapus setoran ini?')">
                     <i class="fas fa-trash"></i> Hapus
                  </a>
                </td>
              </tr>
            <?php endwhile; ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
          <div class="alert alert-info text-center">Belum ada setoran untuk tanggal ini.</div>
        <?php endif; ?>

      </div>
    </div>

  </div>
</div>

</main>
