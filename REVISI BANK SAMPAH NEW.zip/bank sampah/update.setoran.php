<?php
require_once "koneksi.php";

if (!isset($_GET['id'])) {
    echo "<script>alert('ID tidak ditemukan!'); window.location.href='?p=setoran';</script>";
    exit();
}

$id = $_GET['id'];

$sql = "UPDATE setoran SET status='Selesai' WHERE id='$id'";
if ($koneksi->query($sql)) {
    echo "<script>alert('Status setoran diperbarui!'); window.location.href='?p=setoran';</script>";
} else {
    echo "Gagal memperbarui: " . $koneksi->error;
}
?>
