<?php
session_start();
require_once "koneksi.php";

// --- Pastikan nasabah login ---
if (!isset($_SESSION['nasabah_id'])) {
    // sementara, kalau belum ada session pakai id=1
    $nasabah_id = 1;
} else {
    $nasabah_id = (int) $_SESSION['nasabah_id'];
}

// Ambil data nasabah (opsional, buat ditampilkan di form)
$qNasabah = $koneksi->query("SELECT * FROM nasabah WHERE id = '$nasabah_id' LIMIT 1");
$nasabah  = $qNasabah ? $qNasabah->fetch_assoc() : null;
$nama_nasabah = $nasabah['nama'] ?? 'Nasabah';

// Ambil daftar jenis_sampah untuk dropdown
$qJenis = $koneksi->query("SELECT id, nama_sampah, kategori, harga_per_kg FROM jenis_sampah ORDER BY nama_sampah ASC");

// Pesan feedback
$pesan_sukses = "";
$pesan_error  = "";

// --- PROSES FORM SETORAN ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sampah_id = (int) ($_POST['sampah_id'] ?? 0);
    $berat     = (float) ($_POST['berat'] ?? 0);
    $catatan   = trim($_POST['catatan'] ?? '');

    // ---- PROSES UPLOAD BUKTI SETORAN (FOTO) ----
    $bukti_nama = null;
    if (!empty($_FILES['bukti']['name'])) {
        $upload_dir = 'uploads/setoran/';

        // Kalau folder belum ada, buat dulu
        if (!is_dir($upload_dir)) {
            @mkdir($upload_dir, 0777, true);
        }

        $ext = pathinfo($_FILES['bukti']['name'], PATHINFO_EXTENSION);
        $ext = strtolower($ext);

        // Nama file unik
        $bukti_nama = 'bukti_' . time() . '_' . mt_rand(1000, 9999) . '.' . $ext;
        $target_file = $upload_dir . $bukti_nama;

        // Sedikit validasi tipe file dasar (opsional tapi aman)
        $allowed_ext = ['jpg','jpeg','png','gif','webp'];
        if (!in_array($ext, $allowed_ext)) {
            $pesan_error = "Format bukti setoran harus berupa gambar (jpg, jpeg, png, gif, webp).";
        } else {
            if (!move_uploaded_file($_FILES['bukti']['tmp_name'], $target_file)) {
                $pesan_error = "Gagal mengupload bukti setoran.";
            }
        }
    }
    // ---- END UPLOAD BUKTI ----

    if ($sampah_id <= 0 || $berat <= 0) {
        $pesan_error = "Jenis sampah dan berat harus diisi dengan benar.";
    } elseif ($pesan_error === "") { // lanjut hanya kalau tidak ada error upload
        // ambil info harga dari jenis_sampah
        $qInfo = $koneksi->query("SELECT * FROM jenis_sampah WHERE id = '$sampah_id' LIMIT 1");
        $info  = $qInfo ? $qInfo->fetch_assoc() : null;

        if (!$info) {
            $pesan_error = "Jenis sampah tidak ditemukan.";
        } else {
            $harga_per_kg = (float) ($info['harga_per_kg'] ?? 0);

            // kalau harga_per_kg = 0, bisa kamu kembangkan untuk mode per PCS, tapi sekarang fokus per KG dulu
            if ($harga_per_kg <= 0) {
                $total = 0;
            } else {
                $total = $berat * $harga_per_kg;
            }

            $tanggal    = date('Y-m-d');
            $created_at = date('Y-m-d H:i:s');

            // INSERT ke tabel setoran (TAMBAH KOLOM BUKTI)
            $sqlSetoran = "
                INSERT INTO setoran
                (nasabah_id, sampah_id, berat, catatan, total, bukti, status, tanggal, created_at)
                VALUES
                ('$nasabah_id', '$sampah_id', '$berat', '$catatan', '$total', " .
                ($bukti_nama ? "'" . $koneksi->real_escape_string($bukti_nama) . "'" : "NULL") . ",
                'Pending', '$tanggal', '$created_at')
            ";

            if ($koneksi->query($sqlSetoran)) {
                // Buat judul untuk riwayat
                $judul = "Setoran " . ($info['nama_sampah'] ?? 'Sampah');

                // SESUAIKAN NILAI 'jenis' DENGAN DEFINISI ENUM / TIPE DI DATABASE
                // Misal: ENUM('Setoran','Penukaran')
                $jenis_riwayat = 'Setoran'; // <- huruf besar S, sesuaikan dengan yang ada di tabel kamu

                $sqlRiwayat = "
                    INSERT INTO riwayat_transaksi
                    (nasabah_id, jenis, judul, berat, nilai, status, tanggal, created_at)
                    VALUES
                    ('$nasabah_id', '$jenis_riwayat', '$judul', '$berat', '$total', 'Pending', '$tanggal', '$created_at')
                ";

                $koneksi->query($sqlRiwayat);

                // ================== UPDATE TOTAL_KG DI JENIS_SAMPAH ==================
                // Supaya di halaman admin (jenis_sampah.php) kolom Total Terkumpul (kg)
                // langsung bertambah setiap kali ada setoran baru.
                $updateJenis = "
                    UPDATE jenis_sampah
                    SET total_kg = COALESCE(total_kg, 0) + $berat
                    WHERE id = '$sampah_id'
                ";
                $koneksi->query($updateJenis);
                // ====================================================================

                // redirect balik ke dashboard
                echo "<script>alert('Setoran berhasil dikirim. Menunggu verifikasi admin.'); 
                      window.location.href='dashboard.php';</script>";
                exit();
            } else {
                $pesan_error = "Gagal menyimpan setoran: " . $koneksi->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Setor Sampah - Recyclean</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen font-sans">

  <div class="max-w-3xl mx-auto mt-10 bg-white rounded-2xl shadow-xl p-8">
    <h2 class="text-2xl font-bold text-gray-800 mb-2">Setor Sampah</h2>
    <p class="text-gray-600 mb-4">
      Nasabah: <strong><?= htmlspecialchars($nama_nasabah) ?></strong>
    </p>

    <?php if ($pesan_error): ?>
      <div class="mb-4 p-3 rounded bg-red-100 text-red-700 text-sm">
        <?= htmlspecialchars($pesan_error) ?>
      </div>
    <?php endif; ?>

    <!-- TAMBAHKAN enctype UNTUK UPLOAD FILE -->
    <form method="post" enctype="multipart/form-data" class="space-y-4">

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Jenis Sampah</label>
        <select name="sampah_id" class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring focus:ring-green-300" required>
          <option value="">-- Pilih Jenis Sampah --</option>
          <?php if ($qJenis && $qJenis->num_rows > 0): ?>
            <?php while($j = $qJenis->fetch_assoc()): ?>
              <option value="<?= $j['id']; ?>">
                <?= htmlspecialchars($j['nama_sampah']) ?> (<?= htmlspecialchars($j['kategori']) ?>)
              </option>
            <?php endwhile; ?>
          <?php endif; ?>
        </select>
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Berat (Kg)</label>
        <input type="number" step="0.01" min="0" name="berat"
               class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring focus:ring-green-300"
               placeholder="contoh: 2.5" required>
      </div>

      <!-- INPUT BUKTI SETORAN -->
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Bukti Setoran (foto)</label>
        <input type="file" name="bukti"
               accept="image/*"
               class="w-full border rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring focus:ring-green-300">
        <p class="text-xs text-gray-500 mt-1">Format gambar: jpg, jpeg, png, gif, webp.</p>
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Catatan (opsional)</label>
        <textarea name="catatan" rows="3"
                  class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring focus:ring-green-300"
                  placeholder="Contoh: botol plastik campur kardus"></textarea>
      </div>

      <div class="flex justify-between items-center pt-4">
        <a href="dashboard.php" class="px-4 py-2 rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-100">
          Batal
        </a>
        <button type="submit"
                class="px-5 py-2 rounded-lg bg-green-600 text-white font-semibold hover:bg-green-700">
          Kirim Setoran
        </button>
      </div>

    </form>
  </div>

</body>
</html>
