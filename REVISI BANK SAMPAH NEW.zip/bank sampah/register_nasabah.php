<?php
session_start();
require_once "koneksi.php";

$errors = [];
$success = "";

// Jika sudah login nasabah, lempar ke dashboard
if (isset($_SESSION['nasabah_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama          = trim($_POST['nama'] ?? '');
    $gender        = $_POST['jenis_kelamin'] ?? '';   // ini 'L' atau 'P' dari radio
    $email         = trim($_POST['email'] ?? '');
    $password      = trim($_POST['password'] ?? '');
    $password2     = trim($_POST['password2'] ?? '');
    $alamat        = trim($_POST['alamat'] ?? '');
    $nomor_hp      = trim($_POST['nomor_hp'] ?? '');

    // Mapping L/P ke teks panjang untuk kolom jenis_kelamin
    $jenis_kelamin = '';
    if ($gender === 'L') {
        $jenis_kelamin = 'Laki-laki';
    } elseif ($gender === 'P') {
        $jenis_kelamin = 'Perempuan';
    }

    // Validasi sederhana
    if ($nama === '')             $errors[] = "Nama wajib diisi.";
    if ($gender === '' || $jenis_kelamin === '') $errors[] = "Jenis kelamin wajib dipilih.";
    if ($email === '')            $errors[] = "Email wajib diisi.";
    if ($password === '')         $errors[] = "Password wajib diisi.";
    if ($password2 === '')        $errors[] = "Konfirmasi password wajib diisi.";
    if ($password !== $password2) $errors[] = "Password dan konfirmasi tidak sama.";

    // Cek email sudah dipakai di nasabah?
    if (empty($errors)) {
        $email_esc = $koneksi->real_escape_string($email);
        $cek = $koneksi->query("SELECT id FROM nasabah WHERE email = '$email_esc' LIMIT 1");
        if ($cek && $cek->num_rows > 0) {
            $errors[] = "Email sudah terdaftar sebagai nasabah.";
        }
    }

    if (empty($errors)) {
        // (sementara password plain text, disamakan dengan login.php)
        $nama_esc          = $koneksi->real_escape_string($nama);
        $jenis_kelamin_esc = $koneksi->real_escape_string($jenis_kelamin);
        $gender_esc        = $koneksi->real_escape_string($gender);
        $pass_esc          = $koneksi->real_escape_string($password);
        $alamat_esc        = $koneksi->real_escape_string($alamat);
        $nomor_hp_esc      = $koneksi->real_escape_string($nomor_hp);
        $created_at        = date('Y-m-d H:i:s');

        $sql = "
            INSERT INTO nasabah (nama, jenis_kelamin, alamat, nomor_hp, gender, created_at, email, password)
            VALUES (
                '$nama_esc',
                '$jenis_kelamin_esc',
                '$alamat_esc',
                '$nomor_hp_esc',
                '$gender_esc',
                '$created_at',
                '$email_esc',
                '$pass_esc'
            )
        ";

        if ($koneksi->query($sql)) {
            $new_id = $koneksi->insert_id;
            $_SESSION['nasabah_id'] = $new_id;
            $_SESSION['role']       = 'nasabah';

            header("Location: login.php");
            exit;
        } else {
            $errors[] = "Gagal menyimpan ke database: " . $koneksi->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Register Nasabah - RECYCLEAN</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen flex items-center justify-center">

  <div class="bg-white shadow-2xl rounded-2xl max-w-md w-full p-8">
    <div class="flex items-center justify-center mb-6">
      <h1 class="w-30 h-50 mx-auto">
                <img
                  src="recyclean.jpg"
                  alt="Logo RECYCLEAN"
                  class="w-full h-full object-contain"></h1>
    </div>

    <h2 class="text-xl font-semibold text-gray-800 mb-2 text-center">
      Daftar Sebagai Nasabah
    </h2>
    <p class="text-sm text-gray-500 mb-6 text-center">
      Buat akun untuk mulai menukarkan sampah menjadi poin.
    </p>

    <?php if (!empty($errors)): ?>
      <div class="mb-4 px-4 py-3 rounded bg-red-100 text-red-700 text-sm">
        <ul class="list-disc list-inside">
          <?php foreach ($errors as $e): ?>
            <li><?= htmlspecialchars($e) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="post" class="space-y-4">
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Nama Lengkap</label>
        <input type="text" name="nama" required
               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
               value="<?= htmlspecialchars($_POST['nama'] ?? '') ?>">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Jenis Kelamin</label>
        <div class="flex items-center gap-4">
          <label class="inline-flex items-center">
            <input type="radio" name="jenis_kelamin" value="L"
                   class="text-green-600 focus:ring-green-500 border-gray-300"
                   required
                   <?= (($_POST['jenis_kelamin'] ?? '') === 'L') ? 'checked' : '' ?>>
            <span class="ml-2 text-gray-700">Laki-laki</span>
          </label>
          <label class="inline-flex items-center">
            <input type="radio" name="jenis_kelamin" value="P"
                   class="text-green-600 focus:ring-green-500 border-gray-300"
                   <?= (($_POST['jenis_kelamin'] ?? '') === 'P') ? 'checked' : '' ?>>
            <span class="ml-2 text-gray-700">Perempuan</span>
          </label>
        </div>
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
        <input type="email" name="email" required
               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
        <input type="password" name="password" required
               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Konfirmasi Password</label>
        <input type="password" name="password2" required
               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Alamat</label>
        <input type="text" name="alamat"
               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
               value="<?= htmlspecialchars($_POST['alamat'] ?? '') ?>">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Nomor Handphone</label>
        <input type="text" name="nomor_hp"
               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
               value="<?= htmlspecialchars($_POST['nomor_hp'] ?? '') ?>">
      </div>

      <a href="login.php"
      class="w-full inline-block text-center bg-green-600 hover:bg-green-700 text-white font-semibold py-2.5 rounded-lg mt-4 transition-colors">
      Daftar
      </a>

    </form>

    <p class="mt-4 text-sm text-center text-gray-600">
      Sudah punya akun?
      <a href="login.php" class="text-green-600 hover:text-green-700 font-semibold">Masuk di sini</a>
    </p>

    <p class="mt-6 text-xs text-center text-gray-400">
      &copy; <?= date('Y') ?> RECYCLEAN. Semua hak dilindungi.
    </p>
  </div>

</body>
</html>
