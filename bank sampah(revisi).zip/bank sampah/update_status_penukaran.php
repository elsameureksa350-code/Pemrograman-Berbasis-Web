<?php
require_once "koneksi.php";

if (!isset($_GET['id'])) {
    echo "<script>alert('ID tidak ditemukan!'); window.location.href='?p=penukaran_hadiah';</script>";
    exit();
}

$id = $_GET['id'];

$status = isset($_GET['status']) ? $_GET['status'] : 'Selesai';
$res = $koneksi->query("SELECT nasabah_id, tanggal FROM penukaran_hadiah WHERE id='$id' LIMIT 1");
$row = $res ? $res->fetch_assoc() : null;
$nasabah_id = $row['nasabah_id'] ?? null;
$tanggal    = $row['tanggal']    ?? null;

$sql = "UPDATE penukaran_hadiah SET status='$status' WHERE id='$id'";
if ($koneksi->query($sql)) {

    if ($nasabah_id && $tanggal) {
        $tgl_saja = date('Y-m-d', strtotime($tanggal));

        $koneksi->query("
            UPDATE riwayat_transaksi
            SET status = '$status'
            WHERE nasabah_id = '$nasabah_id'
            AND jenis      = 'Penukaran'
            AND tanggal    = '$tgl_saja'
        ");
    }

    echo "<script>alert('Status penukaran diperbarui menjadi $status!'); window.location.href='?p=penukaran_hadiah';</script>";
    exit();
} else {
    echo "Gagal memperbarui: " . $koneksi->error;
}
?>
