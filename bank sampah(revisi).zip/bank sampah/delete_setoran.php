<?php
require_once "koneksi.php";

if (!isset($_GET['id'])) {
    echo "<script>alert('ID tidak ditemukan!'); window.location.href='?p=setoran';</script>";
    exit();
}

$id = $_GET['id'];

$q = $koneksi->query("SELECT bukti FROM setoran WHERE id='$id'");
$d = $q->fetch_assoc();

$folder_upload = 'uploads/setoran/';

if ($d && !empty($d['bukti']) && file_exists($folder_upload . $d['bukti'])) {
    unlink($folder_upload . $d['bukti']);
}

$sql = "DELETE FROM setoran WHERE id='$id'";
if ($koneksi->query($sql)) {
    echo "<script>alert('Setoran berhasil dihapus!'); window.location.href='?p=setoran';</script>";
    exit();
} else {
    echo "Gagal menghapus: " . $koneksi->error;
}
?>
