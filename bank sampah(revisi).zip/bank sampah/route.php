<?php
$p=$_GET['p']??'';

switch($p){
    case 'nasabah': require_once "nasabah.php"; break;
    case 'jenis_sampah': require_once "jenis_sampah.php"; break;
    case 'setoran': require_once "setoran.php"; break;
    case 'penukaran_hadiah': require_once "penukaran_hadiah.php"; break;
    case 'riwayat_transaksi': require_once "riwayat_transaksi.php"; break;
    case 'pengaturan': require_once "pengaturan.php"; break;
    case 'profil': require_once "profil.php"; break;
    case 'login': require_once "login.php"; break;
    case 'logout': require_once "logout.php"; break;
    case 'hadiah': require_once "hadiah.php"; break;
    case 'register_nasabah': require_once "register_nasabah.php"; break;
    case 'riwayat_nasabah': require_once "riwayat_nasabah.php"; break;
    case 'tukar_hadiah': require_once "tukar_hadiah.php"; break;
    case 'landing_page': require_once "landing_page.php"; break;
    case 'update_status_penukaran': require_once "update_status_penukaran.php"; break;

    case 'add_nasabah': require_once "add_nasabah.php"; break;
    case 'add_jenis_sampah': require_once "add_jenis_sampah.php"; break;
    case 'add_setoran': require_once "add_setoran.php"; break;
    case 'add_penukaran_hadiah': require_once "add_penukaran_hadiah.php"; break;
    case 'add_hadiah': require_once "add_hadiah.php"; break;

    case 'edit_nasabah': require_once "edit_nasabah.php"; break;
    case 'edit_jenis_sampah': require_once "edit_jenis_sampah.php"; break;
    case 'edit_hadiah': require_once "edit_hadiah.php"; break;

    case 'detail': require_once "detail.php"; break;

    case 'hapus': require_once "hapus.php"; break;
    case 'delete_jenis_sampah': require_once "delete_jenis_sampah.php"; break;
    case 'delete_jenis_sampah': require_once "delete_jenis_sampah.php"; break;
    case 'delete_setoran': require_once "delete_setoran.php"; break;
    case 'delete_penukaran_hadiah': require_once "delete_penukaran_hadiah.php"; break;
    case 'delete_hadiah': require_once "delete_hadiah.php"; break;

    case 'update_profil': require_once "update_profil.php"; break;
    case 'update_setoran': require_once "update_setoran.php"; break;
    case 'update_status': require_once "update_status.php"; break;
    case 'update_penukaran_hadiah': require_once "update_penukaran_hadiah.php"; break;

    case 'proses_setoran': require_once "proses_setoran.php"; break;
    case 'pross_penukaran': require_once "proses_penukaran.php"; break;
    case 'selesai_penukaran': require_once "selesai_penukaran.php"; break;


    
    default: require_once "index.php"; break;
}
?>