<?php
require_once 'koneksi.php';

if (isset($_POST['simpan'])) {
    $nama      = $_POST['nama'];
    $alamat    = $_POST['alamat'];
    $nomor_hp  = $_POST['nomor_hp'];
    $gender    = $_POST['gender'] ?? '';
    $created_at = $_POST['created_at'];

    if (!empty($created_at)) {
        $created_at = date('Y-m-d H:i:s', strtotime($created_at));
    } else {
        $created_at = date('Y-m-d H:i:s');
    }

    $sql = "INSERT INTO nasabah (nama, alamat, nomor_hp, gender, created_at)
            VALUES ('$nama', '$alamat', '$nomor_hp', '$gender', '$created_at')";

    if ($koneksi->query($sql)) {
        echo "<script>window.location.href='?p=nasabah';</script>";
        exit();
    } else {
        echo 'Gagal menyimpan data: ' . $koneksi->error;
    }
}
?>

<!--begin::App Main-->
<main class="app-main">
  <!--begin::App Content Header-->
  <div class="app-content-header">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6"><h3 class="mb-0">Tambah Nasabah</h3></div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-end">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Tambah Nasabah</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
  <!--end::App Content Header-->

  <!--begin::App Content-->
  <div class="app-content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card shadow-sm border-0">
            <div class="card-header bg-white">
              <form action="" method="post">
                <table class="table table-bordered align-middle">
                  <tr>
                    <td><strong>Nama</strong></td>
                    <td><input type="text" name="nama" class="form-control" required></td>
                  </tr>
                  <tr>
                    <td><strong>Alamat</strong></td>
                    <td><input type="text" name="alamat" class="form-control" required></td>
                  </tr>
                  <tr>
                    <td><strong>Nomor Handphone</strong></td>
                    <td><input type="text" name="nomor_hp" class="form-control" required></td>
                  </tr>
                  <tr>
                    <td><strong>Jenis Kelamin</strong></td>
                    <td>
                      <label><input type="radio" name="gender" value="L" required> Laki-laki</label>
                      <label class="ms-3"><input type="radio" name="gender" value="P" required> Perempuan</label>
                    </td>
                  </tr>
                  <tr>
                    <td><strong>Transaksi Terakhir</strong></td>
                    <td>
                      <input type="datetime-local" name="created_at" class="form-control">
                      <small class="text-muted">Opsional — otomatis diisi waktu saat ini jika dikosongkan</small>
                    </td>
                  </tr>
                  <tr>
                    <td></td>
                    <td>
                      <input type="submit" name="simpan" class="btn btn-success" value="Simpan">
                      <a href="?p=nasabah" class="btn btn-secondary ms-2">Kembali</a>
                    </td>
                  </tr>
                </table>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--end::App Content-->
</main>
<!--end::App Main-->
