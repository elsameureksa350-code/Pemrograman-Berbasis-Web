<?php
include "koneksi.php";

$nasabah = $_POST['nasabah'];
$nominal = $_POST['nominal'];
$tanggal = $_POST['tanggal'];

$sql = "INSERT INTO penukaran (nasabah_id, nominal, tanggal, status, created_at)
        VALUES ('$nasabah','$nominal','$tanggal','Selesai',NOW())";

if ($koneksi->query($sql)) {
    $id_penukaran = $koneksi->insert_id;
    $koneksi->query("INSERT INTO riwayat_transaksi (transaksi_id, jenis, nasabah_id, nilai, created_at)
    VALUES ('$id_penukaran','penukaran','$nasabah','$nominal',NOW())");
    header("Location: riwayat.php");
} else {
    echo "Gagal: " . $koneksi->error;
}
?>
