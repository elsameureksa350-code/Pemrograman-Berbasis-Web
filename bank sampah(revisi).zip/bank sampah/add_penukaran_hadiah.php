<?php
require_once 'koneksi.php';

$nasabah = $koneksi->query("SELECT * FROM nasabah ORDER BY nama ASC");
$hadiah  = $koneksi->query("SELECT * FROM hadiah ORDER BY nama_hadiah ASC");

if (isset($_POST['simpan'])) {
    $nasabah_id = $_POST['nasabah_id'];
    $hadiah_id  = $_POST['hadiah_id'];
    $jumlah     = $_POST['jumlah'];
    $tanggal    = $_POST['tanggal'];
    $status     = 'Pending';

    $h = $koneksi->query("SELECT poin_diperlukan FROM hadiah WHERE id='$hadiah_id'")->fetch_assoc();
    $total_poin = $h['poin_diperlukan'] * $jumlah;

    $bukti = null;
    if (!empty($_FILES['bukti']['name'])) {
        $ext = pathinfo($_FILES['bukti']['name'], PATHINFO_EXTENSION);
        $nama_file_baru = 'penukaran_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
        $folder_upload = 'uploads/penukaran_hadiah/';

        if (!is_dir($folder_upload)) mkdir($folder_upload, 0777, true);
        $tujuan = $folder_upload . $nama_file_baru;

        if (move_uploaded_file($_FILES['bukti']['tmp_name'], $tujuan)) {
            $bukti = $nama_file_baru;
        }
    }

    $sql = "INSERT INTO penukaran_hadiah (nasabah_id, hadiah_id, jumlah, total_poin, bukti, tanggal, status, created_at)
            VALUES ('$nasabah_id', '$hadiah_id', '$jumlah', '$total_poin', '$bukti', '$tanggal', '$status', NOW())";

    if ($koneksi->query($sql)) {
        echo "<script>alert('Penukaran hadiah berhasil disimpan!'); window.location.href='?p=penukaran_hadiah';</script>";
        exit();
    } else {
        echo "Gagal menyimpan: " . $koneksi->error;
    }
}
?>

<main class="app-main">
<div class="app-content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6"><h3 class="mb-0">Tambah Penukaran Hadiah</h3></div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-end">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item"><a href="./?p=penukaran_hadiah">Penukaran Hadiah</a></li>
          <li class="breadcrumb-item active">Tambah</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<div class="app-content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header">
        <form method="post" enctype="multipart/form-data">
          <table class="table">
            <tr>
              <td>Nasabah</td>
              <td>
                <select name="nasabah_id" class="form-control" required>
                  <option value="" disabled selected>Pilih Nasabah</option>
                  <?php while($n = $nasabah->fetch_assoc()): ?>
                    <option value="<?= $n['id'] ?>"><?= $n['nama'] ?></option>
                  <?php endwhile; ?>
                </select>
              </td>
            </tr>

            <tr>
              <td>Hadiah</td>
              <td>
                <select name="hadiah_id" class="form-control" required>
                  <option value="" disabled selected>Pilih Hadiah</option>
                  <?php while($h = $hadiah->fetch_assoc()): ?>
                    <option value="<?= $h['id'] ?>"><?= $h['nama_hadiah'] ?> (<?= $h['poin_diperlukan'] ?> poin)</option>
                  <?php endwhile; ?>
                </select>
              </td>
            </tr>

            <tr>
              <td>Jumlah</td>
              <td><input type="number" name="jumlah" class="form-control" min="1" value="1" required></td>
            </tr>

            <tr>
              <td>Tanggal</td>
              <td><input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>" required></td>
            </tr>

            <tr>
              <td>Bukti (opsional)</td>
              <td><input type="file" name="bukti" class="form-control" accept="image/*"></td>
            </tr>

            <tr>
              <td colspan="2">
                <input type="submit" name="simpan" class="btn btn-success" value="Simpan">
                <a href="./?p=penukaran_hadiah" class="btn btn-secondary">Kembali</a>
              </td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
</main>
