<?php
require_once "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('Invalid request');
}

$nasabah = isset($_POST['nasabah']) ? $_POST['nasabah'] : null;
$jenis_sampah  = isset($_POST['jenis_sampah'])  ? $_POST['jenis_sampah']  : null;
$berat   = isset($_POST['berat'])   ? (float)$_POST['berat']   : 0;
$total = isset($_POST['total']) ? $_POST['total'] : null;
$catatan = isset($_POST['catatan']) ? $_POST['catatan'] : '';

if (!$nasabah || !$jenis_sampah) {
    die("Nasabah atau jenis sampah belum dipilih.");
}

$stmt = $koneksi->prepare("SELECT harga_per_kg, harga_per_pcs FROM jenis_sampah WHERE id = ?");
$stmt->bind_param("i", $sampah);
if (!$stmt->execute()) {
    die("Gagal mengeksekusi query harga: " . $koneksi->error);
}
$res = $stmt->get_result();
$harga = $res->fetch_assoc();
$stmt->close();

if (!$harga) {
    die("Data jenis_sampah tidak ditemukan untuk id: $sampah");
}
$total = 0;
if (!empty($harga['harga_per_kg']) && $harga['harga_per_kg'] > 0) {
    $total = $harga['harga_per_kg'] * $berat;
} elseif (!empty($harga['harga_per_pcs']) && $harga['harga_per_pcs'] > 0) {
    $total = $harga['harga_per_pcs'] * $berat;
} else {
    $total = 0;
}

$insert = $koneksi->prepare("INSERT INTO setoran (id, nasabah_id, sampah_id, berat, total, catatan, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'Pending', NOW())");
if (!$insert) {
    die("Prepare insert gagal: " . $koneksi->error);
}
$insert->bind_param("iidiss",$nasabah, $sampah, $berat, $total, $tanggal, $catatan);

if ($insert->execute()) {
    echo "<script>alert('Setoran berhasil disimpan!'); window.location.href='?p=setoran';</script>";
    exit;
} else {
    die("Gagal menyimpan setoran: " . $insert->error);
}
