<?php
require_once 'koneksi.php';

$nasabah = $koneksi->query("SELECT * FROM nasabah ORDER BY nama ASC");
$sampah  = $koneksi->query("SELECT * FROM jenis_sampah ORDER BY nama_sampah ASC");

if (isset($_POST['simpan'])) {
    $nasabah_id = $_POST['nasabah_id'];
    $sampah_id  = $_POST['sampah_id'];
    $berat      = $_POST['berat'];
    $catatan    = $_POST['catatan'];
    $tanggal    = date('Y-m-d');
    $status     = 'Pending';

    $getHarga = $koneksi->query("SELECT harga_per_kg FROM jenis_sampah WHERE id='$sampah_id'")->fetch_assoc();
    $harga_kg = $getHarga['harga_per_kg'];
    $total    = $berat * $harga_kg;

    $bukti = null;
    if (!empty($_FILES['bukti']['name'])) {
        $ext = pathinfo($_FILES['bukti']['name'], PATHINFO_EXTENSION);
        $nama_file_baru = 'setoran_' . time() . '_' . rand(1000, 9999) . '.' . $ext;

        $folder_upload = 'uploads/setoran/';
        if (!is_dir($folder_upload)) {
            mkdir($folder_upload, 0777, true);
        }

        $tujuan = $folder_upload . $nama_file_baru;

        if (move_uploaded_file($_FILES['bukti']['tmp_name'], $tujuan)) {
            $bukti = $nama_file_baru;
        }
    }

    $sql = "INSERT INTO setoran 
            (nasabah_id, sampah_id, berat, catatan, total, bukti, status, tanggal, created_at)
            VALUES 
            ('$nasabah_id', '$sampah_id', '$berat', '$catatan', '$total', '$bukti', '$status', '$tanggal', NOW())";

    if ($koneksi->query($sql)) {
        echo "<script>alert('Setoran berhasil ditambahkan!'); window.location.href='?p=setoran';</script>";
        exit();
    } else {
        echo 'Gagal: ' . $koneksi->error;
    }
}
?>

<main class="app-main">

<div class="app-content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6">
        <h3 class="mb-0">Tambah Setoran</h3>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-end">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item"><a href="./?p=setoran">Setoran</a></li>
          <li class="breadcrumb-item active">Tambah</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<div class="app-content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header">

        <form method="post" enctype="multipart/form-data">
          <table class="table">

            <tr>
              <td>Nama Nasabah</td>
              <td>
                <select name="nasabah_id" class="form-control" required>
                  <option value="" disabled selected>Pilih Nasabah</option>
                  <?php while ($n = $nasabah->fetch_assoc()): ?>
                    <option value="<?= $n['id'] ?>"><?= $n['nama'] ?></option>
                  <?php endwhile; ?>
                </select>
              </td>
            </tr>

            <tr>
              <td>Jenis Sampah</td>
              <td>
                <select name="sampah_id" class="form-control" required>
                  <option value="" disabled selected>Pilih Jenis Sampah</option>
                  <?php while ($s = $sampah->fetch_assoc()): ?>
                    <option value="<?= $s['id'] ?>"><?= $s['nama_sampah'] ?></option>
                  <?php endwhile; ?>
                </select>
              </td>
            </tr>

            <tr>
              <td>Berat (kg)</td>
              <td>
                <input type="number" name="berat" class="form-control" step="0.01" required>
              </td>
            </tr>

            <tr>
              <td>Catatan</td>
              <td>
                <textarea name="catatan" class="form-control" rows="3"></textarea>
              </td>
            </tr>

            <tr>
              <td>Bukti Foto</td>
              <td>
                <input type="file" name="bukti" class="form-control" accept="image/*">
                <small class="text-muted">Opsional, bisa foto sampah atau struk.</small>
              </td>
            </tr>

            <tr>
              <td colspan="2">
                <input type="submit" name="simpan" class="btn btn-success" value="Simpan">
                <a href="./?p=setoran" class="btn btn-secondary">Kembali</a>
              </td>
            </tr>

          </table>
        </form>

      </div>
    </div>
  </div>
</div>

</main>
