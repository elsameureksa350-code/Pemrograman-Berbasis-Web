<?php
include "koneksi.php";

$nasabah   = $_POST['nasabah'];
$jenis     = $_POST['jenis_penukaran'];
$nominal   = $_POST['nominal'];
$tanggal   = $_POST['tanggal'];
$catatan   = $_POST['catatan'] ?? "";

$sql = "
    INSERT INTO penukaran (nasabah_id, jenis_penukaran, nominal, tanggal, catatan)
    VALUES ('$nasabah', '$jenis', '$nominal', '$tanggal', '$catatan')
";

$koneksi->query($sql);

header("Location: penukaran.php");
exit;
?>
