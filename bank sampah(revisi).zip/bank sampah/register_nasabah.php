<?php
session_start();
require_once "koneksi.php";

$errors = [];

if (isset($_SESSION['nasabah_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama          = trim($_POST['nama'] ?? '');
    $gender        = $_POST['jenis_kelamin'] ?? '';
    $email         = trim($_POST['email'] ?? '');
    $password      = trim($_POST['password'] ?? '');
    $password2     = trim($_POST['password2'] ?? '');
    $alamat        = trim($_POST['alamat'] ?? '');
    $nomor_hp      = trim($_POST['nomor_hp'] ?? '');

    $jenis_kelamin = '';
    if ($gender === 'L') $jenis_kelamin = 'Laki-laki';
    if ($gender === 'P') $jenis_kelamin = 'Perempuan';

    if ($nama === '')             $errors[] = "Nama wajib diisi.";
    if ($gender === '')           $errors[] = "Jenis kelamin wajib dipilih.";
    if ($email === '')            $errors[] = "Email wajib diisi.";
    if ($password === '')         $errors[] = "Password wajib diisi.";
    if ($password2 === '')        $errors[] = "Konfirmasi password wajib diisi.";
    if ($password !== $password2) $errors[] = "Password dan konfirmasi tidak sama.";

    if (empty($errors)) {
        $email_esc = $koneksi->real_escape_string($email);
        $cek = $koneksi->query("SELECT id FROM nasabah WHERE email='$email_esc' LIMIT 1");
        if ($cek && $cek->num_rows > 0) {
            $errors[] = "Email sudah terdaftar.";
        }
    }

    if (empty($errors)) {
        $sql = "
            INSERT INTO nasabah 
            (nama, jenis_kelamin, alamat, nomor_hp, gender, created_at, email, password)
            VALUES (
                '{$koneksi->real_escape_string($nama)}',
                '{$koneksi->real_escape_string($jenis_kelamin)}',
                '{$koneksi->real_escape_string($alamat)}',
                '{$koneksi->real_escape_string($nomor_hp)}',
                '{$koneksi->real_escape_string($gender)}',
                NOW(),
                '$email_esc',
                '{$koneksi->real_escape_string($password)}'
            )
        ";

        if ($koneksi->query($sql)) {
            header("Location: login.php");
            exit;
        } else {
            $errors[] = "Gagal menyimpan data.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Register Nasabah</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-green-50 min-h-screen flex items-center justify-center">

<div class="bg-white shadow-2xl rounded-2xl max-w-md w-full p-8">
    <div class="flex items-center justify-center mb-6">
      <h1 class="w-30 h-50 mx-auto">
                <img
                  src="recyclean.jpg"
                  alt="Logo RECYCLEAN"
                  class="w-full h-full object-contain"></h1>
    </div>

    <h2 class="text-xl font-semibold text-gray-800 mb-2 text-center">
      Daftar Sebagai Nasabah
    </h2>
    <p class="text-sm text-gray-500 mb-6 text-center">
      Buat akun untuk mulai menukarkan sampah menjadi poin.
    </p>
<?php if ($errors): ?>
<div class="bg-red-100 text-red-700 p-3 rounded mb-4">
<ul class="list-disc list-inside">
<?php foreach ($errors as $e): ?>
<li><?= htmlspecialchars($e) ?></li>
<?php endforeach; ?>
</ul>
</div>
<?php endif; ?>

<form method="post" class="space-y-3">
<input type="text" name="nama" placeholder="Nama" class="w-full border p-2" required>
<input type="email" name="email" placeholder="Email" class="w-full border p-2" required>

<div class="flex gap-4">
<label><input type="radio" name="jenis_kelamin" value="L" required> Laki-laki</label>
<label><input type="radio" name="jenis_kelamin" value="P"> Perempuan</label>
</div>

<input type="password" name="password" placeholder="Password" class="w-full border p-2" required>
<input type="password" name="password2" placeholder="Konfirmasi Password" class="w-full border p-2" required>
<input type="text" name="alamat" placeholder="Alamat" class="w-full border p-2">
<input type="text" name="nomor_hp" placeholder="Nomor HP" class="w-full border p-2">

<button type="submit" class="w-full bg-green-600 text-white py-2 rounded">
Daftar
</button>

</form>

<p class="text-center mt-4 text-sm">
Sudah punya akun? <a href="login.php" class="text-green-600">Login</a>
</p>

</div>
</body>
</html>
