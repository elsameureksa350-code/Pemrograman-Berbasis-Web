<?php
$server   = "localhost";
$username = "root";
$password = "";
$database = "recyclean_dbb";
$port     = 3306;

$koneksi = new mysqli($server, $username, $password, $database, $port);

// cek koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
} else {
    // echo "Koneksi berhasil!";
}
?>