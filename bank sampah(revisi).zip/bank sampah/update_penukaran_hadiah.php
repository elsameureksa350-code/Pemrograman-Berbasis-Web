<?php
require_once "koneksi.php";

if (!isset($_GET['id'])) {
    echo "<script>alert('ID tidak ditemukan!'); window.location.href='?p=penukaran_hadiah';</script>";
    exit();
}

$id = (int) $_GET['id'];
$sql = "UPDATE penukaran_hadiah SET status='Selesai' WHERE id = $id";

if ($koneksi->query($sql)) {
    echo "<script>alert('Penukaran hadiah disetujui!'); window.location.href='?p=penukaran_hadiah';</script>";
} else {
    echo "Gagal update: " . $koneksi->error;
}
?>
