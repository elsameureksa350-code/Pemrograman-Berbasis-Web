<?php
require_once "koneksi.php";

// Daftar kategori yang digunakan (untuk filter)
$kategori_options = [
    'Plastik',
    'Kertas',
    'Logam',
    'Kaca',
    'Organik',
    'Elektronik',
    'Lainnya'
];

// Ambil filter kategori dari GET (jika ada)
$kategori_filter = isset($_GET['kategori']) ? trim($_GET['kategori']) : '';

// Query: ambil jenis_sampah + total setoran yang SUDAH SELESAI (status = 'Selesai')
$sql = "
    SELECT 
        j.*,
        COALESCE(SUM(CASE WHEN s.status = 'Selesai' THEN s.berat  ELSE 0 END), 0) AS total_kg,
        COALESCE(SUM(CASE WHEN s.status = 'Selesai' THEN s.total  ELSE 0 END), 0) AS total_nilai
    FROM jenis_sampah j
    LEFT JOIN setoran s ON s.sampah_id = j.id
";

// Terapkan filter kategori kalau dipilih
if ($kategori_filter !== '' && $kategori_filter !== 'Semua') {
    $kategori_safe = mysqli_real_escape_string($koneksi, $kategori_filter);
    $sql .= " WHERE j.kategori = '$kategori_safe'";
}

$sql .= " GROUP BY j.id ORDER BY j.id DESC";

$data = mysqli_query($koneksi, $sql);

$total_kategori = mysqli_num_rows($data);
?>

<main class="app-main">

  <!-- Header -->
  <div class="app-content-header">
    <div class="container-fluid">

      <div class="row align-items-center">
        <div class="col-sm-6">
          <h2 class="fw-bold text-success">Jenis Sampah</h2>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-end">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Jenis Sampah</li>
          </ol>
        </div>
      </div>

      <div class="card-header bg-white mt-3 p-3 rounded shadow-sm">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">

          <div>
            <h6 class="mb-1 text-muted">
              Total Kategori
              <?php if ($kategori_filter && $kategori_filter !== 'Semua'): ?>
                (Filter: <strong><?= htmlspecialchars($kategori_filter) ?></strong>)
              <?php endif; ?>
              : <strong><?= $total_kategori ?></strong>
            </h6>
            <small class="text-muted">Kelola jenis dan harga sampah dengan mudah</small>
          </div>

          <div class="d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center gap-2">

            <form method="get" class="d-flex align-items-center gap-2">
              <input type="hidden" name="p" value="jenis_sampah">

              <select name="kategori" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="Semua" <?= ($kategori_filter === '' || $kategori_filter === 'Semua') ? 'selected' : '' ?>>
                  Semua Kategori
                </option>
                <?php foreach ($kategori_options as $opt): ?>
                  <option value="<?= htmlspecialchars($opt) ?>"
                    <?= ($kategori_filter === $opt) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($opt) ?>
                  </option>
                <?php endforeach; ?>
              </select>

              <?php if ($kategori_filter && $kategori_filter !== 'Semua'): ?>
                <a href="./?p=jenis_sampah" class="btn btn-outline-secondary btn-sm">
                  Reset
                </a>
              <?php endif; ?>
            </form>
            <a href="./?p=add_jenis_sampah" class="btn btn-success btn-sm ms-sm-2">
              <i class="fas fa-plus me-1"></i> Tambah Kategori
            </a>
          </div>
        </div>
      </div>

    </div>
  </div>
  <!-- /Header -->

  <!-- Content -->
  <div class="app-content">
    <div class="container-fluid">

      <div class="card border-0 shadow-sm mt-4">
        <div class="card-body">

          <div class="row g-4">

            <?php while ($d = mysqli_fetch_assoc($data)) : ?>
              <div class="col-md-6 col-lg-4 col-xl-3">
                <div class="card border-0 shadow-sm h-100">
                  <?php if (!empty($d['gambar'])): ?>
                    <img src="uploads/jenis_sampah/<?= htmlspecialchars($d['gambar']) ?>"
                        alt="<?= htmlspecialchars($d['nama_sampah']) ?>"
                        class="card-img-top"
                        style="height:180px; object-fit:cover; border-top-left-radius:10px; border-top-right-radius:10px;">
                  <?php else: ?>
                    <div class="d-flex justify-content-center align-items-center bg-light" style="height:180px;">
                      <i class="fas fa-recycle fa-3x text-success"></i>
                    </div>
                  <?php endif; ?>
                  <div class="card-body text-center">
                    <h5 class="fw-bold text-dark mb-1"><?= htmlspecialchars($d['nama_sampah']) ?></h5>
                    <p class="text-muted mb-2"><?= htmlspecialchars($d['kategori']) ?></p>
                    <hr>

                    <p class="mb-1">Harga/kg:
                      <span class="badge bg-success">
                        Rp <?= number_format($d['harga_per_kg'], 0, ',', '.') ?>
                      </span>
                    </p>
                    <p class="text-primary mb-1">
                      Total Terkumpul:
                      <strong><?= number_format($d['total_kg'] ?? 0, 2, ',', '.') ?> kg</strong>
                    </p>

                    <p class="text-success mb-2">
                      Nilai Total:
                      <strong>
                        Rp <?= number_format($d['total_nilai'] ?? 0, 0, ',', '.') ?>
                      </strong>
                    </p>
                  </div>

                  <div class="card-footer bg-transparent border-0 p-3 d-flex gap-2">
                    <a href="?p=edit_jenis_sampah&id=<?= (int)$d['id'] ?>" class="btn btn-primary flex-fill">
                      <i class="fas fa-edit me-1"></i> Edit
                    </a>
                    <a href="?p=delete_jenis_sampah&id=<?= (int)$d['id'] ?>"
                      class="btn btn-danger flex-fill"
                      onclick="return confirm('Yakin ingin menghapus data ini?');">
                      <i class="fas fa-trash me-1"></i> Hapus
                    </a>
                  </div>
                </div>
              </div>
            <?php endwhile; ?>

            <?php if ($total_kategori == 0): ?>
              <div class="col-12 text-center py-5">
                <i class="fas fa-box-open fa-3x text-muted mb-3"></i>
                <p class="text-muted">
                  <?php if ($kategori_filter && $kategori_filter !== 'Semua'): ?>
                    Belum ada jenis sampah untuk kategori <strong><?= htmlspecialchars($kategori_filter) ?></strong>.
                  <?php else: ?>
                    Belum ada data jenis sampah yang ditambahkan.
                  <?php endif; ?>
                </p>
              </div>
            <?php endif; ?>

          </div>
        </div>
      </div>

    </div>
  </div>
  <!-- /Content -->

</main>

<!-- FontAwesome -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
</body>
</html>
