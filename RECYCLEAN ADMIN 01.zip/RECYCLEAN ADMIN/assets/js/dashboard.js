
        // Set current date
        document.getElementById('current-date').textContent = new Date().toLocaleDateString('id-ID', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        });

        // Waste Collection Trend Chart
        const wasteData = {
            x: ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'],
            y: [320, 280, 350, 290, 380, 420, 390],
            type: 'scatter',
            mode: 'lines+markers',
            line: {
                color: '#4caf50',
                width: 3
            },
            marker: {
                color: '#4caf50',
                size: 8
            },
            name: 'Kg Sampah'
        };

        const wasteLayout = {
            margin: { t: 20, r: 20, b: 40, l: 40 },
            paper_bgcolor: 'rgba(0,0,0,0)',
            plot_bgcolor: 'rgba(0,0,0,0)',
            xaxis: { 
                gridcolor: '#f0f0f0',
                showgrid: true
            },
            yaxis: { 
                gridcolor: '#f0f0f0',
                showgrid: true
            },
            showlegend: false
        };

        Plotly.newPlot('waste-chart', [wasteData], wasteLayout, {displayModeBar: false});

        // Waste Category Pie Chart
        const categoryData = [{
            values: [45, 25, 20, 10],
            labels: ['Plastik', 'Kertas', 'Kaca', 'Logam'],
            type: 'pie',
            marker: {
                colors: ['#4caf50', '#2196f3', '#ff9800', '#9c27b0']
            },
            textinfo: 'label+percent',
            textposition: 'outside'
        }];

        const categoryLayout = {
            margin: { t: 20, r: 20, b: 20, l: 20 },
            paper_bgcolor: 'rgba(0,0,0,0)',
            plot_bgcolor: 'rgba(0,0,0,0)',
            showlegend: false
        };

        Plotly.newPlot('category-chart', categoryData, categoryLayout, {displayModeBar: false});

        function goTo(page) {
            window.location.href = page;
        }

    document.addEventListener('keydown', e => {
        if (e.key === 'ArrowRight' || e.key === ' ') {
            e.preventDefault();
            window.parent.postMessage('go-next', '*');
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            window.parent.postMessage('go-prev', '*');
        }
    });
