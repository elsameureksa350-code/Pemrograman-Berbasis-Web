
        function goTo(page) {
            window.location.href = page;
        }

        function showSection(sectionId) {
            // Hide all sections
            document.querySelectorAll('.profile-section').forEach(section => {
                section.classList.add('hidden');
            });
            
            // Show selected section
            document.getElementById(sectionId).classList.remove('hidden');
        }

        function logout() {
            if (confirm('Apakah Anda yakin ingin keluar dari akun ini?')) {
                alert('Anda telah berhasil keluar dari akun.');
                // In real application, redirect to login page
                // window.location.href = 'login.html';
            }
        }

        // Form submissions
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                alert('Perubahan berhasil disimpan!');
            });
        });

        // Button actions
        document.querySelectorAll('button').forEach(button => {
            button.addEventListener('click', function() {
                if (this.textContent.includes('Ubah Password')) {
                    alert('Mengarahkan ke halaman ubah password...');
                } else if (this.textContent.includes('Setup 2FA')) {
                    alert('Mengarahkan ke pengaturan 2FA...');
                } else if (this.textContent.includes('Keluar dari Semua Perangkat')) {
                    if (confirm('Keluar dari semua perangkat yang login?')) {
                        alert('Berhasil keluar dari semua perangkat.');
                    }
                } else if (this.textContent.includes('Simpan Preferensi')) {
                    alert('Preferensi berhasil disimpan!');
                }
            });
        });
    
    document.addEventListener('keydown', e => {
        if (e.key === 'ArrowRight' || e.key === ' ') {
            e.preventDefault();
            window.parent.postMessage('go-next', '*');
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            window.parent.postMessage('go-prev', '*');
        }
    });
