
        function goTo(page) {
            window.location.href = page;
        }

        // Form calculation
        document.querySelector('input[type="number"]').addEventListener('input', function() {
            const berat = parseFloat(this.value) || 0;
            const hargaPerKg = 5000; // Default plastik
            const total = berat * hargaPerKg;
            
            document.getElementById('beratSetoran').textContent = berat + ' kg';
            document.getElementById('totalSetoran').textContent = 'Rp ' + total.toLocaleString();
        });

        // Form submission
        document.getElementById('setoranForm').addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Setoran berhasil disimpan!');
        });

        // Button actions
        document.querySelectorAll('.setoran-card button').forEach(button => {
            button.addEventListener('click', function() {
                if (this.textContent.includes('Terima')) {
                    alert('Setoran diterima!');
                } else if (this.textContent.includes('Edit')) {
                    alert('Fitur edit akan segera tersedia!');
                } else if (this.textContent.includes('Hapus')) {
                    if (confirm('Apakah Anda yakin ingin menghapus setoran ini?')) {
                        alert('Setoran dihapus!');
                    }
                }
            });
        });

    document.addEventListener('keydown', e => {
        if (e.key === 'ArrowRight' || e.key === ' ') {
            e.preventDefault();
            window.parent.postMessage('go-next', '*');
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            window.parent.postMessage('go-prev', '*');
        }
    });
