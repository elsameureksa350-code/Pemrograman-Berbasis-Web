
        function goTo(page) {
            window.location.href = page;
        }

        function toggleFAQ(element) {
            const answer = element.querySelector('.faq-answer');
            const icon = element.querySelector('i');
            
            if (answer.classList.contains('open')) {
                answer.classList.remove('open');
                icon.style.transform = 'rotate(0deg)';
            } else {
                // Close all other FAQs
                document.querySelectorAll('.faq-answer').forEach(item => {
                    item.classList.remove('open');
                });
                document.querySelectorAll('.faq-item i').forEach(item => {
                    item.style.transform = 'rotate(0deg)';
                });
                
                // Open clicked FAQ
                answer.classList.add('open');
                icon.style.transform = 'rotate(180deg)';
            }
        }

        // Form submission
        document.querySelector('form').addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Pesan Anda telah terkirim! Tim kami akan segera merespons.');
        });

        // File upload
        document.querySelector('.border-dashed').addEventListener('click', function() {
            document.querySelector('input[type="file"]').click();
        });

        document.querySelector('input[type="file"]').addEventListener('change', function(e) {
            if (e.target.files.length > 0) {
                alert('File berhasil diunggah: ' + e.target.files[0].name);
            }
        });

        // Quick action buttons
        document.querySelector('.contact-card button').addEventListener('click', function() {
            window.location.href = 'tel:0800-123-4567';
        });

        document.querySelector('.video-card button').addEventListener('click', function() {
            alert('Membuka halaman video tutorial...');
        });

        document.querySelector('.guide-card button').addEventListener('click', function() {
            alert('Mengunduh panduan pengguna...');
        });
    
    document.addEventListener('keydown', e => {
        if (e.key === 'ArrowRight' || e.key === ' ') {
            e.preventDefault();
            window.parent.postMessage('go-next', '*');
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            window.parent.postMessage('go-prev', '*');
        }
    });