
        // Search functionality
        document.getElementById('searchInput').addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const cards = document.querySelectorAll('.nasabah-card');
            
            cards.forEach(card => {
                const name = card.querySelector('h3').textContent.toLowerCase();
                const id = card.querySelector('p').textContent.toLowerCase();
                
                if (name.includes(searchTerm) || id.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });

        function goTo(page) {
            window.location.href = page;
        }

        // Add button functionality
        document.querySelector('.floating-add').addEventListener('click', function() {
            alert('Fitur tambah nasabah akan segera tersedia!');
        });

        // Card button functionality
        document.querySelectorAll('.nasabah-card button').forEach(button => {
            button.addEventListener('click', function(e) {
                e.stopPropagation();
                if (this.textContent.includes('Edit')) {
                    alert('Fitur edit nasabah akan segera tersedia!');
                } else {
                    alert('Fitur detail nasabah akan segera tersedia!');
                }
            });
        });

    document.addEventListener('keydown', e => {
        if (e.key === 'ArrowRight' || e.key === ' ') {
            e.preventDefault();
            window.parent.postMessage('go-next', '*');
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            window.parent.postMessage('go-prev', '*');
        }
    });