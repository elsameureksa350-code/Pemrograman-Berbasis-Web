
        function goTo(page) {
            window.location.href = page;
        }

        // Action buttons
        document.querySelectorAll('.history-card button').forEach(button => {
            button.addEventListener('click', function() {
                if (this.textContent.includes('Detail')) {
                    alert('Menampilkan detail transaksi...');
                } else if (this.textContent.includes('Cetak')) {
                    alert('Mencetak bukti transaksi...');
                } else if (this.textContent.includes('Proses')) {
                    if (confirm('Proses transaksi ini?')) {
                        alert('Transaksi sedang diproses!');
                    }
                }
            });
        });

        // Filter functionality
        document.querySelector('.filter-card button').addEventListener('click', function() {
            alert('Menerapkan filter...');
        });

        // Export functionality
        document.querySelectorAll('.filter-card button')[1].addEventListener('click', function() {
            alert('Mengekspor data ke Excel...');
        });

        document.querySelectorAll('.filter-card button')[2].addEventListener('click', function() {
            alert('Mengekspor data ke PDF...');
        });

    document.addEventListener('keydown', e => {
        if (e.key === 'ArrowRight' || e.key === ' ') {
            e.preventDefault();
            window.parent.postMessage('go-next', '*');
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            window.parent.postMessage('go-prev', '*');
        }
    });