
        function goTo(page) {
            window.location.href = page;
        }

        function showSection(sectionId) {
            // Hide all sections
            document.querySelectorAll('.settings-section').forEach(section => {
                section.classList.add('hidden');
            });
            
            // Show selected section
            document.getElementById(sectionId).classList.remove('hidden');
            
            // Update menu active state
            document.querySelectorAll('.menu-item').forEach(item => {
                item.classList.remove('active');
            });
            event.target.closest('.menu-item').classList.add('active');
        }

        // Save button functionality
        document.querySelectorAll('button').forEach(button => {
            if (button.textContent.includes('Simpan')) {
                button.addEventListener('click', function() {
                    alert('Pengaturan berhasil disimpan!');
                });
            }
        });

        // Backup functionality
        document.querySelector('.bg-green-600').addEventListener('click', function() {
            if (this.textContent.includes('Backup')) {
                alert('Proses backup dimulai...');
            }
        });

        document.querySelector('.bg-blue-600').addEventListener('click', function() {
            if (this.textContent.includes('Restore')) {
                alert('Mengunggah file backup...');
            }
        });
    
    document.addEventListener('keydown', e => {
        if (e.key === 'ArrowRight' || e.key === ' ') {
            e.preventDefault();
            window.parent.postMessage('go-next', '*');
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            window.parent.postMessage('go-prev', '*');
        }
    });
