
        function goTo(page) {
            window.location.href = page;
        }

        // Edit button functionality
        document.querySelectorAll('.sampah-card button').forEach(button => {
            button.addEventListener('click', function(e) {
                e.stopPropagation();
                alert('Fitur edit jenis sampah akan segera tersedia!');
            });
        });

    document.addEventListener('keydown', e => {
        if (e.key === 'ArrowRight' || e.key === ' ') {
            e.preventDefault();
            window.parent.postMessage('go-next', '*');
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            window.parent.postMessage('go-prev', '*');
        }
    });