
        // Initialize Vanta.js background
        VANTA.BIRDS({
            el: "#vanta-bg",
            mouseControls: true,
            touchControls: true,
            gyroControls: false,
            minHeight: 200.00,
            minWidth: 200.00,
            scale: 1.00,
            scaleMobile: 1.00,
            backgroundColor: 0xa8e6a3,
            color1: 0x7fcdcd,
            color2: 0x81c784,
            colorMode: "lerp",
            birdSize: 1.20,
            wingSpan: 25.00,
            speedLimit: 3.00,
            separation: 20.00,
            alignment: 20.00,
            cohesion: 20.00,
            quantity: 3.00
        });
        
        function goTo(page) {
            // Add loading animation
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach(item => {
                item.style.transform = 'scale(0.95)';
                item.style.opacity = '0.7';
            });
            
            setTimeout(() => {
                window.location.href = page;
            }, 200);
        }
        
        // Add scroll animations
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const parallax = document.querySelector('.hero-title');
            const speed = scrolled * 0.5;
            parallax.style.transform = `translateY(${speed}px)`;
        });
        
        // Add hover effects for navigation items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('mouseenter', function() {
                this.style.background = this.style.background.replace(/50/g, '100');
            });
            
            item.addEventListener('mouseleave', function() {
                this.style.background = this.style.background.replace(/100/g, '50');
            });
        });
    

    document.addEventListener('keydown', e => {
        if (e.key === 'ArrowRight' || e.key === ' ') {
            e.preventDefault();
            window.parent.postMessage('go-next', '*');
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            window.parent.postMessage('go-prev', '*');
        }
    });
