
        function goTo(page) {
            window.location.href = page;
        }

        function selectPayment(element, type) {
            // Remove selected class from all payment methods
            document.querySelectorAll('.bank-card').forEach(card => {
                card.classList.remove('selected');
            });
            
            // Add selected class to clicked element
            element.classList.add('selected');
            
            // Show/hide bank details
            const bankDetails = document.getElementById('bankDetails');
            if (type === 'bank') {
                bankDetails.classList.remove('hidden');
            } else {
                bankDetails.classList.add('hidden');
            }
        }

        // Form calculation
        document.querySelector('input[type="number"]').addEventListener('input', function() {
            const jumlah = parseFloat(this.value) || 0;
            const biayaAdmin = 2500;
            const totalDiterima = jumlah - biayaAdmin;
            
            document.getElementById('jumlahPenarikan').textContent = 'Rp ' + jumlah.toLocaleString();
            document.getElementById('totalDiterima').textContent = 'Rp ' + Math.max(0, totalDiterima).toLocaleString();
        });

        // Form submission
        document.getElementById('penukaranForm').addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Permintaan penukaran berhasil dikirim!');
        });

        // Action buttons
        document.querySelectorAll('.saldo-card button').forEach(button => {
            button.addEventListener('click', function() {
                if (this.textContent.includes('Proses')) {
                    if (confirm('Proses penukaran ini?')) {
                        alert('Penukaran sedang diproses!');
                    }
                } else if (this.textContent.includes('Tolak')) {
                    if (confirm('Tolak penukaran ini?')) {
                        alert('Penukaran ditolak!');
                    }
                } else if (this.textContent.includes('Ulangi')) {
                    alert('Mengulang proses penukaran...');
                } else if (this.textContent.includes('Bukti')) {
                    alert('Menampilkan bukti transaksi...');
                }
            });
        });

    document.addEventListener('keydown', e => {
        if (e.key === 'ArrowRight' || e.key === ' ') {
            e.preventDefault();
            window.parent.postMessage('go-next', '*');
        } else if (e.key === 'ArrowLeft') {
            e.preventDefault();
            window.parent.postMessage('go-prev', '*');
        }
    });
