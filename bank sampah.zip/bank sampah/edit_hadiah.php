<?php
require_once "koneksi.php";

if (!isset($_GET['id'])) {
    echo "<script>alert('ID hadiah tidak ditemukan!'); window.location.href='?p=hadiah';</script>";
    exit();
}

$id = $_GET['id'];
$d = $koneksi->query("SELECT * FROM hadiah WHERE id='$id'")->fetch_assoc();

if (isset($_POST['update'])) {
    $nama  = $_POST['nama_hadiah'];
    $poin  = $_POST['poin_diperlukan'];
    $stok  = $_POST['stok'];
    $gambar_lama = $_POST['gambar_lama'];
    $gambar = $gambar_lama;

    if (!empty($_FILES['gambar']['name'])) {
        $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
        $nama_file_baru = 'hadiah_' . time() . '.' . $ext;
        $folder = 'uploads/hadiah/';
        $tujuan = $folder . $nama_file_baru;

        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $tujuan)) {
            if (!empty($gambar_lama) && file_exists($folder . $gambar_lama)) unlink($folder . $gambar_lama);
            $gambar = $nama_file_baru;
        }
    }

    $sql = "UPDATE hadiah SET nama_hadiah='$nama', poin_diperlukan='$poin', stok='$stok', gambar='$gambar' WHERE id='$id'";
    if ($koneksi->query($sql)) {
        echo "<script>alert('Hadiah berhasil diperbarui!'); window.location.href='?p=hadiah';</script>";
    } else {
        echo "Gagal update: " . $koneksi->error;
    }
}
?>

<main class="app-main">
<div class="app-content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6"><h3 class="mb-0">Edit Hadiah</h3></div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-end">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item"><a href="./?p=hadiah">Hadiah</a></li>
          <li class="breadcrumb-item active">Edit</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<div class="app-content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header">
        <form method="post" enctype="multipart/form-data">
          <table class="table">
            <tr>
              <td>Nama Hadiah</td>
              <td><input type="text" name="nama_hadiah" class="form-control" value="<?= $d['nama_hadiah'] ?>" required></td>
            </tr>
            <tr>
              <td>Poin Diperlukan</td>
              <td><input type="number" name="poin_diperlukan" class="form-control" value="<?= $d['poin_diperlukan'] ?>" required></td>
            </tr>
            <tr>
              <td>Stok</td>
              <td><input type="number" name="stok" class="form-control" value="<?= $d['stok'] ?>" required></td>
            </tr>
            <tr>
              <td>Gambar Saat Ini</td>
              <td>
                <?php if (!empty($d['gambar'])): ?>
                  <img src="uploads/hadiah/<?= $d['gambar'] ?>" style="max-width:150px; height:auto;"><br>
                <?php endif; ?>
                <input type="hidden" name="gambar_lama" value="<?= $d['gambar'] ?>">
                <input type="file" name="gambar" class="form-control mt-2" accept="image/*">
              </td>
            </tr>
            <tr>
              <td colspan="2">
                <input type="submit" name="update" class="btn btn-success" value="Update">
                <a href="./?p=hadiah" class="btn btn-secondary">Kembali</a>
              </td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
</main>
