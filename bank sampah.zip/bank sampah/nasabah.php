<?php
require_once 'koneksi.php';

// ambil data nasabah, sesuaikan dengan field yang dipakai di edit_nasabah:
// id, nama, nomor_hp, alamat, gender, created_at
$sql  = "SELECT * FROM nasabah ORDER BY id ASC";
$data = mysqli_query($koneksi, $sql);
?>

<!--begin::App Main-->
<main class="app-main">

    <!--begin::App Content Header-->
    <div class="app-content-header">
        <div class="container-fluid">

            <div class="row align-items-center">
                <div class="col-sm-6 fw-bold" style="color:#355E3B">
                    <h3 class="mb-0 fw-bold">
                        <i class="fas fa-users me-2"></i>Data Nasabah
                    </h3>
                </div>

                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="./">Home</a></li>
                        <li class="breadcrumb-item active">Data Nasabah</li>
                    </ol>
                </div>
            </div>

        </div>
    </div>
    <!--end::App Content Header-->


    <!--begin::App Content-->
    <div class="app-content">
        <div class="container-fluid">

            <div class="card shadow-sm border-0">

                <!--begin::Card Header-->
                <div class="card-header bg-white d-flex justify-content-between align-items-center mt-3">
                    <div>
                        <a href="./?p=add_nasabah" class="btn btn-success">
                            <i class="fas fa-plus"></i> Tambah Data
                        </a>
                    </div>

                    <!-- Search Bar (opsional, belum di-proses di PHP) -->
                    <form class="d-flex" style="max-width: 300px;" method="get">
                        <input type="hidden" name="p" value="nasabah">
                        <input class="form-control form-control-sm"
                               type="search"
                               name="q"
                               placeholder="Cari nasabah...">
                    </form>
                </div>
                <!--end::Card Header-->


                <!--begin::Card Body-->
                <div class="card-body">

                    <table class="table table-hover table-striped table-bordered align-middle text-sm">
                        <thead class="table-success text-center">
                            <tr>
                                <th style="width: 5%">No</th>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Jenis Kelamin</th>
                                <th>Alamat</th>
                                <th>Nomor HP</th>
                                <th>Transaksi Terakhir</th>
                                <th style="width: 25%">Options</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $no = 1;
                            if ($data && mysqli_num_rows($data) > 0):
                                while ($d = mysqli_fetch_assoc($data)):

                                    // amankan semua field dari NULL
                                    $id         = htmlspecialchars($d['id']         ?? '');
                                    $nama       = htmlspecialchars($d['nama']       ?? '');
                                    $alamat     = htmlspecialchars($d['alamat']     ?? '');
                                    $nomor_hp   = htmlspecialchars($d['nomor_hp']   ?? '');
                                    $gender_raw = $d['gender'] ?? '';
                                    $created_at = $d['created_at'] ?? '';

                                    // label gender
                                    if ($gender_raw === 'L') {
                                        $gender = 'Laki-laki';
                                    } elseif ($gender_raw === 'P') {
                                        $gender = 'Perempuan';
                                    } else {
                                        $gender = '-';
                                    }

                                    // tampilkan transaksi terakhir (created_at) apa adanya,
                                    // bisa diformat kalau mau (date('d-m-Y', strtotime(...)))
                                    $transaksi_terakhir = !empty($created_at)
                                        ? htmlspecialchars($created_at)
                                        : '-';
                            ?>
                                <tr>
                                    <td class="text-center"><?= $no++; ?></td>
                                    <td class="text-center fw-bold"><?= $id; ?></td>
                                    <td><?= $nama; ?></td>
                                    <td><?= htmlspecialchars($gender); ?></td>
                                    <td><?= $alamat; ?></td>
                                    <td><?= $nomor_hp; ?></td>
                                    <td><?= $transaksi_terakhir; ?></td>

                                    <td class="text-center">
                                        <a href="?p=detail&id=<?= $id; ?>"
                                           class="btn btn-info btn-sm me-1">
                                            <i class="fas fa-eye"></i> Detail
                                        </a>

                                        <a href="?p=edit_nasabah&id=<?= $id; ?>"
                                           class="btn btn-warning btn-sm me-1">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>

                                        <a href="?p=hapus&id=<?= $id; ?>"
                                           onclick="return confirm('Hapus data nasabah?')"
                                           class="btn btn-danger btn-sm">
                                           <i class="fas fa-trash"></i> Hapus
                                        </a>
                                    </td>
                                </tr>
                            <?php
                                endwhile;
                            else:
                            ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted">
                                        Belum ada data nasabah.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                </div>
                <!--end::Card Body-->

            </div>

        </div>
    </div>
    <!--end::App Content-->

</main>
<!--end::App Main-->
