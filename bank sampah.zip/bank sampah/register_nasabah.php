<?php
session_start();
require_once "koneksi.php";

$errors = [];
$success = "";

// Jika sudah login nasabah, boleh langsung lempar ke dashboard
if (isset($_SESSION['nasabah_id'])) {
    header("Location: dashboard.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama      = trim($_POST['nama'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $password  = trim($_POST['password'] ?? '');
    $password2 = trim($_POST['password2'] ?? '');
    $alamat    = trim($_POST['alamat'] ?? '');
    $nomor_hp  = trim($_POST['nomor_hp'] ?? '');

    // Validasi sederhana
    if ($nama === '')        $errors[] = "Nama wajib diisi.";
    if ($email === '')       $errors[] = "Email wajib diisi.";
    if ($password === '')    $errors[] = "Password wajib diisi.";
    if ($password2 === '')   $errors[] = "Konfirmasi password wajib diisi.";
    if ($password !== $password2) $errors[] = "Password dan konfirmasi tidak sama.";

    // Cek email sudah dipakai di nasabah?
    if (empty($errors)) {
        $email_esc = $koneksi->real_escape_string($email);
        $cek = $koneksi->query("SELECT id FROM nasabah WHERE email = '$email_esc' LIMIT 1");
        if ($cek && $cek->num_rows > 0) {
            $errors[] = "Email sudah terdaftar sebagai nasabah.";
        }
    }

    if (empty($errors)) {
        // Sementara password disimpan plain text (supaya cocok dengan login.php kamu sekarang)
        // Nanti kalau mau aman: $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $nama_esc     = $koneksi->real_escape_string($nama);
        $email_esc    = $email_esc; // sudah di-escape di atas
        $pass_esc     = $koneksi->real_escape_string($password);
        $alamat_esc   = $koneksi->real_escape_string($alamat);
        $nomor_hp_esc = $koneksi->real_escape_string($nomor_hp);
        $created_at   = date('Y-m-d H:i:s');

        $sql = "
            INSERT INTO nasabah (nama, email, password, alamat, nomor_hp, created_at)
            VALUES ('$nama_esc', '$email_esc', '$pass_esc', '$alamat_esc', '$nomor_hp_esc', '$created_at')
        ";

        if ($koneksi->query($sql)) {
            // Bisa langsung login otomatis:
            $new_id = $koneksi->insert_id;
            $_SESSION['nasabah_id'] = $new_id;
            $_SESSION['role']       = 'nasabah';

            header("Location: dashboard.php");
            exit;
        } else {
            $errors[] = "Gagal menyimpan ke database: " . $koneksi->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Register Nasabah - RECYCLEAN</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen flex items-center justify-center">

  <div class="bg-white shadow-2xl rounded-2xl max-w-md w-full p-8">
    <div class="flex items-center justify-center mb-6">
      <div class="bg-green-600 p-2 rounded-full mr-2">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor">
          <path d="M7 21a7 7 0 0 1 0-14h1" />
          <path d="M11 3a7 7 0 0 1 0 14h-1" />
          <path d="M14 21a7 7 0 0 0 0-14h-1" />
        </svg>
      </div>
      <h1 class="text-2xl font-bold text-green-700">RECYCLEAN</h1>
    </div>

    <h2 class="text-xl font-semibold text-gray-800 mb-2 text-center">
      Daftar Sebagai Nasabah
    </h2>
    <p class="text-sm text-gray-500 mb-6 text-center">
      Buat akun untuk mulai menukarkan sampah menjadi poin.
    </p>

    <?php if (!empty($errors)): ?>
      <div class="mb-4 px-4 py-3 rounded bg-red-100 text-red-700 text-sm">
        <ul class="list-disc list-inside">
          <?php foreach ($errors as $e): ?>
            <li><?= htmlspecialchars($e) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="post" class="space-y-4">
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Nama Lengkap</label>
        <input type="text" name="nama" required
               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
               value="<?= htmlspecialchars($_POST['nama'] ?? '') ?>">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
        <input type="email" name="email" required
               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
        <input type="password" name="password" required
               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Konfirmasi Password</label>
        <input type="password" name="password2" required
               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Alamat</label>
        <input type="text" name="alamat"
               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
               value="<?= htmlspecialchars($_POST['alamat'] ?? '') ?>">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Nomor Handphone</label>
        <input type="text" name="nomor_hp"
               class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
               value="<?= htmlspecialchars($_POST['nomor_hp'] ?? '') ?>">
      </div>

      <button type="submit"
              class="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2.5 rounded-lg mt-4 transition-colors">
        Daftar
      </button>
    </form>

    <p class="mt-4 text-sm text-center text-gray-600">
      Sudah punya akun?
      <a href="login.php" class="text-green-600 hover:text-green-700 font-semibold">Masuk di sini</a>
    </p>

    <p class="mt-6 text-xs text-center text-gray-400">
      &copy; <?= date('Y') ?> RECYCLEAN. Semua hak dilindungi.
    </p>
  </div>

</body>
</html>
