<?php
session_start();
require_once "koneksi.php";

// 1. Ambil NASABAH yang login
$nasabah_id = $_SESSION['nasabah_id'] ?? 1; // sementara default 1

$qNasabah = $koneksi->query("SELECT * FROM nasabah WHERE id = '$nasabah_id' LIMIT 1");
$nasabah  = $qNasabah ? $qNasabah->fetch_assoc() : null;

$nama_nasabah  = $nasabah['nama']  ?? 'Nasabah';
$email_nasabah = $nasabah['email'] ?? 'email@contoh.com';

// 2. Ambil riwayat SETORAN user ini
$qSetoran = $koneksi->query("
    SELECT s.*, j.nama_sampah
    FROM setoran s
    LEFT JOIN jenis_sampah j ON s.sampah_id = j.id
    WHERE s.nasabah_id = '$nasabah_id'
    ORDER BY s.tanggal DESC, s.id DESC
");

// 3. Ambil riwayat PENUKARAN HADIAH user ini
$qTukar = $koneksi->query("
    SELECT p.*, h.nama_hadiah
    FROM penukaran_hadiah p
    LEFT JOIN hadiah h ON p.hadiah_id = h.id
    WHERE p.nasabah_id = '$nasabah_id'
    ORDER BY p.tanggal DESC, p.id DESC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Riwayat Transaksi - Recyclean</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
</head>
<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen font-sans">

  <!-- HEADER SAMA SEPERTI DASHBOARD -->
  <header class="bg-white shadow-lg sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex justify-between items-center py-4">
        <div class="flex items-center space-x-3">
          <div class="bg-green-600 p-2 rounded-full">
            <i data-lucide="recycle" class="w-8 h-8 text-white"></i>
          </div>
          <h1 class="text-2xl font-bold text-green-700">RECYCLEAN</h1>
        </div>

        <div class="flex items-center space-x-4">
          <!-- Profile dropdown -->
          <div class="relative">
            <button id="profile-btn" class="flex items-center space-x-3 hover:bg-gray-100 px-3 py-2 rounded-lg transition-colors">
              <div class="w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center font-semibold">
                <?php
                  $init = '';
                  $parts = explode(' ', $nama_nasabah);
                  foreach ($parts as $p) {
                    if ($p !== '') { $init .= strtoupper($p[0]); }
                  }
                  echo htmlspecialchars(substr($init, 0, 2));
                ?>
              </div>
              <span class="font-medium text-gray-700"><?= htmlspecialchars($nama_nasabah) ?></span>
              <i data-lucide="chevron-down" class="w-4 h-4 text-gray-500"></i>
            </button>

            <div id="profile-dropdown" class="hidden absolute top-full right-0 mt-2 bg-white shadow-lg rounded-lg p-2 w-48 z-40">
              <a href="dashboard.php" class="flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                <i data-lucide="home" class="w-4 h-4"></i>
                <span>Dashboard</span>
              </a>
              <a href="profil_nasabah.php" class="flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                <i data-lucide="user" class="w-4 h-4"></i>
                <span>Profil Saya</span>
              </a>
              <hr class="my-2 border-gray-200">
              <a href="logout.php" class="flex items-center space-x-3 px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                <i data-lucide="log-out" class="w-4 h-4"></i>
                <span>Keluar</span>
              </a>
            </div>
          </div>
        </div>

      </div>
    </div>
  </header>

  <!-- MAIN -->
  <main class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

    <!-- HEADER HALAMAN -->
    <section class="mb-6 flex justify-between items-center">
      <div>
        <h2 class="text-3xl font-bold text-gray-800 mb-1">Riwayat Transaksi</h2>
        <p class="text-gray-600">
          Lihat semua aktivitas setoran dan penukaran hadiah kamu.
        </p>
      </div>
      <a href="dashboard.php"
         class="inline-flex items-center px-4 py-2 rounded-lg bg-gray-100 text-gray-700 hover:bg-gray-200 text-sm font-medium">
        <i data-lucide="arrow-left" class="w-4 h-4 mr-2"></i>
        Kembali ke Dashboard
      </a>
    </section>

    <!-- RIWAYAT SETORAN -->
    <section class="mb-8">
      <div class="flex items-center justify-between mb-3">
        <h3 class="text-xl font-semibold text-gray-800 flex items-center">
          <i data-lucide="package" class="w-5 h-5 text-green-600 mr-2"></i>
          Riwayat Setoran
        </h3>
      </div>

      <?php if ($qSetoran && $qSetoran->num_rows > 0): ?>
        <div class="space-y-3">
          <?php while($s = $qSetoran->fetch_assoc()): 
              $tgl_src = null;
              if (!empty($s['tanggal'])) {
                  $tgl_src = $s['tanggal'];
              } elseif (!empty($s['created_at'])) {
                  $tgl_src = $s['created_at'];
              }
              $tgl_tampil = $tgl_src ? date('d M Y', strtotime($tgl_src)) : '-';

              $status = $s['status'] ?? 'Pending';
              $badgeColor = $status === 'Selesai'
                  ? 'bg-green-100 text-green-800'
                  : 'bg-yellow-100 text-yellow-800';
          ?>
            <div class="bg-white rounded-xl shadow-sm p-4 flex justify-between items-start border-l-4 border-green-500">
              <div>
                <div class="flex items-center mb-1">
                  <span class="font-semibold text-gray-800 mr-2">
                    <?= htmlspecialchars($s['nama_sampah'] ?? 'Sampah') ?>
                  </span>
                  <span class="px-2 py-0.5 rounded-full text-xs font-semibold <?= $badgeColor ?>">
                    <?= htmlspecialchars($status) ?>
                  </span>
                </div>
                <div class="text-sm text-gray-600">
                  Tanggal: <?= htmlspecialchars($tgl_tampil) ?><br>
                  Berat: <?= number_format((float)($s['berat'] ?? 0), 1) ?> Kg<br>
                  Nilai: Rp <?= number_format((float)($s['total'] ?? 0)) ?>
                </div>
                <?php if (!empty($s['catatan'])): ?>
                  <div class="text-xs text-gray-500 mt-1">
                    Catatan: <?= nl2br(htmlspecialchars($s['catatan'])) ?>
                  </div>
                <?php endif; ?>
              </div>

              <?php if (!empty($s['bukti'])): ?>
                <div class="ml-4">
                  <img src="uploads/setoran/<?= htmlspecialchars($s['bukti']) ?>"
                       alt="Bukti setoran"
                       class="w-24 h-24 rounded-lg object-cover border">
                </div>
              <?php endif; ?>
            </div>
          <?php endwhile; ?>
        </div>
      <?php else: ?>
        <div class="bg-white rounded-xl shadow-sm p-4 text-gray-500 text-sm">
          Belum ada riwayat setoran.
        </div>
      <?php endif; ?>
    </section>

    <!-- RIWAYAT PENUKARAN HADIAH -->
    <section class="mb-4">
      <div class="flex items-center justify-between mb-3">
        <h3 class="text-xl font-semibold text-gray-800 flex items-center">
          <i data-lucide="gift" class="w-5 h-5 text-blue-600 mr-2"></i>
          Riwayat Penukaran Hadiah
        </h3>
      </div>

      <?php if ($qTukar && $qTukar->num_rows > 0): ?>
        <div class="space-y-3">
          <?php while($p = $qTukar->fetch_assoc()): 
              $tgl_src2 = null;
              if (!empty($p['tanggal'])) {
                  $tgl_src2 = $p['tanggal'];
              } elseif (!empty($p['created_at'])) {
                  $tgl_src2 = $p['created_at'];
              }
              $tgl_tampil2 = $tgl_src2 ? date('d M Y', strtotime($tgl_src2)) : '-';

              $status2 = $p['status'] ?? 'Pending';
              $badgeColor2 = $status2 === 'Selesai'
                  ? 'bg-green-100 text-green-800'
                  : 'bg-yellow-100 text-yellow-800';

              $nama_hadiah = $p['nama_hadiah'] ?? 'Hadiah';
              $jumlah      = (int)($p['jumlah'] ?? 0);
              $total_poin  = (float)($p['total_poin'] ?? 0);
          ?>
            <div class="bg-white rounded-xl shadow-sm p-4 flex justify-between items-start border-l-4 border-blue-500">
              <div>
                <div class="flex items-center mb-1">
                  <span class="font-semibold text-gray-800 mr-2">
                    <?= htmlspecialchars($nama_hadiah) ?>
                  </span>
                  <span class="px-2 py-0.5 rounded-full text-xs font-semibold <?= $badgeColor2 ?>">
                    <?= htmlspecialchars($status2) ?>
                  </span>
                </div>
                <div class="text-sm text-gray-600">
                  Tanggal: <?= htmlspecialchars($tgl_tampil2) ?><br>
                  Jumlah: <?= $jumlah ?> item<br>
                  Poin Digunakan: <?= number_format($total_poin) ?>
                </div>
                <?php if (!empty($p['catatan'])): ?>
                  <div class="text-xs text-gray-500 mt-1">
                    Catatan: <?= nl2br(htmlspecialchars($p['catatan'])) ?>
                  </div>
                <?php endif; ?>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      <?php else: ?>
        <div class="bg-white rounded-xl shadow-sm p-4 text-gray-500 text-sm">
          Belum ada riwayat penukaran hadiah.
        </div>
      <?php endif; ?>
    </section>

  </main>

  <script>
    lucide.createIcons();

    // Toggle dropdown profil
    const profileBtn = document.getElementById('profile-btn');
    const profileDropdown = document.getElementById('profile-dropdown');

    if (profileBtn && profileDropdown) {
      profileBtn.addEventListener('click', () => {
        profileDropdown.classList.toggle('hidden');
      });

      document.addEventListener('click', (e) => {
        if (!profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
          profileDropdown.classList.add('hidden');
        }
      });
    }
  </script>
</body>
</html>
