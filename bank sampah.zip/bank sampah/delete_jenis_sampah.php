<?php
require_once "koneksi.php";

if (!isset($_GET['id'])) {
    echo "<script>
            alert('ID tidak ditemukan!');
            window.location.href='?p=jenis_sampah';
            </script>";
    exit();
}

$id = $_GET['id'];

// Ambil nama file gambar dulu
$q = mysqli_query($koneksi, "SELECT gambar FROM jenis_sampah WHERE id='$id'");
$d = mysqli_fetch_assoc($q);

$folder_upload = 'uploads/jenis_sampah/';

if ($d && !empty($d['gambar']) && file_exists($folder_upload . $d['gambar'])) {
    unlink($folder_upload . $d['gambar']);
}

// Hapus data dari database
$sql = "DELETE FROM jenis_sampah WHERE id = '$id'";

if ($koneksi->query($sql)) {
    echo "<script>
            alert('Data berhasil dihapus!');
            window.location.href='?p=jenis_sampah';
            </script>";
    exit();
} else {
    echo "Gagal menghapus data: " . $koneksi->error;
}
?>
