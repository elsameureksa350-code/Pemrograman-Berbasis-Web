<?php
require_once "koneksi.php";
$data = $koneksi->query("SELECT * FROM hadiah ORDER BY id DESC");
?>

<main class="app-main">
<div class="app-content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6 fw-bold" style="color:#355E3B">
        <h3 class="mb-0 fw-bold">Daftar Hadiah</h3></div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-end">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Hadiah</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<div class="app-content">
  <div class="container-fluid">
    <div class="card shadow-sm border-0">
      <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="fw-bold mb-0">Katalog Hadiah</h5>
        <a href="./?p=add_hadiah" class="btn btn-success"><i class="fas fa-plus"></i> Tambah Hadiah</a>
      </div>

      <div class="card-body">
        <div class="row g-4">
          <?php while ($d = $data->fetch_assoc()): ?>
          <div class="col-md-4 col-lg-3">
            <div class="card h-100 shadow-sm">

              <?php if (!empty($d['gambar'])): ?>
                <img src="uploads/hadiah/<?= htmlspecialchars($d['gambar']) ?>" 
                     class="card-img-top" 
                     style="max-height:180px; object-fit:cover;">
              <?php endif; ?>

              <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($d['nama_hadiah']) ?></h5>
                <p class="mb-1 text-muted">Poin Diperlukan: <b><?= $d['poin_diperlukan'] ?></b></p>
                <p class="mb-1 text-muted">Stok: <b><?= $d['stok'] ?></b></p>
              </div>

              <div class="card-footer d-flex justify-content-between">
                <a href="?p=edit_hadiah&id=<?= $d['id'] ?>" class="btn btn-primary btn-sm w-50 me-1">Edit</a>
                <a href="?p=delete_hadiah&id=<?= $d['id'] ?>" 
                   class="btn btn-danger btn-sm w-50"
                   onclick="return confirm('Yakin ingin menghapus hadiah ini?')">
                   Hapus
                </a>
              </div>
            </div>
          </div>
          <?php endwhile; ?>
        </div>
      </div>
    </div>
  </div>
</div>
</main>
