<?php
session_start();
require_once "koneksi.php";

// ================== KONFIGURASI NAMA KOLOM POIN DI TABEL HADIAH ==================
// Kalau di tabel `hadiah` nama kolomnya bukan `poin` (misal `poin_hadiah`),
// ganti baris di bawah ini:
$kolomPoinHadiah = 'poin';
// ================================================================================


// ==== 1. Ambil NASABAH yang login ====
$nasabah_id = $_SESSION['nasabah_id'] ?? 1;

$qNasabah = $koneksi->query("SELECT * FROM nasabah WHERE id = '$nasabah_id' LIMIT 1");
$nasabah  = $qNasabah ? $qNasabah->fetch_assoc() : null;

$nama_nasabah  = $nasabah['nama'] ?? 'Nasabah';

// ==== 2. Hitung saldo poin ====
$qPoinMasuk = $koneksi->query("
    SELECT COALESCE(SUM(total), 0) AS poin_masuk
    FROM setoran
    WHERE nasabah_id = '$nasabah_id' AND status = 'Selesai'
");
$poinMasukRow = $qPoinMasuk ? $qPoinMasuk->fetch_assoc() : ['poin_masuk' => 0];
$poin_masuk = (float)($poinMasukRow['poin_masuk'] ?? 0);

$qPoinKeluar = $koneksi->query("
    SELECT COALESCE(SUM(total_poin), 0) AS poin_keluar
    FROM penukaran_hadiah
    WHERE nasabah_id = '$nasabah_id' AND status = 'Selesai'
");
$poinKeluarRow = $qPoinKeluar ? $qPoinKeluar->fetch_assoc() : ['poin_keluar' => 0];
$poin_keluar = (float)($poinKeluarRow['poin_keluar'] ?? 0);

$saldo_poin = $poin_masuk - $poin_keluar;
if ($saldo_poin < 0) $saldo_poin = 0;

// ==== 3. Ambil daftar hadiah ====
$qHadiah = $koneksi->query("SELECT * FROM hadiah ORDER BY nama_hadiah ASC");

// ==== 4. Proses penukaran ====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hadiah_id = (int)($_POST['hadiah_id'] ?? 0);
    $jumlah    = (int)($_POST['jumlah'] ?? 0);
    if ($jumlah < 1) $jumlah = 1;
    $tanggal   = date('Y-m-d H:i:s');

    // Ambil data hadiah
    $qH = $koneksi->query("SELECT * FROM hadiah WHERE id = '$hadiah_id' LIMIT 1");
    $hadiah = $qH ? $qH->fetch_assoc() : null;

    if ($hadiah) {
        // baca poin per item dari kolom yang dikonfigurasi
        $poin_item = isset($hadiah[$kolomPoinHadiah]) ? (float)$hadiah[$kolomPoinHadiah] : 0;

        if ($poin_item <= 0) {
            echo "<script>alert('Data poin hadiah belum diatur dengan benar.');</script>";
        } else {
            $total_poin = $poin_item * $jumlah;

            if ($saldo_poin >= $total_poin) {
                $sql = "INSERT INTO penukaran_hadiah 
                        (nasabah_id, hadiah_id, jumlah, total_poin, status, tanggal)
                        VALUES 
                        ('$nasabah_id', '$hadiah_id', '$jumlah', '$total_poin', 'Selesai', '$tanggal')";
                if ($koneksi->query($sql)) {
                    echo "<script>alert('Penukaran berhasil!'); window.location.href='tukar_hadiah.php';</script>";
                    exit;
                } else {
                    echo "<script>alert('Terjadi kesalahan saat menyimpan data.');</script>";
                }
            } else {
                echo "<script>alert('Poin Anda tidak cukup untuk menukar hadiah ini.');</script>";
            }
        }
    } else {
        echo "<script>alert('Hadiah tidak ditemukan.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Penukaran Hadiah - Recyclean</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
</head>
<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen font-sans">

  <!-- Header -->
  <header class="bg-white shadow-lg sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex justify-between items-center py-4">
        <div class="flex items-center space-x-3">
          <div class="bg-green-600 p-2 rounded-full">
            <i data-lucide="recycle" class="w-8 h-8 text-white"></i>
          </div>
          <h1 class="text-2xl font-bold text-green-700">RECYCLEAN</h1>
        </div>

        <div class="flex items-center space-x-4">
          <a href="dashboard.php" class="text-gray-600 hover:text-green-600 font-medium">Kembali</a>
        </div>
      </div>
    </div>
  </header>

  <!-- Main Content -->
  <main class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

    <section class="bg-white rounded-2xl shadow-xl p-8 mb-8 text-center">
      <h2 class="text-3xl font-bold text-gray-800 mb-2">Tukar Poin dengan Hadiah 🎁</h2>
      <p class="text-gray-600 text-lg mb-3">
        Saldo poin Anda saat ini:
        <span class="font-bold text-green-700"><?= number_format($saldo_poin) ?></span> poin
      </p>
    </section>

    <section class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <?php if ($qHadiah && $qHadiah->num_rows > 0): ?>
        <?php while($h = $qHadiah->fetch_assoc()): 
              // aman: baca poin dari kolom yang dikonfigurasi, kalau tidak ada = 0
              $poin_item = isset($h[$kolomPoinHadiah]) ? (float)$h[$kolomPoinHadiah] : 0;
        ?>
          <div class="bg-white p-5 rounded-xl shadow-lg hover:shadow-xl transition-all">
            <?php if (!empty($h['gambar'])): ?>
              <img src="uploads/hadiah/<?= htmlspecialchars($h['gambar']) ?>" 
                   class="w-full h-40 object-cover rounded-lg mb-3" 
                   alt="Gambar Hadiah">
            <?php else: ?>
              <div class="w-full h-40 bg-gray-100 flex items-center justify-center rounded-lg mb-3">
                <i data-lucide="gift" class="w-10 h-10 text-gray-400"></i>
              </div>
            <?php endif; ?>

            <h3 class="text-lg font-semibold text-gray-800 mb-1">
                <?= htmlspecialchars($h['nama_hadiah'] ?? 'Hadiah') ?>
            </h3>
            <p class="text-gray-600 text-sm mb-2">
                <?= htmlspecialchars($h['deskripsi'] ?? '') ?>
            </p>
            <p class="text-green-700 font-medium mb-3">
                <?= number_format($poin_item) ?> poin / item
            </p>

            <form method="POST" action="">
              <input type="hidden" name="hadiah_id" value="<?= (int)$h['id'] ?>">
              <input type="number" name="jumlah" min="1" max="10" value="1" required
                     class="border rounded-lg px-3 py-1 w-20 text-center mr-2">
              <button type="submit"
                      class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-medium">
                Tukar
              </button>
            </form>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <div class="col-span-3 text-center text-gray-500 py-8">
          Belum ada hadiah tersedia.
        </div>
      <?php endif; ?>
    </section>
  </main>

  <script>
    lucide.createIcons();
  </script>
</body>
</html>
