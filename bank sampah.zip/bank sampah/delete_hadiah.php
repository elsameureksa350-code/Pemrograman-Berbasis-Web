<?php
require_once "koneksi.php";

if (!isset($_GET['id'])) {
    echo "<script>alert('ID hadiah tidak ditemukan!'); window.location.href='?p=hadiah';</script>";
    exit();
}

$id = $_GET['id'];
$q = $koneksi->query("SELECT gambar FROM hadiah WHERE id='$id'");
$d = $q->fetch_assoc();

if ($d && !empty($d['gambar'])) {
    $folder = __DIR__ . "/uploads/hadiah/";
    $path = $folder . $d['gambar'];
    if (is_file($path)) unlink($path);
}

$sql = "DELETE FROM hadiah WHERE id='$id'";
if ($koneksi->query($sql)) {
    echo "<script>alert('Hadiah berhasil dihapus!'); window.location.href='?p=hadiah';</script>";
} else {
    echo "Gagal menghapus: " . $koneksi->error;
}
?>
