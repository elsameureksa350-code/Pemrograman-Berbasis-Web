<?php
require_once "koneksi.php";

$filter_date = isset($_GET['tanggal']) && $_GET['tanggal'] != '' 
    ? $_GET['tanggal'] 
    : date('Y-m-d');

$sql = "
SELECT 
    s.id, 
    s.nasabah_id, 
    s.sampah_id, 
    s.berat, 
    s.catatan, 
    s.total, 
    s.bukti, 
    s.status, 
    s.created_at,
    n.nama AS nasabah, 
    j.nama_sampah AS sampah
FROM setoran s
LEFT JOIN nasabah n ON s.nasabah_id = n.id
LEFT JOIN jenis_sampah j ON s.sampah_id = j.id
WHERE DATE(s.tanggal) = '$filter_date'
ORDER BY s.id DESC
";
$q = $koneksi->query($sql);
?>

<main class="app-main">

<div class="app-content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6">
        <h3 class="mb-0">Setoran Sampah</h3>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-end">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Setoran</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<div class="app-content">
  <div class="container-fluid">

    <div class="card">
      <div class="card-header">
        <form method="GET">
          <table class="table table-borderless mb-0">
            <tr>
              <td style="width:150px;">Pilih Tanggal</td>
              <td>
                <input type="date" name="tanggal" class="form-control"
                       value="<?= htmlspecialchars($filter_date ?? '') ?>">
              </td>
              <td>
                <button type="submit" class="btn btn-primary">Filter</button>
                <a href="?p=setoran" class="btn btn-secondary">Reset</a>
              </td>
              <td class="text-end">
                <a href="./?p=add_setoran" class="btn btn-success">
                  <i class="fas fa-plus"></i> Tambah Setoran
                </a>
              </td>
            </tr>
          </table>
        </form>
      </div>

      <div class="card-body">
        <h5 class="fw-bold mb-3">
          Daftar Setoran (<?= htmlspecialchars($filter_date ?? '') ?>)
        </h5>

        <?php if ($q && $q->num_rows > 0): ?>
          <?php while ($d = $q->fetch_assoc()): 
                $status    = $d['status'] ?? 'Pending';
                $status_color = ($status === 'Selesai') ? 'success' : 'warning';

                $nasabah  = htmlspecialchars($d['nasabah']   ?? '');
                $sampah   = htmlspecialchars($d['sampah']    ?? '');
                $berat    = isset($d['berat']) ? (float)$d['berat'] : 0;
                $total    = isset($d['total']) ? (float)$d['total'] : 0;
                $created  = htmlspecialchars($d['created_at'] ?? '');
                $catatan  = $d['catatan'] ?? '';
                $bukti    = $d['bukti'] ?? '';
          ?>
          <div class="card card-setoran mb-3 p-3">

            <!-- Bukti foto kalau ada -->
            <?php if (!empty($bukti)): ?>
              <img src="uploads/setoran/<?= htmlspecialchars($bukti) ?>" 
                   alt="Bukti setoran" 
                   class="img-fluid mb-2"
                   style="max-height:180px; object-fit:cover;">
            <?php endif; ?>

            <b><?= $nasabah ?></b>
            <span class="badge bg-<?= $status_color ?>">
              <?= htmlspecialchars($status) ?>
            </span><br>

            <?= $sampah ?> • 
            <?= number_format($berat, 1) ?> kg • 
            Rp<?= number_format($total) ?><br>

            <small><?= $created ?></small><br>

            <?php if (!empty($catatan)): ?>
              <small>Catatan: <?= nl2br(htmlspecialchars($catatan)) ?></small><br>
            <?php endif; ?>

            <a href="?p=update_status&id=<?= (int)$d['id'] ?>" class="btn btn-success btn-sm mt-2">
              Terima
            </a>
            <a href="?p=delete_setoran&id=<?= (int)$d['id'] ?>" 
               class="btn btn-danger btn-sm mt-2"
               onclick="return confirm('Yakin ingin menghapus setoran ini?')">
               Hapus
            </a>
          </div>
          <?php endwhile; ?>
        <?php else: ?>
          <div class="alert alert-info">Belum ada setoran untuk tanggal ini.</div>
        <?php endif; ?>

      </div>
    </div>

  </div>
</div>

</main>
