<?php
require_once "koneksi.php";

$filter_date = isset($_GET['tanggal']) && $_GET['tanggal'] != '' 
    ? $_GET['tanggal'] 
    : date('Y-m-d');

$sql = "
SELECT p.id, p.nasabah_id, p.hadiah_id, p.jumlah, p.total_poin, p.bukti, p.status, p.tanggal, 
       n.nama AS nasabah, h.nama_hadiah AS hadiah
FROM penukaran_hadiah p
LEFT JOIN nasabah n ON p.nasabah_id = n.id
LEFT JOIN hadiah h ON p.hadiah_id = h.id
WHERE DATE(p.tanggal) = '$filter_date'
ORDER BY p.id DESC
";
$q = $koneksi->query($sql);
?>

<main class="app-main">
<div class="app-content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6 fw-bold" style="color:#355E3B">
        <h3 class="mb-0 fw-bold">Penukaran Hadiah</h3></div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-end">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Penukaran Hadiah</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<div class="app-content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header">
        <form method="GET">
          <table class="table table-borderless mb-0">
            <tr>
              <td style="width:150px;">Pilih Tanggal</td>
              <td><input type="date" name="tanggal" class="form-control" value="<?= htmlspecialchars($filter_date) ?>"></td>
              <td>
                <button type="submit" class="btn btn-primary">Filter</button>
                <a href="?p=penukaran_hadiah" class="btn btn-secondary">Reset</a>
              </td>
              <td class="text-end">
                <a href="./?p=add_penukaran_hadiah" class="btn btn-success">
                  <i class="fas fa-gift"></i> Tambah Penukaran
                </a>
              </td>
            </tr>
          </table>
        </form>
      </div>

      <div class="card-body">
        <h5 class="fw-bold mb-3">Daftar Penukaran (<?= htmlspecialchars($filter_date) ?>)</h5>

        <?php if ($q->num_rows > 0): ?>
          <?php while ($d = $q->fetch_assoc()): 
                $status_color = ($d['status'] === 'Selesai') ? 'success' : 'warning';
          ?>
          <div class="card card-penukaran mb-3 p-3">
            
            <!-- Bukti foto -->
            <?php if (!empty($d['bukti'])): ?>
              <img src="uploads/penukaran_hadiah/<?= htmlspecialchars($d['bukti']) ?>" 
                   alt="Bukti penukaran" 
                   class="img-fluid mb-2"
                   style="max-height:180px; object-fit:cover;">
            <?php endif; ?>

            <b><?= htmlspecialchars($d['nasabah']) ?></b>
            <span class="badge bg-<?= $status_color ?>"><?= htmlspecialchars($d['status']) ?></span><br>

            <?= htmlspecialchars($d['hadiah']) ?> × <?= $d['jumlah'] ?> item<br>
            <small>Total Poin: <?= $d['total_poin'] ?></small><br>
            <small><?= htmlspecialchars($d['tanggal']) ?></small><br>

            <a href="?p=update_penukaran_hadiah&id=<?= $d['id'] ?>" class="btn btn-success btn-sm mt-2">Selesai</a>
            <a href="?p=delete_penukaran_hadiah&id=<?= $d['id'] ?>" class="btn btn-danger btn-sm mt-2" 
               onclick="return confirm('Yakin ingin menghapus penukaran ini?')">Hapus</a>
          </div>
          <?php endwhile; ?>
        <?php else: ?>
          <div class="alert alert-info">Belum ada penukaran pada tanggal ini.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</main>
