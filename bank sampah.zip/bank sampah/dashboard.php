<?php
session_start();
require_once "koneksi.php";

// ==== 1. Ambil NASABAH yang login ====
$nasabah_id = $_SESSION['nasabah_id'] ?? 1; // sementara default 1 kalau belum ada session

$qNasabah = $koneksi->query("SELECT * FROM nasabah WHERE id = '$nasabah_id' LIMIT 1");
$nasabah  = $qNasabah->fetch_assoc();

$nama_nasabah  = $nasabah['nama'] ?? 'Nasabah';
$email_nasabah = $nasabah['email'] ?? 'email@contoh.com';


// Total sampah (kg) & total nilai setoran
$qSetoran = $koneksi->query("
    SELECT 
        COALESCE(SUM(berat), 0) AS total_kg,
        COALESCE(SUM(total), 0) AS total_nilai
    FROM setoran
    WHERE nasabah_id = '$nasabah_id'
      AND status = 'Selesai'
");
$setoranAgg = $qSetoran->fetch_assoc();
$total_kg     = $setoranAgg['total_kg'] ?? 0;
$total_nilai  = $setoranAgg['total_nilai'] ?? 0;

// Poin masuk dari semua setoran yang sudah Selesai
$qPoinMasuk = $koneksi->query("
    SELECT COALESCE(SUM(total), 0) AS poin_masuk
    FROM setoran
    WHERE nasabah_id = '$nasabah_id'
      AND status = 'Selesai'
");
$rowMasuk   = $qPoinMasuk ? $qPoinMasuk->fetch_assoc() : ['poin_masuk' => 0];
$poin_masuk = $rowMasuk['poin_masuk'] ?? 0;

// Poin keluar dari penukaran hadiah yang sudah Selesai
$qPoinKeluar = $koneksi->query("
    SELECT COALESCE(SUM(total_poin), 0) AS poin_keluar
    FROM penukaran_hadiah
    WHERE nasabah_id = '$nasabah_id'
      AND status = 'Selesai'
");
$rowKeluar   = $qPoinKeluar ? $qPoinKeluar->fetch_assoc() : ['poin_keluar' => 0];
$poin_keluar = $rowKeluar['poin_keluar'] ?? 0;

// Saldo poin akhir
$saldo_poin  = $poin_masuk - $poin_keluar;


// Estimasi “pohon” -> misal 10kg sampah ≈ 1 pohon
$total_pohon = $total_kg > 0 ? max(1, floor($total_kg / 10)) : 0;

// Level berdasarkan poin
if ($saldo_poin >= 2000) {
    $user_level = "Eco Warrior 🌟";
} elseif ($saldo_poin >= 1000) {
    $user_level = "Green Hero 💚";
} elseif ($saldo_poin >= 500) {
    $user_level = "Earth Saver 🌱";
} else {
    $user_level = "Pemula Peduli";
}
$user_rank_text = "Level berdasarkan total poin kamu";

// ==== 3. Setoran Bulan Ini & Tahun Ini ====
$qBulan = $koneksi->query("
    SELECT 
        COALESCE(SUM(berat), 0) AS kg_bulan,
        COALESCE(SUM(total), 0) AS nilai_bulan
    FROM setoran
    WHERE nasabah_id = '$nasabah_id'
      AND status = 'Selesai'
      AND YEAR(tanggal) = YEAR(CURDATE())
      AND MONTH(tanggal) = MONTH(CURDATE())
");
$bulanAgg = $qBulan->fetch_assoc();
$kg_bulan   = $bulanAgg['kg_bulan'] ?? 0;
$nilai_bulan = $bulanAgg['nilai_bulan'] ?? 0;

// target fiktif untuk progress bar (boleh diubah)
$target_kg_bulan  = 50;
$target_kg_tahun  = 500;

// Setoran Tahun Ini
$qTahun = $koneksi->query("
    SELECT 
        COALESCE(SUM(berat), 0) AS kg_tahun
    FROM setoran
    WHERE nasabah_id = '$nasabah_id'
      AND status = 'Selesai'
      AND YEAR(tanggal) = YEAR(CURDATE())
");
$tahunAgg = $qTahun->fetch_assoc();
$kg_tahun = $tahunAgg['kg_tahun'] ?? 0;

// Hitung persentase progress
$persen_bulan = $target_kg_bulan > 0 ? min(100, ($kg_bulan / $target_kg_bulan) * 100) : 0;
$persen_tahun = $target_kg_tahun > 0 ? min(100, ($kg_tahun / $target_kg_tahun) * 100) : 0;

// ==== 4. Transaksi terbaru (setoran) ====
$qTransaksi = $koneksi->query("
    SELECT s.*, j.nama_sampah 
    FROM setoran s
    LEFT JOIN jenis_sampah j ON s.sampah_id = j.id
    WHERE s.nasabah_id = '$nasabah_id'
    ORDER BY s.created_at DESC
    LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RECYCLEAN - Dashboard Nasabah</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
  <link rel="stylesheet" href="style.css">
</head>

<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen font-sans">

  <!-- Header -->
  <header class="bg-white shadow-lg sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex justify-between items-center py-4">
        <div class="flex items-center space-x-3">
          <div class="bg-green-600 p-2 rounded-full">
            <i data-lucide="recycle" class="w-8 h-8 text-white"></i>
          </div>
          <h1 class="text-2xl font-bold text-green-700">RECYCLEAN</h1>
        </div>

        <div class="flex items-center space-x-4">
          <!-- Notification Bell (dummy) -->
          <div class="relative">
            <button id="notification-btn" class="relative p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <i data-lucide="bell" class="w-6 h-6 text-gray-600"></i>
              <span id="notification-badge" class="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center hidden">0</span>
            </button>
            <!-- Dropdown notifikasi bisa diisi nanti -->
          </div>

          <!-- Profile dropdown -->
          <div class="relative">
            <button id="profile-btn" class="flex items-center space-x-3 hover:bg-gray-100 px-3 py-2 rounded-lg transition-colors">
              <div class="w-10 h-10 rounded-full bg-green-500 text-white flex items-center justify-center font-semibold">
                <?php
                  $init = '';
                  $parts = explode(' ', $nama_nasabah);
                  foreach ($parts as $p) {
                    if ($p !== '') { $init .= strtoupper($p[0]); }
                  }
                  echo htmlspecialchars(substr($init, 0, 2));
                ?>
              </div>
              <span class="font-medium text-gray-700"><?= htmlspecialchars($nama_nasabah) ?></span>
              <i data-lucide="chevron-down" class="w-4 h-4 text-gray-500"></i>
            </button>

            <div id="profile-dropdown" class="hidden absolute top-full right-0 mt-2 bg-white shadow-lg rounded-lg p-2 w-48 z-40">
              <a href="profil_nasabah.php" class="flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                <i data-lucide="user" class="w-4 h-4"></i>
                <span>Profil Saya</span>
              </a>
              <a href="pengaturan_nasabah.php" class="flex items-center space-x-3 px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                <i data-lucide="settings" class="w-4 h-4"></i>
                <span>Pengaturan</span>
              </a>
              <hr class="my-2 border-gray-200">
              <a href="logout.php" class="flex items-center space-x-3 px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                <i data-lucide="log-out" class="w-4 h-4"></i>
                <span>Keluar</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>

  <!-- Main Content -->
  <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

    <!-- Welcome Section -->
    <section class="bg-white rounded-2xl shadow-xl p-8 mb-8 text-center">
      <h2 class="text-3xl font-bold text-gray-800 mb-2">
        Selamat Datang, <?= htmlspecialchars($nama_nasabah) ?>! 🌿
      </h2>
      <p class="text-gray-600 text-lg">
        Mari bersama-sama menjaga lingkungan dengan mendaur ulang sampah Anda.
      </p>
    </section>

    <!-- Info Cards -->
    <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <!-- Total Sampah -->
      <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="bg-blue-100 p-3 rounded-full">
            <i data-lucide="package" class="w-8 h-8 text-blue-600"></i>
          </div>
          <span class="text-2xl font-bold text-blue-700">
            <?= number_format($total_kg, 1) ?> Kg
          </span>
        </div>
        <p class="text-gray-600 font-medium">Total Sampah Terkumpul</p>
        <p class="text-sm text-gray-500">Ayo tingkatkan lagi!</p>
      </div>

      <!-- Total Poin -->
      <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="bg-green-100 p-3 rounded-full">
            <i data-lucide="coins" class="w-8 h-8 text-green-600"></i>
          </div>
          <span class="text-3xl font-bold text-green-700">
            <?= number_format($saldo_poin) ?>
          </span>
        </div>
        <p class="text-gray-600 font-medium">Total Poin</p>
        <p class="text-sm text-gray-500">Tukarkan dengan hadiah!</p>
      </div>

      <!-- Level -->
      <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="bg-yellow-100 p-3 rounded-full">
            <i data-lucide="trophy" class="w-8 h-8 text-yellow-600"></i>
          </div>
          <span class="text-2xl font-bold text-yellow-700">
            <?= htmlspecialchars($user_level) ?>
          </span>
        </div>
        <p class="text-gray-600 font-medium">Peringkat Anda</p>
        <p class="text-sm text-gray-500"><?= htmlspecialchars($user_rank_text) ?></p>
      </div>

      <!-- Dampak Lingkungan -->
      <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="bg-purple-100 p-3 rounded-full">
            <i data-lucide="leaf" class="w-8 h-8 text-purple-600"></i>
          </div>
          <span class="text-2xl font-bold text-purple-700">
            <?= $total_pohon ?>
          </span>
        </div>
        <p class="text-gray-600 font-medium">Dampak Lingkungan</p>
        <p class="text-sm text-gray-500">Setara dengan menanam pohon</p>
      </div>
    </section>

    <!-- Quick Actions (button boleh diarahkan ke halaman PHP lain) -->
    <section class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <a href="setor_nasabah.php" class="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all transform hover:scale-105">
        <div class="flex items-center space-x-4">
          <i data-lucide="plus-circle" class="w-10 h-10"></i>
          <div class="text-left">
            <h3 class="text-xl font-bold">Setor Sampah</h3>
            <p class="text-green-100">Tambah poin dan bantu lingkungan</p>
          </div>
        </div>
      </a>

      <a href="tukar_hadiah.php" class="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all transform hover:scale-105">
        <div class="flex items-center space-x-4">
          <i data-lucide="gift" class="w-10 h-10"></i>
          <div class="text-left">
            <h3 class="text-xl font-bold">Tukar Poin & Hadiah</h3>
            <p class="text-blue-100">Dapatkan hadiah menarik</p>
          </div>
        </div>
      </a>

      <a href="lokasi_bank_sampah.php" class="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-all transform hover:scale-105">
        <div class="flex items-center space-x-4">
          <i data-lucide="map-pin" class="w-10 h-10"></i>
          <div class="text-left">
            <h3 class="text-xl font-bold">Lokasi Bank Sampah</h3>
            <p class="text-yellow-100">Temukan titik setoran terdekat</p>
          </div>
        </div>
      </a>
    </section>

    <!-- Progress & Achievements -->
    <section class="bg-white rounded-xl shadow-lg p-8 mb-8">
      <h3 class="text-2xl font-bold text-gray-800 mb-6">Pencapaian</h3>
      <div class="space-y-6">
        <div>
          <div class="flex justify-between mb-2">
            <span class="text-gray-700 font-medium">Setoran Bulan Ini</span>
            <span class="text-gray-700 font-medium">
              <?= number_format($kg_bulan,1) ?> Kg dari <?= $target_kg_bulan ?> Kg
            </span>
          </div>
          <div class="w-full bg-gray-200 rounded-full h-3">
            <div class="bg-green-500 h-3 rounded-full transition-all duration-1000" style="width: <?= $persen_bulan ?>%"></div>
          </div>
        </div>
        <div>
          <div class="flex justify-between mb-2">
            <span class="text-gray-700 font-medium">Setoran Tahun Ini</span>
            <span class="text-gray-700 font-medium">
              <?= number_format($kg_tahun,1) ?> Kg dari <?= $target_kg_tahun ?> Kg
            </span>
          </div>
          <div class="w-full bg-gray-200 rounded-full h-3">
            <div class="bg-green-500 h-3 rounded-full transition-all duration-1000" style="width: <?= $persen_tahun ?>%"></div>
          </div>
        </div>
      </div>
    </section>

    <!-- Recent Transactions -->
    <section class="bg-white rounded-xl shadow-lg p-8">
      <h3 class="text-2xl font-bold text-gray-800 mb-6">Transaksi Terbaru</h3>
      <div class="overflow-x-auto">
        <table class="w-full">
          <thead>
            <tr class="border-b border-gray-200">
              <th class="text-left py-3 px-4 font-semibold text-gray-700">Tanggal</th>
              <th class="text-left py-3 px-4 font-semibold text-gray-700">Jenis Sampah</th>
              <th class="text-left py-3 px-4 font-semibold text-gray-700">Berat (Kg)</th>
              <th class="text-left py-3 px-4 font-semibold text-gray-700">Nilai / Poin</th>
              <th class="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($qTransaksi->num_rows > 0): ?>
              <?php while($t = $qTransaksi->fetch_assoc()): ?>
                <tr class="border-b border-gray-100">
                  <td class="py-3 px-4 text-gray-700">
                    <?php
    // tentukan sumber tanggal yang tidak null/kosong
    $srcTanggal = null;
    if (!empty($t['tanggal'])) {
        $srcTanggal = $t['tanggal'];
    } elseif (!empty($t['created_at'])) {
        $srcTanggal = $t['created_at'];
    }

    if ($srcTanggal) {
        echo date('d M Y', strtotime($srcTanggal));
    } else {
        echo '-';
    }
?>

                  </td>
                  <td class="py-3 px-4 text-gray-700">
                    <?= htmlspecialchars($t['nama_sampah'] ?? '-') ?>
                  </td>
                  <td class="py-3 px-4 text-gray-700">
                    <?= number_format($t['berat'],1) ?>
                  </td>
                  <td class="py-3 px-4 text-gray-700">
                    <?= number_format($t['total']) ?>
                  </td>
                  <td class="py-3 px-4">
                    <?php
                      $status = $t['status'] ?? 'Pending';
                      $badgeColor = $status == 'Selesai' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800';
                    ?>
                    <span class="px-3 py-1 rounded-full text-xs font-semibold <?= $badgeColor ?>">
                      <?= htmlspecialchars($status) ?>
                    </span>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr>
                <td colspan="5" class="py-4 text-center text-gray-500">
                  Belum ada transaksi.
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <div class="mt-6 text-center">
        <a href="riwayat_nasabah.php" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-medium transition-colors">
          Lihat Semua Riwayat
        </a>
      </div>
    </section>

  </main>

  <script>
    lucide.createIcons();

    // Toggle dropdown profil
    const profileBtn = document.getElementById('profile-btn');
    const profileDropdown = document.getElementById('profile-dropdown');

    if (profileBtn && profileDropdown) {
      profileBtn.addEventListener('click', () => {
        profileDropdown.classList.toggle('hidden');
      });

      document.addEventListener('click', (e) => {
        if (!profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
          profileDropdown.classList.add('hidden');
        }
      });
    }
  </script>

</body>
</html>
