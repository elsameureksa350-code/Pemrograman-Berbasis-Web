<?php
require_once "koneksi.php";

// Ambil semua data jenis sampah
$data = mysqli_query($koneksi, "SELECT * FROM jenis_sampah ORDER BY id DESC");

// Hitung total kategori
$total_kategori = mysqli_num_rows($data);
?>

<!--begin::App Main-->
<main class="app-main">

    <!--begin::App Content Header-->
    <div class="app-content-header">
        <div class="container-fluid">

            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h2 class="fw-bold" style="color:#355E3B">Jenis Sampah</h2>
                </div>

                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Jenis Sampah</li>
                    </ol>
                </div>
            </div>

            <div class="card-header bg-white d-flex justify-content-between align-items-center mt-3">
                <a href="./?p=add_jenis_sampah" class="btn btn-success">
                    <i class="fas fa-plus"></i> Tambah Kategori
                </a>
            </div>

        </div>
    </div>
    <!--end::App Content Header-->

    <!--begin::App Content-->
    <div class="app-content">
        <div class="container-fluid">

            <div class="card shadow-sm border-0">

                <div class="container py-4">

                    <h6 class="text-muted mb-4">Kelola jenis dan harga sampah</h6>

                    <div class="row g-4">

                        <?php while ($d = mysqli_fetch_assoc($data)) : ?>

                        <div class="col-md-4 col-lg-3">
                            <div class="card-jenis">
                                <?php if (!empty($d['gambar'])):
                                    ?>
                                <img src="uploads/jenis_sampah/<?= $d['gambar'] ?>"
                                alt="<?= $d['nama_sampah'] ?>"
                                class="img-fluid mb-2"
                                style="max-height:140px; object-fit:cover; width:100%;">
                                <?php endif;
                                ?>
                                <i class="fas fa-recycle"></i>

                                <h2 class="fw-bold"><?= $d['nama_sampah'] ?></h2>
                                <h6 class="fw-bold"><?= $d['kategori'] ?></h6>

                                <hr>

                                <?php if ($d['harga_per_pcs'] > 0): ?>
                                    <p>Poin/Pcs: 
                                        <span class="badge bg-success"><?= $d['poin_per_pcs'] ?> Poin</span>
                                    </p>

                                    <p class="text-primary">
                                        Total Terkumpul: 
                                        <strong><?= $d['harga_per_pcs'] ?> Pcs</strong>
                                    </p>

                                    <p class="text-success">
                                        Nilai Total: 
                                        <strong><?= $d['harga_per_pcs'] * $d['poin_per_pcs'] ?> Poin</strong>
                                    </p>

                                <?php else: ?>
                                    <p>Harga/kg: 
                                        <span class="badge bg-success">
                                            Rp <?= number_format($d['harga_per_kg'], 0, ',', '.') ?>
                                        </span>
                                    </p>

                                    <p class="text-primary">
                                        Total Terkumpul: 
                                        <strong><?= $d['total_kg'] ?> kg</strong>
                                    </p>

                                    <p class="text-success">
                                        Nilai Total: 
                                        <strong>
                                            Rp <?= number_format($d['total_kg'] * $d['harga_per_kg'], 0, ',', '.') ?>
                                        </strong>
                                    </p>
                                <?php endif; ?>

                                <div class="mt-3">
                                    <a href="?p=edit_jenis_sampah&id=<?= $d['id'] ?>" 
                                       class="btn btn-primary w-100">
                                       Edit
                                    </a>
                                </div>
                                <div class="mt-2">
                                    <a href="?p=delete_jenis_sampah&id=<?= $d['id'] ?>" 
                                       class="btn btn-danger w-100"
                                       onclick="return confirm('Yakin ingin menghapus data ini?');">
                                       Hapus
                                    </a>
                                </div>


                            </div>
                        </div>

                        <?php endwhile; ?>

                    </div>

                </div>

            </div>

        </div>
    </div>
    <!--end::App Content-->

</main>

<!-- FontAwesome -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
</body>
</html>
