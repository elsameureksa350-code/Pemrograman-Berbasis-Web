<?php
session_start();

// kalau sudah login, langsung lempar ke halaman masing-masing
if (isset($_SESSION['admin_id'])) {
    header("Location: index.php");
    exit;
}
if (isset($_SESSION['nasabah_id'])) {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>RECYCLEAN - Selamat Datang</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen flex flex-col">

  <!-- Header -->
  <header class="bg-white shadow-md">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
      <div class="flex items-center space-x-3">
        <div class="bg-green-600 p-2 rounded-full">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path d="M7 21a7 7 0 0 1 0-14h1"/>
            <path d="M11 3a7 7 0 0 1 0 14h-1"/>
            <path d="M14 21a7 7 0 0 0 0-14h-1"/>
          </svg>
        </div>
        <div>
          <h1 class="text-2xl font-bold text-green-700">RECYCLEAN</h1>
          <p class="text-xs text-gray-500 -mt-1">Rubbish Your Recycle</p>
        </div>
      </div>

      <div class="flex items-center space-x-3">
        <a href="login.php"
           class="px-4 py-2 text-sm font-semibold rounded-lg border border-green-600 text-green-700 hover:bg-green-50">
          Masuk
        </a>
        <a href="register_nasabah.php"
           class="px-4 py-2 text-sm font-semibold rounded-lg bg-green-600 text-white hover:bg-green-700">
          Daftar Nasabah
        </a>
      </div>
    </div>
  </header>

  <!-- Main -->
  <main class="flex-1">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid md:grid-cols-2 gap-10 items-center">

      <!-- Kiri: Hero text -->
      <div>
        <h2 class="text-3xl md:text-4xl font-extrabold text-gray-800 mb-4">
          Kelola Sampah, Raih Manfaat, Jaga Bumi 🌍
        </h2>
        <p class="text-gray-600 mb-6 text-justify">
          <span class="font-semibold">Recyclean</span> adalah sistem bank sampah berbasis web yang membantu
          pengelolaan data nasabah, setoran sampah, penukaran poin, dan riwayat transaksi secara
          rapi dan terstruktur. Nasabah dapat menyetorkan sampah, mengumpulkan poin, dan
          menukarkannya dengan berbagai hadiah menarik.
        </p>

        <div class="flex flex-wrap gap-3 mb-8">
          <a href="login.php"
             class="inline-flex items-center px-5 py-2.5 rounded-lg bg-green-600 text-white font-semibold hover:bg-green-700">
            Mulai Masuk
          </a>
          <a href="#tentang"
             class="inline-flex items-center px-5 py-2.5 rounded-lg border border-green-600 text-green-700 font-semibold hover:bg-green-50">
            Tentang Recyclean
          </a>
        </div>

        <div class="grid grid-cols-3 gap-4 text-center text-sm">
          <div class="bg-white/70 backdrop-blur rounded-xl p-4 shadow">
            <div class="text-lg font-bold text-green-700">Nasabah</div>
            <div class="text-gray-500 mt-1">Tercatat dengan rapi</div>
          </div>
          <div class="bg-white/70 backdrop-blur rounded-xl p-4 shadow">
            <div class="text-lg font-bold text-green-700">Setoran</div>
            <div class="text-gray-500 mt-1">Dipantau setiap hari</div>
          </div>
          <div class="bg-white/70 backdrop-blur rounded-xl p-4 shadow">
            <div class="text-lg font-bold text-green-700">Hadiah</div>
            <div class="text-gray-500 mt-1">Tukar poin jadi manfaat</div>
          </div>
        </div>
      </div>

      <!-- Kanan: Card profil / ilustrasi -->
      <div class="bg-white rounded-2xl shadow-xl p-8">
        <h3 class="text-xl font-bold text-gray-800 mb-4 text-center">Profil Singkat Recyclean</h3>

        <div class="flex flex-col items-center mb-4">
          <div class="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mb-3">
            <span class="text-3xl">♻</span>
          </div>
          <p class="text-gray-600 text-center text-sm">
            Sistem ini dikembangkan untuk membantu pengelola bank sampah dan nasabah dalam
            mencatat aktivitas daur ulang secara digital, sederhana, dan mudah digunakan.
          </p>
        </div>

        <ul class="space-y-2 text-sm text-gray-700 mb-6">
          <li>• Login terpisah antara <span class="font-semibold">Admin</span> dan <span class="font-semibold">Nasabah</span>.</li>
          <li>• Pencatatan jenis sampah dan setoran secara otomatis.</li>
          <li>• Perhitungan poin dan penukaran hadiah.</li>
          <li>• Dashboard nasabah yang menampilkan riwayat dan pencapaian.</li>
        </ul>

        <div class="space-y-2 text-sm text-gray-600">
          <p><span class="font-semibold">Admin:</span> mengelola nasabah, setoran, hadiah, dan laporan.</p>
          <p><span class="font-semibold">Nasabah:</span> menyetorkan sampah, melihat poin, dan menukar hadiah.</p>
        </div>

        <div class="mt-6 flex flex-col gap-2">
          <a href="login.php"
             class="w-full text-center px-4 py-2.5 rounded-lg bg-green-600 text-white font-semibold hover:bg-green-700">
            Masuk Sekarang
          </a>
          <a href="register_nasabah.php"
             class="w-full text-center px-4 py-2.5 rounded-lg border border-green-600 text-green-700 font-semibold hover:bg-green-50">
            Daftar Sebagai Nasabah
          </a>
        </div>
      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer class="bg-gray-800 text-white text-center text-sm py-4 mt-8">
    &copy; <?= date('Y') ?> RECYCLEAN. Bersama menjaga bumi.
  </footer>

</body>
</html>
